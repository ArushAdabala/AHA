package main

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"math"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

func newUUID() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return ""
	}
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	hs := hex.EncodeToString(b)
	return fmt.Sprintf("%s-%s-%s-%s-%s", hs[0:8], hs[8:12], hs[12:16], hs[16:20], hs[20:32])
}

func getAPIKey() string {
	return "AIzaSyBkfgjhn-pYQ5d1vT50AAEQEg85wGn-GAo"
}

func initDB() error {
	dsn := os.Getenv("MYSQL_DSN")
	if dsn == "" {
		return nil
	}
	conn, err := sql.Open("mysql", dsn)
	if err != nil {
		return err
	}
	conn.SetMaxOpenConns(5)
	conn.SetMaxIdleConns(5)
	conn.SetConnMaxLifetime(30 * time.Minute)
	if err := conn.Ping(); err != nil {
		return err
	}
	ddls := []string{
		`CREATE TABLE IF NOT EXISTS merchants (
  name VARCHAR(256) PRIMARY KEY,
  address TEXT,
  lat DOUBLE,
  lng DOUBLE,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)`,
		`CREATE TABLE IF NOT EXISTS droneports (
  id VARCHAR(128) PRIMARY KEY,
  name VARCHAR(256),
  lat DOUBLE,
  lng DOUBLE,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)`,
		`CREATE TABLE IF NOT EXISTS customers (
  username VARCHAR(128) PRIMARY KEY,
  address TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)`,
		`CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(64) PRIMARY KEY,
  user VARCHAR(128),
  merchant_name VARCHAR(256),
  merchant_address TEXT,
  merchant_lat DOUBLE,
  merchant_lng DOUBLE,
  customer_address TEXT,
  droneport_id VARCHAR(128),
  droneport_name VARCHAR(256),
  status VARCHAR(32),
  leg1_polyline MEDIUMTEXT,
  leg2_polyline MEDIUMTEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)`,
	}
	for _, stmt := range ddls {
		if _, err := conn.Exec(stmt); err != nil {
			return err
		}
	}
	dbMu.Lock()
	db = conn
	dbMu.Unlock()
	log.Println("DB initialized (MySQL)")
	return nil
}

type routeJob struct {
	ID        string         `json:"id"`
	Origin    string         `json:"origin"`
	Dest      string         `json:"destination"`
	Status    string         `json:"status"`
	Result    *droneRouteOut `json:"result,omitempty"`
	Error     string         `json:"error,omitempty"`
	StartedAt time.Time      `json:"started_at"`
	Finished  *time.Time     `json:"finished,omitempty"`
	cancel    context.CancelFunc
}

var (
	routeJobs = make(map[string]*routeJob)
	routeMu   = &sync.Mutex{}

	db   *sql.DB
	dbMu sync.Mutex
)

type storedOrder struct {
	ID              string    `json:"id"`
	User            string    `json:"user"`
	MerchantName    string    `json:"merchant_name"`
	MerchantAddress string    `json:"merchant_address"`
	MerchantLat     float64   `json:"merchant_lat"`
	MerchantLng     float64   `json:"merchant_lng"`
	CustomerAddress string    `json:"customer_address"`
	DroneportID     string    `json:"droneport_id"`
	DroneportName   string    `json:"droneport_name"`
	Status          string    `json:"status"`
	Leg1Polyline    string    `json:"leg1_polyline"`
	Leg2Polyline    string    `json:"leg2_polyline"`
	CreatedAt       time.Time `json:"created_at"`

	DroneID             string  `json:"drone_id,omitempty"`
	BatteryUsedPct      float64 `json:"battery_used_pct,omitempty"`
	BatteryRemainingPct float64 `json:"battery_remaining_pct,omitempty"`
}

type gDirections struct {
	Status string `json:"status"`
	Routes []struct {
		OverviewPolyline struct {
			Points string `json:"points"`
		} `json:"overview_polyline"`
		Bounds struct {
			NorthEast struct{ Lat, Lng float64 } `json:"northeast"`
			SouthWest struct{ Lat, Lng float64 } `json:"southwest"`
		} `json:"bounds"`
		Legs []struct {
			Distance struct{ Text string } `json:"distance"`
			Duration struct{ Text string } `json:"duration"`
			Steps    []struct {
				HTMLInstructions string                `json:"html_instructions"`
				Distance         struct{ Text string } `json:"distance"`
				Duration         struct{ Text string } `json:"duration"`
			} `json:"steps"`
		} `json:"legs"`
	} `json:"routes"`
}

type apiOut struct {
	Status       string              `json:"status"`
	DistanceText string              `json:"distance_text"`
	DurationText string              `json:"duration_text"`
	Polyline     string              `json:"polyline"`
	Bounds       map[string]float64  `json:"bounds,omitempty"`
	Steps        []map[string]string `json:"steps"`
}

type droneRouteOut struct {
	Status      string         `json:"status"`
	DistanceM   float64        `json:"distance_m"`
	DurationSec float64        `json:"duration_s"`
	Polyline    string         `json:"polyline"`
	Debug       map[string]any `json:"debug,omitempty"`

	Grid *droneGridOut `json:"grid,omitempty"`

	LaunchPort   *DronePort `json:"launch_port,omitempty"`
	MerchantPort *DronePort `json:"merchant_port,omitempty"`

	AvgWindMS   float64 `json:"avg_wind_ms,omitempty"`
	MaxGustMS   float64 `json:"max_gust_ms,omitempty"`
	MaxPrecip   float64 `json:"max_precip_penalty,omitempty"`
	WeatherNote string  `json:"weather_note,omitempty"`
}

type geoJSON struct {
	Type     string           `json:"type"`
	Features []geoJSONFeature `json:"features"`
}

type geoJSONFeature struct {
	Type       string          `json:"type"`
	Properties map[string]any  `json:"properties"`
	Geometry   geoJSONGeometry `json:"geometry"`
}

type geoJSONGeometry struct {
	Type        string `json:"type"`
	Coordinates any    `json:"coordinates"`
}

type Polygon struct {
	Rings [][][2]float64
}

type NFZCircle struct {
	Lat, Lng float64
	RadiusM  float64
	Label    string
}

type DronePort struct {
	ID   string  `json:"id"`
	Name string  `json:"name"`
	Lat  float64 `json:"lat"`
	Lng  float64 `json:"lng"`
}

type Drone struct {
	ID         string  `json:"id"`
	BatteryPct float64 `json:"battery_pct"`
}

type maintenanceDrone struct {
	Drone     *Drone
	readyAt   time.Time
	startedAt time.Time
	startPct  float64
}

type dronePortFleet struct {
	Port        DronePort
	Ready       []*Drone
	Maintenance []*maintenanceDrone
	Orders      map[string]*Drone
}

var (
	fleetMu          sync.Mutex
	droneFleets      map[string]*dronePortFleet
	orderAssignments map[string]*assignedDrone
	positionsMu      sync.Mutex
	dronePositions   map[string][2]float64
)

type assignedDrone struct {
	PortID string
	Drone  *Drone
}

type WxSampler interface {
	Sample(lat, lng float64) (windMS, windDirDeg, gustMS, precipPenalty, crosswindPenalty float64)
}

type blockedCell struct {
	SW node `json:"sw"`
	NE node `json:"ne"`
}

func setDronePosition(droneID string, lat, lng float64) {
	positionsMu.Lock()
	defer positionsMu.Unlock()
	dronePositions[droneID] = [2]float64{lat, lng}
}

func getDronePosition(droneID string) (float64, float64, bool) {
	positionsMu.Lock()
	defer positionsMu.Unlock()
	if pt, ok := dronePositions[droneID]; ok {
		return pt[0], pt[1], true
	}
	return 0, 0, false
}

func main() {
	apiKey := getAPIKey()
	if apiKey == "" || strings.HasPrefix(apiKey, "REDACTED") {
		log.Println("INFO: No backend Google key needed for drone route; front-end uses browser key.")
	}

	convexCli := newConvexClientFromEnv()
	if convexCli != nil {
		if ports, err := convexCli.fetchDroneports(context.Background()); err == nil && len(ports) > 0 {
			houstonDronePorts = ports
			log.Printf("Loaded %d droneports from Convex", len(ports))
		} else if err != nil {
			log.Printf("WARN: Convex droneports fetch failed: %v (falling back to static list)", err)
		}
	}

	if err := initDB(); err != nil {
		log.Printf("WARN: DB init failed: %v (continuing without persistence)", err)
	}
	initDroneFleets()
	if convexCli != nil {
		startConvexOrderIngest(convexCli, apiKey)
		startFleetSync(convexCli)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]any{"ok": true})
	})

	mux.HandleFunc("/api/route", func(w http.ResponseWriter, r *http.Request) {
		handleRoute(w, r, apiKey)
	})

	mux.HandleFunc("/api/drone-route-async", func(w http.ResponseWriter, r *http.Request) {
		handleDroneRouteAsync(w, r, apiKey)
	})
	mux.HandleFunc("/api/drone-routes", handleListRoutes)
	mux.HandleFunc("/api/drone-route/", handleGetRoute) // trailing slash to catch /api/drone-route/{id}

	mux.HandleFunc("/api/drone-route", func(w http.ResponseWriter, r *http.Request) {
		handleDroneRoute(w, r, apiKey)
	})
	mux.HandleFunc("/api/drone-grid", func(w http.ResponseWriter, r *http.Request) {
		handleDroneGrid(w, r, apiKey)
	})
	mux.HandleFunc("/api/orders", func(w http.ResponseWriter, r *http.Request) {
		handleOrders(w, r, apiKey)
	})

	mux.HandleFunc("/api/drone-ports", handleDronePorts)

	mux.HandleFunc("/api/merchants", handleMerchants)

	mux.HandleFunc("/api/admin/clear", handleAdminClear)

	fs := http.FileServer(http.Dir("public"))
	mux.Handle("/", spa(fs))

	addr := ":8080"
	if p := os.Getenv("PORT"); p != "" {
		addr = ":" + p
	}
	log.Printf("listening on http://0.0.0.0%s\n", addr)
	log.Fatal(http.ListenAndServe(addr, mux))
}

func handleRoute(w http.ResponseWriter, r *http.Request, apiKey string) {
	q := r.URL.Query()
	origin := strings.TrimSpace(q.Get("origin"))
	dest := strings.TrimSpace(q.Get("destination"))
	mode := q.Get("mode")
	if mode == "" {
		mode = "DRIVING"
	}
	if origin == "" || dest == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "origin and destination are required"})
		return
	}
	base := "https://maps.googleapis.com/maps/api/directions/json"
	u, _ := url.Parse(base)
	qs := url.Values{}
	qs.Set("origin", origin)
	qs.Set("destination", dest)
	qs.Set("mode", mode)
	qs.Set("units", "imperial")
	qs.Set("key", apiKey)
	u.RawQuery = qs.Encode()

	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	defer cancel()

	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		writeJSON(w, http.StatusBadGateway, map[string]string{"error": "Failed to reach Google Directions"})
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		writeJSON(w, http.StatusBadGateway, map[string]any{"error": "Google Directions non-200", "status_code": resp.StatusCode})
		return
	}
	body, _ := io.ReadAll(resp.Body)
	var g gDirections
	if err := json.Unmarshal(body, &g); err != nil {
		writeJSON(w, http.StatusBadGateway, map[string]string{"error": "Invalid JSON from Google"})
		return
	}
	if g.Status != "" && g.Status != "OK" {
		writeJSON(w, http.StatusNotFound, map[string]any{"error": "No route found", "google_status": g.Status})
		return
	}
	if len(g.Routes) == 0 || len(g.Routes[0].Legs) == 0 {
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "No route found"})
		return
	}

	route := g.Routes[0]
	leg := route.Legs[0]

	out := apiOut{
		Status:       g.Status,
		DistanceText: leg.Distance.Text,
		DurationText: leg.Duration.Text,
		Polyline:     route.OverviewPolyline.Points,
		Steps:        make([]map[string]string, 0, len(leg.Steps)),
	}
	out.Bounds = map[string]float64{
		"north": route.Bounds.NorthEast.Lat,
		"east":  route.Bounds.NorthEast.Lng,
		"south": route.Bounds.SouthWest.Lat,
		"west":  route.Bounds.SouthWest.Lng,
	}
	for _, s := range leg.Steps {
		out.Steps = append(out.Steps, map[string]string{
			"html_instructions": s.HTMLInstructions,
			"distance_text":     s.Distance.Text,
			"duration_text":     s.Duration.Text,
		})
	}
	writeJSON(w, http.StatusOK, out)
}

type gGeocode struct {
	Status  string `json:"status"`
	Results []struct {
		FormattedAddress string `json:"formatted_address"`
		Geometry         struct {
			Location struct {
				Lat float64 `json:"lat"`
				Lng float64 `json:"lng"`
			} `json:"location"`
		} `json:"geometry"`
	} `json:"results"`
}

func resolveLatLng(ctx context.Context, raw string, apiKey string) (float64, float64, error) {
	if lat, lng, err := parseLatLng(raw); err == nil {
		return lat, lng, nil
	}

	if apiKey == "" || strings.HasPrefix(apiKey, "REDACTED") {
		return 0, 0, fmt.Errorf("backend geocoding requires a server key; set getAPIKey()")
	}

	base := "https://maps.googleapis.com/maps/api/geocode/json"
	u, _ := url.Parse(base)
	qs := url.Values{}

	trim := strings.TrimSpace(raw)
	if strings.HasPrefix(strings.ToLower(trim), "place_id:") {
		qs.Set("place_id", strings.TrimSpace(strings.TrimPrefix(trim, "place_id:")))
	} else {
		qs.Set("address", trim)
	}
	qs.Set("key", apiKey)
	u.RawQuery = qs.Encode()

	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return 0, 0, fmt.Errorf("geocode request failed: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return 0, 0, fmt.Errorf("geocode non-200: %d", resp.StatusCode)
	}
	var g gGeocode
	if err := json.NewDecoder(resp.Body).Decode(&g); err != nil {
		return 0, 0, fmt.Errorf("geocode invalid JSON: %w", err)
	}
	if g.Status != "OK" || len(g.Results) == 0 {
		return 0, 0, fmt.Errorf("geocode not found: %s", g.Status)
	}
	loc := g.Results[0].Geometry.Location
	return loc.Lat, loc.Lng, nil
}

func buildDroneGrid(
	bbox [4]float64,
	fineDeg float64,
	nfzPolys []Polygon,
	nfzCircles []NFZCircle,
	inBand inBandFn,
) *droneGridOut {
	minLat, minLng, maxLat, maxLng := bbox[0], bbox[1], bbox[2], bbox[3]
	nI := int(math.Ceil((maxLat - minLat) / fineDeg))
	nJ := int(math.Ceil((maxLng - minLng) / fineDeg))
	if nI*nJ > 2_000_000 {
		return nil
	}

	indexToLatLng := func(i, j int) (float64, float64) {
		return minLat + float64(i)*fineDeg, minLng + float64(j)*fineDeg
	}

	g := &droneGridOut{
		GridDeg: fineDeg,
		BBox:    bbox,
		NI:      nI,
		NJ:      nJ,
	}

	for i := 0; i <= nI; i++ {
		lat := minLat + float64(i)*fineDeg
		g.LatLines = append(g.LatLines, []float64{lat, minLng, maxLng})
	}
	for j := 0; j <= nJ; j++ {
		lng := minLng + float64(j)*fineDeg
		g.LngLines = append(g.LngLines, []float64{lng, minLat, maxLat})
	}

	isBlocked := func(i, j int) bool {
		lat, lng := indexToLatLng(i, j)

		for _, c := range nfzCircles {
			if haversine(lat, lng, c.Lat, c.Lng) <= c.RadiusM {
				return true
			}
		}
		for _, p := range nfzPolys {
			if pointInPolygon(lng, lat, p) {
				return true
			}
		}
		if inBand != nil && !inBand(lat, lng) {
			return true
		}
		return false
	}

	for i := 0; i < nI; i++ {
		for j := 0; j < nJ; j++ {
			if isBlocked(i, j) {
				swLat, swLng := indexToLatLng(i, j)
				neLat, neLng := swLat+fineDeg, swLng+fineDeg
				g.Blocked = append(g.Blocked, blockedCell{
					SW: node{Lat: swLat, Lng: swLng},
					NE: node{Lat: neLat, Lng: neLng},
				})
			}
		}
	}

	g.NFZCircles = nfzCircles
	for _, p := range nfzPolys {
		g.NFZPolygons = append(g.NFZPolygons, p.Rings)
	}
	return g
}

func summarizeWeatherAlongPath(wx WxSampler, path []node) (avgWindMS, maxGustMS, maxPrecip float64) {
	if wx == nil || len(path) < 2 {
		return 0, 0, 0
	}
	var sumWind float64
	var samples int
	for i := 1; i < len(path); i++ {
		midLat := (path[i-1].Lat + path[i].Lat) / 2
		midLng := (path[i-1].Lng + path[i].Lng) / 2
		wMS, _, gMS, precip, _ := wx.Sample(midLat, midLng)
		sumWind += wMS
		if gMS > maxGustMS {
			maxGustMS = gMS
		}
		if precip > maxPrecip {
			maxPrecip = precip
		}
		samples++
	}
	if samples > 0 {
		avgWindMS = sumWind / float64(samples)
	}
	return
}

func describeWeather(avgWindMS, maxGustMS, maxPrecip float64) string {
	var parts []string
	if avgWindMS > 0 {
		parts = append(parts, fmt.Sprintf("avg wind %.1f m/s", avgWindMS))
	}
	if maxGustMS > 0 {
		parts = append(parts, fmt.Sprintf("gusts up to %.1f m/s", maxGustMS))
	}
	if maxPrecip > 0 {
		switch {
		case maxPrecip >= 0.75:
			parts = append(parts, "thunderstorms likely")
		case maxPrecip >= 0.5:
			parts = append(parts, "snow or heavy precipitation")
		case maxPrecip >= 0.3:
			parts = append(parts, "rain or showers along the route")
		default:
			parts = append(parts, "chance of light precipitation")
		}
	}
	if len(parts) == 0 {
		return "calm / clear conditions along the route"
	}
	return strings.Join(parts, ", ")
}

func computeDroneRoute(
	ctx context.Context,
	origin, destination, apiKey string,
	airspeed, fineM, bandM float64,
	nfzURL string,
	includeGrid bool,
) (*droneRouteOut, error) {

	oLat, oLng, err := resolveLatLng(ctx, origin, apiKey)
	if err != nil {
		return nil, fmt.Errorf("invalid origin: %v", err)
	}
	dLat, dLng, err := resolveLatLng(ctx, destination, apiKey)
	if err != nil {
		return nil, fmt.Errorf("invalid destination: %v", err)
	}

	minLat, maxLat := math.Min(oLat, dLat), math.Max(oLat, dLat)
	minLng, maxLng := math.Min(oLng, dLng), math.Max(oLng, dLng)
	pad := 0.05
	minLat -= pad
	maxLat += pad
	minLng -= pad
	maxLng += pad
	bbox := [4]float64{minLat, minLng, maxLat, maxLng}

	midLat := (oLat + dLat) / 2
	wx, err := newNWSGridSampler(ctx, minLat, minLng, maxLat, maxLng, 3, 3) // 3x3 grid
	if err != nil {
		log.Printf("WARN: NWS sampler failed: %v (default calm)", err)
		wx = &staticWx{windMS: 0, windDir: 0, gustMS: 0, precipPenalty: 0}
	}

	nfzCircles := demoAirportNFZ()
	var nfzPolys []Polygon
	if nfzURL != "" {
		if pgs, err := fetchGeoJSONPolygons(ctx, nfzURL, bbox); err == nil {
			nfzPolys = append(nfzPolys, pgs...)
		} else {
			log.Printf("WARN: nfz_url fetch failed: %v", err)
		}
	}

	coarseDeg := 0.003
	maxExpandCoarse := 60000
	coarsePath, coarseDist, coarseDur, err := planRouteAStar(
		ctx, oLat, oLng, dLat, dLng,
		airspeed, coarseDeg, nfzPolys, nfzCircles, wx, maxExpandCoarse,
	)
	if err != nil {
		return nil, fmt.Errorf("coarse route failed: %v", err)
	}

	if len(coarsePath) > 0 {
		coarsePath[0] = node{Lat: oLat, Lng: oLng}
		coarsePath[len(coarsePath)-1] = node{Lat: dLat, Lng: dLng}
	}

	inBand := makePolylineBand(coarsePath, bandM)

	const mPerDegLat = 111320.0
	fineDegLat := fineM / mPerDegLat
	fineDegLng := fineM / (mPerDegLat * math.Cos(degToRad(midLat)))
	fineDeg := math.Max(fineDegLat, fineDegLng)

	maxExpandFine := 120000
	finePath, distM, durS, err := planRouteAStarCore(
		ctx, oLat, oLng, dLat, dLng,
		airspeed, fineDeg, nfzPolys, nfzCircles, wx, maxExpandFine, inBand,
	)
	if err != nil {
		log.Printf("WARN refine failed: %v; returning coarse", err)

		avgWind, maxGust, maxPrecip := summarizeWeatherAlongPath(wx, coarsePath)
		weatherNote := describeWeather(avgWind, maxGust, maxPrecip)

		out := &droneRouteOut{
			Status:      "OK (coarse-fallback)",
			DistanceM:   coarseDist,
			DurationSec: coarseDur,
			Polyline:    encodePolyline(coarsePath),
			Debug: map[string]any{
				"stage":                "coarse-fallback",
				"coarse_nodes":         len(coarsePath),
				"avg_wind_ms":          avgWind,
				"max_gust_ms":          maxGust,
				"max_precip_penalty":   maxPrecip,
				"weather_note_summary": weatherNote,
			},
			AvgWindMS:   avgWind,
			MaxGustMS:   maxGust,
			MaxPrecip:   maxPrecip,
			WeatherNote: weatherNote,
		}
		if includeGrid {
			grid := buildDroneGrid(bbox, coarseDeg, nfzPolys, nfzCircles, nil)
			out.Grid = grid
		}
		return out, nil
	}

	if len(finePath) > 0 {
		finePath[0] = node{Lat: oLat, Lng: oLng}
		finePath[len(finePath)-1] = node{Lat: dLat, Lng: dLng}
	}

	avgWind, maxGust, maxPrecip := summarizeWeatherAlongPath(wx, finePath)
	weatherNote := describeWeather(avgWind, maxGust, maxPrecip)

	out := &droneRouteOut{
		Status:      "OK",
		DistanceM:   distM,
		DurationSec: durS,
		Polyline:    encodePolyline(finePath),
		Debug: map[string]any{
			"stage":                "refined",
			"coarse_nodes":         len(coarsePath),
			"fine_nodes":           len(finePath),
			"avg_wind_ms":          avgWind,
			"max_gust_ms":          maxGust,
			"max_precip_penalty":   maxPrecip,
			"weather_note_summary": weatherNote,
		},
		AvgWindMS:   avgWind,
		MaxGustMS:   maxGust,
		MaxPrecip:   maxPrecip,
		WeatherNote: weatherNote,
	}

	if includeGrid {
		grid := buildDroneGrid(bbox, fineDeg, nfzPolys, nfzCircles, inBand)
		out.Grid = grid
	}
	return out, nil
}

func computeDroneRouteViaHub(
	ctx context.Context,
	origin, destination, apiKey string,
	airspeed, fineM, bandM float64,
	nfzURL string,
	includeGrid bool,
) (*droneRouteOut, error) {
	if len(houstonDronePorts) == 0 {
		return computeDroneRoute(ctx, origin, destination, apiKey, airspeed, fineM, bandM, nfzURL, includeGrid)
	}

	oLat, oLng, err := resolveLatLng(ctx, origin, apiKey)
	if err != nil {
		return nil, fmt.Errorf("invalid origin: %v", err)
	}
	dLat, dLng, err := resolveLatLng(ctx, destination, apiKey)
	if err != nil {
		return nil, fmt.Errorf("invalid destination: %v", err)
	}

	bestIdx := -1
	bestDist := math.Inf(1)
	for i, p := range houstonDronePorts {
		dist := haversine(dLat, dLng, p.Lat, p.Lng)
		if dist < bestDist {
			bestDist = dist
			bestIdx = i
		}
	}
	if bestIdx < 0 {
		return computeDroneRoute(ctx, origin, destination, apiKey, airspeed, fineM, bandM, nfzURL, includeGrid)
	}
	hub := houstonDronePorts[bestIdx]

	originLL := formatLatLng(oLat, oLng)
	destLL := formatLatLng(dLat, dLng)
	hubLL := formatLatLng(hub.Lat, hub.Lng)

	leg1, err := computeDroneRoute(ctx, hubLL, destLL, apiKey, airspeed, fineM, bandM, nfzURL, false)
	if err != nil {
		return computeDroneRoute(ctx, origin, destination, apiKey, airspeed, fineM, bandM, nfzURL, includeGrid)
	}

	leg2, err := computeDroneRoute(ctx, destLL, originLL, apiKey, airspeed, fineM, bandM, nfzURL, false)
	if err != nil {
		return computeDroneRoute(ctx, origin, destination, apiKey, airspeed, fineM, bandM, nfzURL, includeGrid)
	}

	path1 := decodePolyline(leg1.Polyline)
	path2 := decodePolyline(leg2.Polyline)

	combined := make([]node, 0, len(path1)+len(path2))
	combined = append(combined, path1...)
	if len(path2) > 0 {
		combined = append(combined, path2[1:]...)
	}
	combinedPolyline := encodePolyline(combined)

	totalDist := leg1.DistanceM + leg2.DistanceM
	var avgWind float64
	if totalDist > 0 {
		avgWind = (leg1.AvgWindMS*leg1.DistanceM + leg2.AvgWindMS*leg2.DistanceM) / totalDist
	}
	maxGust := math.Max(leg1.MaxGustMS, leg2.MaxGustMS)
	maxPrecip := math.Max(leg1.MaxPrecip, leg2.MaxPrecip)
	weatherNote := describeWeather(avgWind, maxGust, maxPrecip)

	hubCopy := hub

	out := &droneRouteOut{
		Status:      "OK",
		DistanceM:   leg1.DistanceM + leg2.DistanceM,
		DurationSec: leg1.DurationSec + leg2.DurationSec,
		Polyline:    combinedPolyline,
		Debug: map[string]any{
			"mode":               "via_merchant_hub",
			"hub_id":             hub.ID,
			"hub_name":           hub.Name,
			"hub_lat":            hub.Lat,
			"hub_lng":            hub.Lng,
			"leg1_desc":          "hub -> merchant(destination)",
			"leg2_desc":          "merchant(destination) -> customer(origin)",
			"leg1_distance_m":    leg1.DistanceM,
			"leg2_distance_m":    leg2.DistanceM,
			"leg1_duration_s":    leg1.DurationSec,
			"leg2_duration_s":    leg2.DurationSec,
			"include_grid_ack":   includeGrid,
			"grid_note":          "grid omitted for via-hub route",
			"avg_wind_ms":        avgWind,
			"max_gust_ms":        maxGust,
			"max_precip_penalty": maxPrecip,
			"weather_note":       weatherNote,
		},
		LaunchPort:   &hubCopy,
		MerchantPort: &hubCopy,
		AvgWindMS:    avgWind,
		MaxGustMS:    maxGust,
		MaxPrecip:    maxPrecip,
		WeatherNote:  weatherNote,
	}
	return out, nil
}

func handleDroneRoute(w http.ResponseWriter, r *http.Request, apiKey string) {
	q := r.URL.Query()
	origin := strings.TrimSpace(q.Get("origin"))
	destination := strings.TrimSpace(q.Get("destination"))
	if origin == "" || destination == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "origin and destination are required"})
		return
	}

	airspeed := parseFloatDefault(q.Get("airspeed_ms"), 12.0)
	fineM := parseFloatDefault(q.Get("fine_grid_m"), 6.0)
	bandM := parseFloatDefault(q.Get("band_m"), 150.0)
	includeGrid := strings.EqualFold(q.Get("include_grid"), "1") || strings.EqualFold(q.Get("include_grid"), "true")
	nfzURL := strings.TrimSpace(q.Get("nfz_url"))

	ctx, cancel := context.WithTimeout(r.Context(), 60*time.Second)
	defer cancel()

	result, err := computeDroneRoute(ctx, origin, destination, apiKey, airspeed, fineM, bandM, nfzURL, includeGrid)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, result)
}

func handleDroneRouteAsync(w http.ResponseWriter, r *http.Request, apiKey string) {
	if r.Method != http.MethodPost {
		http.Error(w, "use POST", http.StatusMethodNotAllowed)
		return
	}

	var payload struct {
		Origin      string  `json:"origin"`
		Destination string  `json:"destination"`
		AirspeedMS  float64 `json:"airspeed_ms"`
		FineM       float64 `json:"fine_m"`
		BandM       float64 `json:"band_m"`
		NFZURL      string  `json:"nfz_url"`
		IncludeGrid bool    `json:"include_grid"`
	}
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		http.Error(w, "invalid JSON payload", http.StatusBadRequest)
		return
	}

	id := newUUID()
	if id == "" {
		id = fmt.Sprintf("%d", time.Now().UnixNano())
	}
	ctx, cancel := context.WithCancel(context.Background())

	job := &routeJob{
		ID:        id,
		Origin:    payload.Origin,
		Dest:      payload.Destination,
		Status:    "running",
		StartedAt: time.Now(),
		cancel:    cancel,
	}

	routeMu.Lock()
	routeJobs[id] = job
	routeMu.Unlock()

	go func() {
		defer cancel()
		result, err := computeDroneRoute(ctx, payload.Origin, payload.Destination, apiKey,
			payload.AirspeedMS, payload.FineM, payload.BandM, payload.NFZURL, payload.IncludeGrid)

		routeMu.Lock()
		defer routeMu.Unlock()

		if err != nil {
			job.Status = "error"
			job.Error = err.Error()
		} else {
			job.Status = "done"
			now := time.Now()
			job.Finished = &now
			job.Result = result
		}
	}()

	writeJSON(w, http.StatusAccepted, map[string]string{
		"id":     id,
		"status": "running",
	})
}

func handleListRoutes(w http.ResponseWriter, r *http.Request) {
	routeMu.Lock()
	defer routeMu.Unlock()
	out := make([]*routeJob, 0, len(routeJobs))
	for _, j := range routeJobs {
		out = append(out, j)
	}
	writeJSON(w, http.StatusOK, out)
}

func handleGetRoute(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/api/drone-route/")
	routeMu.Lock()
	defer routeMu.Unlock()
	j, ok := routeJobs[id]
	if !ok {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	writeJSON(w, http.StatusOK, j)
}

type nwsHourly struct {
	Properties struct {
		Periods []struct {
			WindSpeed     string `json:"windSpeed"`
			WindDirection string `json:"windDirection"`
			ShortForecast string `json:"shortForecast"`
			WindGust      string `json:"windGust"`
		} `json:"periods"`
	} `json:"properties"`
}

type staticWx struct {
	windMS, windDir, gustMS, precipPenalty float64
}

func (s *staticWx) Sample(lat, lng float64) (float64, float64, float64, float64, float64) {
	return s.windMS, s.windDir, s.gustMS, s.precipPenalty, 0
}

type nwsSampler struct {
	windMS, windDirDeg, gustMS, precipPenalty float64
}

func newNWSSampler(ctx context.Context, lat, lng float64) (WxSampler, error) {
	pURL := fmt.Sprintf("https://api.weather.gov/points/%.4f,%.4f", lat, lng)
	req, _ := http.NewRequestWithContext(ctx, "GET", pURL, nil)
	req.Header.Set("User-Agent", "DroneRouter/1.0")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("points non-200: %d", resp.StatusCode)
	}
	var pts struct {
		Properties struct {
			ForecastHourly string `json:"forecastHourly"`
		} `json:"properties"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&pts); err != nil {
		return nil, err
	}
	if pts.Properties.ForecastHourly == "" {
		return &staticWx{}, nil
	}
	req2, _ := http.NewRequestWithContext(ctx, "GET", pts.Properties.ForecastHourly, nil)
	req2.Header.Set("User-Agent", "DroneRouter/1.0")
	resp2, err := http.DefaultClient.Do(req2)
	if err != nil {
		return nil, err
	}
	defer resp2.Body.Close()
	if resp2.StatusCode != 200 {
		return nil, fmt.Errorf("forecastHourly non-200: %d", resp2.StatusCode)
	}
	var fc nwsHourly
	if err := json.NewDecoder(resp2.Body).Decode(&fc); err != nil {
		return nil, err
	}
	if len(fc.Properties.Periods) == 0 {
		return &staticWx{}, nil
	}
	p0 := fc.Properties.Periods[0]
	wMS := mphToMS(parseLeadingNumber(p0.WindSpeed))
	gMS := mphToMS(parseLeadingNumber(p0.WindGust))
	dir := parseLeadingNumber(p0.WindDirection)
	precip := 0.0
	sf := strings.ToLower(p0.ShortForecast)
	if strings.Contains(sf, "thunder") {
		precip = 0.8
	}
	if strings.Contains(sf, "snow") {
		precip = 0.5
	}
	if strings.Contains(sf, "rain") || strings.Contains(sf, "showers") {
		precip = math.Max(precip, 0.3)
	}
	return &nwsSampler{
		windMS:        wMS,
		windDirDeg:    dir,
		gustMS:        gMS,
		precipPenalty: precip,
	}, nil
}

func (n *nwsSampler) Sample(lat, lng float64) (float64, float64, float64, float64, float64) {
	return n.windMS, n.windDirDeg, n.gustMS, n.precipPenalty, 0
}

type windVec struct{ u, v float64 }

func dirSpeedToUV(dirFromDeg, speedMS float64) (u, v float64) {
	r := degToRad(dirFromDeg)
	u = -speedMS * math.Sin(r)
	v = -speedMS * math.Cos(r)
	return
}

func uvToDirSpeed(u, v float64) (dirFromDeg, speedMS float64) {
	uFrom, vFrom := -u, -v
	speed := math.Hypot(uFrom, vFrom)
	ang := math.Atan2(uFrom, vFrom)
	dir := math.Mod(radToDeg(ang)+360.0, 360.0)
	return dir, speed
}

type nwsGridSampler struct {
	minLat, minLng float64
	maxLat, maxLng float64
	nx, ny         int

	wind []windVec
	gust []float64
	prec []float64
}

func newNWSGridSampler(ctx context.Context, minLat, minLng, maxLat, maxLng float64, nx, ny int) (WxSampler, error) {
	if nx < 2 {
		nx = 2
	}
	if ny < 2 {
		ny = 2
	}

	s := &nwsGridSampler{
		minLat: minLat, minLng: minLng,
		maxLat: maxLat, maxLng: maxLng,
		nx:   nx,
		ny:   ny,
		wind: make([]windVec, nx*ny),
		gust: make([]float64, nx*ny),
		prec: make([]float64, nx*ny),
	}

	for iy := 0; iy < ny; iy++ {
		t := float64(iy) / float64(ny-1)
		lat := minLat + t*(maxLat-minLat)
		for ix := 0; ix < nx; ix++ {
			sx := float64(ix) / float64(nx-1)
			lng := minLng + sx*(maxLng-minLng)

			wx, err := newNWSSampler(ctx, lat, lng)
			if err != nil {
				continue
			}
			wMS, wDirDeg, gMS, pPen, _ := wx.Sample(lat, lng)
			u, v := dirSpeedToUV(wDirDeg, wMS)

			idx := iy*nx + ix
			s.wind[idx] = windVec{u: u, v: v}
			s.gust[idx] = gMS
			s.prec[idx] = pPen
		}
	}
	return s, nil
}

func (s *nwsGridSampler) Sample(lat, lng float64) (windMS, windDirDeg, gustMS, precipPenalty, crosswindPenalty float64) {
	if s.maxLat == s.minLat || s.maxLng == s.minLng {
		return 0, 0, 0, 0, 0
	}
	tx := (lng - s.minLng) / (s.maxLng - s.minLng)
	ty := (lat - s.minLat) / (s.maxLat - s.minLat)
	if tx < 0 {
		tx = 0
	} else if tx > 1 {
		tx = 1
	}
	if ty < 0 {
		ty = 0
	} else if ty > 1 {
		ty = 1
	}

	fx := tx * float64(s.nx-1)
	fy := ty * float64(s.ny-1)
	ix := int(math.Floor(fx))
	iy := int(math.Floor(fy))
	if ix >= s.nx-1 {
		ix = s.nx - 2
	}
	if iy >= s.ny-1 {
		iy = s.ny - 2
	}
	dx := fx - float64(ix)
	dy := fy - float64(iy)

	idx := func(x, y int) int { return y*s.nx + x }

	w00 := s.wind[idx(ix, iy)]
	w10 := s.wind[idx(ix+1, iy)]
	w01 := s.wind[idx(ix, iy+1)]
	w11 := s.wind[idx(ix+1, iy+1)]

	g00, g10 := s.gust[idx(ix, iy)], s.gust[idx(ix+1, iy)]
	g01, g11 := s.gust[idx(ix, iy+1)], s.gust[idx(ix+1, iy+1)]

	p00, p10 := s.prec[idx(ix, iy)], s.prec[idx(ix+1, iy)]
	p01, p11 := s.prec[idx(ix, iy+1)], s.prec[idx(ix+1, iy+1)]

	u0 := w00.u*(1-dx) + w10.u*dx
	v0 := w00.v*(1-dx) + w10.v*dx
	u1 := w01.u*(1-dx) + w11.u*dx
	v1 := w01.v*(1-dx) + w11.v*dx
	u := u0*(1-dy) + u1*dy
	v := v0*(1-dy) + v1*dy

	g0 := g00*(1-dx) + g10*dx
	g1 := g01*(1-dx) + g11*dx
	g := g0*(1-dy) + g1*dy

	p0 := p00*(1-dx) + p10*dx
	p1 := p01*(1-dx) + p11*dx
	p := p0*(1-dy) + p1*dy

	dir, spd := uvToDirSpeed(u, v)
	return spd, dir, g, p, 0
}

func parseLeadingNumber(s string) float64 {
	tok := ""
	for _, r := range s {
		if (r >= '0' && r <= '9') || r == '.' {
			tok += string(r)
		} else if tok != "" {
			break
		}
	}
	if tok == "" {
		return 0
	}
	v, _ := strconv.ParseFloat(tok, 64)
	return v
}

func mphToMS(v float64) float64 { return v * 0.44704 }

func fetchGeoJSONPolygons(ctx context.Context, rawURL string, bbox [4]float64) ([]Polygon, error) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return nil, err
	}
	req, _ := http.NewRequestWithContext(ctx, "GET", u.String(), nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("nfz_url non-200: %d", resp.StatusCode)
	}
	var gj geoJSON
	if err := json.NewDecoder(resp.Body).Decode(&gj); err != nil {
		return nil, err
	}
	var polys []Polygon
	switch strings.ToLower(gj.Type) {
	case "featurecollection":
		for _, ft := range gj.Features {
			ps := geometryToPolys(ft.Geometry)
			polys = append(polys, ps...)
		}
	case "polygon", "multipolygon":
	}
	return polys, nil
}

func geometryToPolys(g geoJSONGeometry) []Polygon {
	var out []Polygon
	switch strings.ToLower(g.Type) {
	case "polygon":
		if coords, ok := g.Coordinates.([]any); ok {
			rings := make([][][2]float64, 0, len(coords))
			for _, ringAny := range coords {
				ring := ringAny.([]any)
				var rr [][2]float64
				for _, ptAny := range ring {
					xy := ptAny.([]any)
					lng := xy[0].(float64)
					lat := xy[1].(float64)
					rr = append(rr, [2]float64{lng, lat})
				}
				rings = append(rings, rr)
			}
			out = append(out, Polygon{Rings: rings})
		}
	case "multipolygon":
		if polys, ok := g.Coordinates.([]any); ok {
			for _, polyAny := range polys {
				ringsAny := polyAny.([]any)
				var rings [][][2]float64
				for _, ringAny := range ringsAny {
					ring := ringAny.([]any)
					var rr [][2]float64
					for _, ptAny := range ring {
						xy := ptAny.([]any)
						lng := xy[0].(float64)
						lat := xy[1].(float64)
						rr = append(rr, [2]float64{lng, lat})
					}
					rings = append(rings, rr)
				}
				out = append(out, Polygon{Rings: rings})
			}
		}
	}
	return out
}

func demoAirportNFZ() []NFZCircle {
	return []NFZCircle{
		{Lat: 29.9902, Lng: -95.3368, RadiusM: 5556, Label: "KIAH demo"},
		{Lat: 29.6454, Lng: -95.2789, RadiusM: 5556, Label: "KHOU demo"},
	}
}

const (
	fullBatteryMiles   = 70.0
	fullBatteryPercent = 100.0
	dronesPerPort      = 20
	fullChargeDuration = time.Hour
)

func initDroneFleets() {
	fleetMu.Lock()
	defer fleetMu.Unlock()
	droneFleets = make(map[string]*dronePortFleet)
	orderAssignments = make(map[string]*assignedDrone)
	positionsMu.Lock()
	dronePositions = make(map[string][2]float64)
	positionsMu.Unlock()
	for _, dp := range houstonDronePorts {
		fleet := &dronePortFleet{
			Port:   dp,
			Orders: make(map[string]*Drone),
		}
		for i := 1; i <= dronesPerPort; i++ {
			fleet.Ready = append(fleet.Ready, &Drone{
				ID:         fmt.Sprintf("%s-drone-%d", dp.ID, i),
				BatteryPct: fullBatteryPercent,
			})
			positionsMu.Lock()
			dronePositions[fmt.Sprintf("%s-drone-%d", dp.ID, i)] = [2]float64{dp.Lat, dp.Lng}
			positionsMu.Unlock()
		}
		droneFleets[dp.ID] = fleet
	}
}

func getFleet(portID string) (*dronePortFleet, error) {
	fleet, ok := droneFleets[portID]
	if !ok {
		return nil, fmt.Errorf("droneport %s not found", portID)
	}
	return fleet, nil
}

func newMaintenanceDrone(d *Drone) *maintenanceDrone {
	now := time.Now()
	if d.BatteryPct > fullBatteryPercent {
		d.BatteryPct = fullBatteryPercent
	}
	if d.BatteryPct < 0 {
		d.BatteryPct = 0
	}
	missingPct := fullBatteryPercent - d.BatteryPct
	if missingPct < 0 {
		missingPct = 0
	}
	readyAt := now.Add(time.Duration((missingPct / fullBatteryPercent) * float64(fullChargeDuration)))
	// Enforce a minimum dwell time in maintenance so we don't immediately recycle.
	minReady := now.Add(time.Minute)
	if readyAt.Before(minReady) {
		readyAt = minReady
	}
	return &maintenanceDrone{
		Drone:     d,
		readyAt:   readyAt,
		startedAt: now,
		startPct:  d.BatteryPct,
	}
}

func (m *maintenanceDrone) batteryPct(now time.Time) float64 {
	if m == nil {
		return 0
	}
	if !now.Before(m.readyAt) {
		m.Drone.BatteryPct = fullBatteryPercent
		return fullBatteryPercent
	}
	elapsed := now.Sub(m.startedAt)
	gain := (elapsed.Seconds() / fullChargeDuration.Seconds()) * fullBatteryPercent
	pct := m.startPct + gain
	if pct > fullBatteryPercent {
		return fullBatteryPercent
	}
	if pct > m.Drone.BatteryPct {
		m.Drone.BatteryPct = pct
	}
	return pct
}

func pushMaintenanceSorted(fleet *dronePortFleet, d *Drone) {
	if d == nil {
		return
	}
	md := newMaintenanceDrone(d)
	insertIdx := len(fleet.Maintenance)
	for i, existing := range fleet.Maintenance {
		if md.readyAt.Before(existing.readyAt) {
			insertIdx = i
			break
		}
	}
	fleet.Maintenance = append(fleet.Maintenance, md)
	if insertIdx < len(fleet.Maintenance)-1 {
		copy(fleet.Maintenance[insertIdx+1:], fleet.Maintenance[insertIdx:len(fleet.Maintenance)-1])
		fleet.Maintenance[insertIdx] = md
	}
}

func promoteCharged(fleet *dronePortFleet, now time.Time) {
	for len(fleet.Maintenance) > 0 {
		md := fleet.Maintenance[0]
		if now.Before(md.readyAt) {
			break
		}
		fleet.Maintenance = fleet.Maintenance[1:]
		md.Drone.BatteryPct = fullBatteryPercent
		fleet.Ready = append(fleet.Ready, md.Drone)
	}
}

func dispatchDrone(portID string, requiredPct float64) (*Drone, error) {
	fleetMu.Lock()
	defer fleetMu.Unlock()
	fleet, err := getFleet(portID)
	if err != nil {
		return nil, err
	}
	now := time.Now()
	if len(fleet.Ready) == 0 && len(fleet.Maintenance) > 0 {
		promoteCharged(fleet, now)
	}
	if len(fleet.Ready) == 0 {
		return nil, fmt.Errorf("no ready drones at %s", portID)
	}
	d := fleet.Ready[0]
	fleet.Ready = fleet.Ready[1:]
	if d.BatteryPct < requiredPct {
		pushMaintenanceSorted(fleet, d)
		return nil, fmt.Errorf("drone %s insufficient battery (have %.1f%% need %.1f%%)", d.ID, d.BatteryPct, requiredPct)
	}
	d.BatteryPct -= requiredPct
	if d.BatteryPct < 0 {
		d.BatteryPct = 0
	}
	return d, nil
}

func parkDrone(portID string, d *Drone) {
	if d == nil {
		return
	}
	fleetMu.Lock()
	defer fleetMu.Unlock()
	fleet, err := getFleet(portID)
	if err != nil {
		return
	}
	if d.BatteryPct >= fullBatteryPercent {
		fleet.Ready = append(fleet.Ready, d)
	} else {
		pushMaintenanceSorted(fleet, d)
	}
}

func rememberAssignment(orderID, portID string, d *Drone) {
	fleetMu.Lock()
	defer fleetMu.Unlock()
	orderAssignments[orderID] = &assignedDrone{PortID: portID, Drone: d}
}

func releaseAssignment(orderID string) *assignedDrone {
	fleetMu.Lock()
	defer fleetMu.Unlock()
	if assign, ok := orderAssignments[orderID]; ok {
		delete(orderAssignments, orderID)
		fleet := droneFleets[assign.PortID]
		if fleet != nil {
			assign.Drone.BatteryPct = fullBatteryPercent
			fleet.Ready = append(fleet.Ready, assign.Drone)
		}
		return assign
	}
	return nil
}

func readyCount(portID string) int {
	fleetMu.Lock()
	defer fleetMu.Unlock()
	if f := droneFleets[portID]; f != nil {
		if len(f.Maintenance) > 0 {
			promoteCharged(f, time.Now())
		}
		return len(f.Ready)
	}
	return 0
}

func findAndDispatchDrone(
	ctx context.Context,
	candidates []DronePort,
	merchantLat, merchantLng float64,
	customerAddr string,
	apiKey string,
) (*DronePort, *Drone, *droneRouteOut, *droneRouteOut, float64, error) {
	const sleepInterval = 2 * time.Second

	// Evaluate closer droneports first so we don't always pick the first entry.
	sortedCandidates := make([]DronePort, len(candidates))
	copy(sortedCandidates, candidates)
	sort.Slice(sortedCandidates, func(i, j int) bool {
		return haversine(merchantLat, merchantLng, sortedCandidates[i].Lat, sortedCandidates[i].Lng) <
			haversine(merchantLat, merchantLng, sortedCandidates[j].Lat, sortedCandidates[j].Lng)
	})

	for {
		for _, dp := range sortedCandidates {
			if readyCount(dp.ID) == 0 {
				continue
			}

			origin1 := formatLatLng(dp.Lat, dp.Lng)
			origin2 := formatLatLng(merchantLat, merchantLng)

			leg1, err := computeDroneRoute(ctx, origin1, origin2, apiKey, 12, 6, 150, "", false)
			if err != nil {
				continue
			}
			leg2, err := computeDroneRoute(ctx, origin2, customerAddr, apiKey, 12, 6, 150, "", false)
			if err != nil {
				continue
			}

			totalDistMiles := (leg1.DistanceM + leg2.DistanceM) * 0.000621371
			requiredPct := (totalDistMiles / fullBatteryMiles) * 100.0
			if requiredPct > fullBatteryPercent {
				continue
			}

			dr, derr := dispatchDrone(dp.ID, requiredPct)
			if derr != nil {
				continue
			}
			return &dp, dr, leg1, leg2, requiredPct, nil
		}

		select {
		case <-ctx.Done():
			return nil, nil, nil, nil, 0, ctx.Err()
		case <-time.After(sleepInterval):
		}
	}
}

var houstonDronePorts = []DronePort{
	{
		ID:   "hou-downtown",
		Name: "Downtown Hub",
		Lat:  29.7604,
		Lng:  -95.3698,
	},
	{
		ID:   "hou-heights",
		Name: "Houston Heights Port",
		Lat:  29.7980,
		Lng:  -95.3980,
	},
	{
		ID:   "hou-med-center",
		Name: "Texas Medical Center Port",
		Lat:  29.7099,
		Lng:  -95.4010,
	},
	{
		ID:   "hou-galleria",
		Name: "Uptown / Galleria Port",
		Lat:  29.7407,
		Lng:  -95.4639,
	},
	{
		ID:   "hou-energy-corridor",
		Name: "Energy Corridor West Port",
		Lat:  29.7875,
		Lng:  -95.6433,
	},
	{
		ID:   "hou-alief",
		Name: "Alief Southwest Port",
		Lat:  29.7110,
		Lng:  -95.5960,
	},
	{
		ID:   "hou-magnolia-park",
		Name: "Magnolia Park East End Port",
		Lat:  29.7320,
		Lng:  -95.2920,
	},
	{
		ID:   "hou-clear-lake",
		Name: "Clear Lake Southeast Port",
		Lat:  29.5552,
		Lng:  -95.1152,
	},
	{
		ID:   "hou-greenspoint",
		Name: "Greenspoint North Port",
		Lat:  29.9451,
		Lng:  -95.4116,
	},
	{
		ID:   "hou-kingwood",
		Name: "Kingwood Northeast Port",
		Lat:  30.0340,
		Lng:  -95.2610,
	},
}

func selectConvexCustomerAddress(ord convexOrder) string {
	if ord.DeliveryLat != nil && ord.DeliveryLng != nil {
		return formatLatLng(*ord.DeliveryLat, *ord.DeliveryLng)
	}
	return strings.TrimSpace(ord.DeliveryAddressText)
}

func merchantLatLng(ctx context.Context, m *convexMerchant, apiKey string) (float64, float64, string, error) {
	if m == nil {
		return 0, 0, "", fmt.Errorf("missing merchant details")
	}
	addr := strings.TrimSpace(m.Address)
	if addr == "" {
		addr = strings.TrimSpace(m.Name)
	}
	if m.Lat != nil && m.Lng != nil {
		return *m.Lat, *m.Lng, addr, nil
	}
	if addr == "" {
		return 0, 0, "", fmt.Errorf("merchant address unavailable")
	}
	lat, lng, err := resolveLatLng(ctx, addr, apiKey)
	return lat, lng, addr, err
}

func startConvexOrderIngest(cli *convexClient, apiKey string) {
	if cli == nil {
		return
	}

	runOnce := func() {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		orders, err := cli.fetchOrders(ctx, 5)
		cancel()
		if err != nil {
			log.Printf("WARN: Convex order pull failed: %v", err)
			return
		}
		for _, ord := range orders {
			go processConvexOrder(cli, ord, apiKey)
		}
	}

	runOnce()
	go func() {
		ticker := time.NewTicker(12 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			runOnce()
		}
	}()
}

func startFleetSync(cli *convexClient) {
	if cli == nil {
		return
	}
	go func() {
		ticker := time.NewTicker(12 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			drs := buildFleetSnapshot()
			if err := cli.sendFleetSnapshot(ctx, drs); err != nil {
				log.Printf("WARN: fleet snapshot push failed: %v", err)
			}
			cancel()
		}
	}()
}

func buildFleetSnapshot() []convexFleetDrone {
	fleetMu.Lock()
	defer fleetMu.Unlock()
	now := time.Now()
	_ = now
	var out []convexFleetDrone

	for _, fleet := range droneFleets {
		dp := fleet.Port
		promoteCharged(fleet, now)
		for _, d := range fleet.Ready {
			lat, lng, _ := getDronePosition(d.ID)
			out = append(out, convexFleetDrone{
				Code:        d.ID,
				DroneportID: dp.ID,
				Droneport:   dp.Name,
				Status:      "idle",
				BatteryPct:  d.BatteryPct,
				AtDroneport: true,
				Lat:         lat,
				Lng:         lng,
			})
		}
		for _, md := range fleet.Maintenance {
			lat, lng, _ := getDronePosition(md.Drone.ID)
			out = append(out, convexFleetDrone{
				Code:        md.Drone.ID,
				DroneportID: dp.ID,
				Droneport:   dp.Name,
				Status:      "maintenance",
				BatteryPct:  md.batteryPct(now),
				AtDroneport: true,
				Lat:         lat,
				Lng:         lng,
			})
		}
	}

	for orderID, assign := range orderAssignments {
		lat, lng, _ := getDronePosition(assign.Drone.ID)
		out = append(out, convexFleetDrone{
			Code:         assign.Drone.ID,
			DroneportID:  assign.PortID,
			Status:       "in-flight",
			BatteryPct:   assign.Drone.BatteryPct,
			AtDroneport:  false,
			CurrentOrder: orderID,
			Lat:          lat,
			Lng:          lng,
		})
	}

	return out
}

func simulateDeliveryLifecycle(cli *convexClient, orderID string, dp *DronePort, dr *Drone, merchantLat, merchantLng float64, leg1, leg2, retRoute *droneRouteOut) {
	if cli == nil {
		return
	}

	ctx := context.Background()
	leg1Dur := time.Duration(leg1.DurationSec * float64(time.Second))
	if leg1Dur < time.Second {
		leg1Dur = 3 * time.Second
	}
	time.Sleep(leg1Dur)
	setDronePosition(dr.ID, merchantLat, merchantLng)
	if err := cli.reportRoute(ctx, convexRouteResult{
		OrderID:         orderID,
		DroneportID:     dp.ID,
		DroneportName:   dp.Name,
		DroneID:         dr.ID,
		RoutingStatus:   "waiting_load",
		Leg1CompletedAt: time.Now().UnixMilli(),
	}); err != nil {
		log.Printf("WARN: Convex route progress (waiting_load) failed for %s: %v", orderID, err)
	}

	// Wait for load confirmation from Convex
	loadCtx, loadCancel := context.WithTimeout(context.Background(), 30*time.Minute)
	defer loadCancel()
	for {
		confirmed, err := cli.checkLoadStatus(loadCtx, orderID)
		if err == nil && confirmed {
			break
		}
		select {
		case <-loadCtx.Done():
			return
		case <-time.After(4 * time.Second):
		}
	}

	now := time.Now()
	if err := cli.reportRoute(ctx, convexRouteResult{
		OrderID:         orderID,
		DroneportID:     dp.ID,
		DroneportName:   dp.Name,
		DroneID:         dr.ID,
		RoutingStatus:   "enroute_customer",
		Leg2StartedAt:   now.UnixMilli(),
		Leg2DurationS:   leg2.DurationSec,
		LoadConfirmedAt: now.UnixMilli(),
	}); err != nil {
		log.Printf("WARN: Convex route progress (enroute_customer) failed for %s: %v", orderID, err)
	}

	leg2Dur := time.Duration(leg2.DurationSec * float64(time.Second))
	if leg2Dur < time.Second {
		leg2Dur = 3 * time.Second
	}
	time.Sleep(leg2Dur)

	if pts := decodePolyline(leg2.Polyline); len(pts) > 0 {
		last := pts[len(pts)-1]
		setDronePosition(dr.ID, last.Lat, last.Lng)
	}

	if err := cli.reportRoute(ctx, convexRouteResult{
		OrderID:             orderID,
		DroneportID:         dp.ID,
		DroneportName:       dp.Name,
		DroneID:             dr.ID,
		RoutingStatus:       "delivered",
		DeliveredAt:         time.Now().UnixMilli(),
		BatteryRemainingPct: dr.BatteryPct,
	}); err != nil {
		log.Printf("WARN: Convex route progress (delivered) failed for %s: %v", orderID, err)
	}

	// Plan return leg back to the launch droneport; keep the drone unavailable until it lands.
	if retRoute == nil {
		customerLat, customerLng := dp.Lat, dp.Lng
		if pts := decodePolyline(leg2.Polyline); len(pts) > 0 {
			last := pts[len(pts)-1]
			customerLat, customerLng = last.Lat, last.Lng
		}

		apiKey := getAPIKey()
		var err error
		retRoute, err = computeDroneRoute(
			ctx,
			formatLatLng(customerLat, customerLng),
			formatLatLng(dp.Lat, dp.Lng),
			apiKey,
			12,
			6,
			150,
			"",
			false,
		)
		if err != nil {
			log.Printf("WARN: return route failed for %s: %v (teleporting to port)", orderID, err)
			releaseAssignment(orderID)
			parkDrone(dp.ID, dr)
			setDronePosition(dr.ID, dp.Lat, dp.Lng)
			return
		}
	}

	returnStart := time.Now()
	if err := cli.reportRoute(ctx, convexRouteResult{
		OrderID:             orderID,
		DroneportID:         dp.ID,
		DroneportName:       dp.Name,
		DroneID:             dr.ID,
		RoutingStatus:       "enroute_return",
		ReturnPolyline:      retRoute.Polyline,
		ReturnDurationS:     retRoute.DurationSec,
		ReturnStartedAt:     returnStart.UnixMilli(),
		BatteryRemainingPct: dr.BatteryPct,
	}); err != nil {
		log.Printf("WARN: Convex route progress (enroute_return) failed for %s: %v", orderID, err)
	}

	// Consume battery for the return leg; keep non-negative.
	retMiles := retRoute.DistanceM * 0.000621371
	retPct := (retMiles / fullBatteryMiles) * 100.0
	dr.BatteryPct -= retPct
	if dr.BatteryPct < 0 {
		dr.BatteryPct = 0
	}

	retDur := time.Duration(retRoute.DurationSec * float64(time.Second))
	if retDur < time.Second {
		retDur = 3 * time.Second
	}
	time.Sleep(retDur)
	setDronePosition(dr.ID, dp.Lat, dp.Lng)

	if err := cli.reportRoute(ctx, convexRouteResult{
		OrderID:             orderID,
		DroneportID:         dp.ID,
		DroneportName:       dp.Name,
		DroneID:             dr.ID,
		RoutingStatus:       "returned",
		ReturnCompletedAt:   time.Now().UnixMilli(),
		ReturnPolyline:      retRoute.Polyline,
		ReturnDurationS:     retRoute.DurationSec,
		BatteryRemainingPct: dr.BatteryPct,
	}); err != nil {
		log.Printf("WARN: Convex route progress (returned) failed for %s: %v", orderID, err)
	}

	releaseAssignment(orderID)
	parkDrone(dp.ID, dr)
}

func processConvexOrder(cli *convexClient, ord convexOrder, apiKey string) {
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()

	merchantLat, merchantLng, merchantAddr, err := merchantLatLng(ctx, ord.Merchant, apiKey)
	if err != nil {
		_ = cli.reportRoute(ctx, convexRouteResult{
			OrderID: ord.ID,
			Error:   fmt.Sprintf("merchant lookup failed: %v", err),
		})
		return
	}

	customerAddr := selectConvexCustomerAddress(ord)
	if customerAddr == "" {
		_ = cli.reportRoute(ctx, convexRouteResult{
			OrderID: ord.ID,
			Error:   "missing delivery address",
		})
		return
	}

	dp, dr, leg1, leg2, requiredPct, ferr := findAndDispatchDrone(ctx, houstonDronePorts, merchantLat, merchantLng, customerAddr, apiKey)
	if ferr != nil {
		res := convexRouteResult{
			OrderID:             ord.ID,
			Error:               ferr.Error(),
			CustomerAddressText: customerAddr,
		}
		if ord.Merchant != nil {
			res.Merchant = &convexMerchant{
				ID:      ord.Merchant.ID,
				Name:    ord.Merchant.Name,
				Address: merchantAddr,
			}
		}
		_ = cli.reportRoute(ctx, res)
		return
	}
	rememberAssignment(ord.ID, dp.ID, dr)
	setDronePosition(dr.ID, dp.Lat, dp.Lng)

	// Pre-compute return leg so UIs can render it immediately.
	retRoute, retErr := computeDroneRoute(
		ctx,
		customerAddr,
		formatLatLng(dp.Lat, dp.Lng),
		apiKey,
		12,
		6,
		150,
		"",
		false,
	)
	if retErr != nil {
		log.Printf("WARN: return route precompute failed for %s: %v", ord.ID, retErr)
		retRoute = &droneRouteOut{
			Status:      "stub",
			DistanceM:   haversine(merchantLat, merchantLng, dp.Lat, dp.Lng),
			DurationSec: 60,
			Polyline:    leg1.Polyline,
		}
	}

	result := convexRouteResult{
		OrderID:             ord.ID,
		DroneportID:         dp.ID,
		DroneportName:       dp.Name,
		DroneportLat:        &dp.Lat,
		DroneportLng:        &dp.Lng,
		Leg1Polyline:        leg1.Polyline,
		Leg2Polyline:        leg2.Polyline,
		ReturnPolyline:      retRoute.Polyline,
		ReturnDurationS:     retRoute.DurationSec,
		DistanceM:           leg1.DistanceM + leg2.DistanceM + retRoute.DistanceM,
		DurationS:           leg1.DurationSec + leg2.DurationSec + retRoute.DurationSec,
		Leg1DurationS:       leg1.DurationSec,
		Leg2DurationS:       leg2.DurationSec,
		DroneID:             dr.ID,
		BatteryUsedPct:      requiredPct,
		BatteryRemainingPct: dr.BatteryPct,
		CustomerAddressText: customerAddr,
		RoutingStatus:       "enroute_merchant",
	}
	if ord.Merchant != nil {
		result.Merchant = &convexMerchant{
			ID:      ord.Merchant.ID,
			Name:    ord.Merchant.Name,
			Address: merchantAddr,
			Lat:     &merchantLat,
			Lng:     &merchantLng,
		}
	}

	if err := cli.reportRoute(ctx, result); err != nil {
		log.Printf("WARN: Convex route report failed for order %s: %v", ord.ID, err)
	}

	go simulateDeliveryLifecycle(cli, ord.ID, dp, dr, merchantLat, merchantLng, leg1, leg2, retRoute)
}

func handleDronePorts(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Allow", http.MethodGet)
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if db != nil {
		dbMu.Lock()
		rows, err := db.Query(`SELECT id,name,lat,lng FROM droneports ORDER BY name LIMIT 500`)
		dbMu.Unlock()
		if err == nil {
			defer rows.Close()
			var ports []DronePort
			for rows.Next() {
				var dp DronePort
				if err := rows.Scan(&dp.ID, &dp.Name, &dp.Lat, &dp.Lng); err == nil {
					ports = append(ports, dp)
				}
			}
			if len(ports) > 0 {
				writeJSON(w, http.StatusOK, ports)
				return
			}
		} else {
			log.Printf("WARN: droneports query failed: %v", err)
		}
	}
	writeJSON(w, http.StatusOK, houstonDronePorts)
}

func handleMerchants(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Allow", http.MethodGet)
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if db == nil {
		writeJSON(w, http.StatusOK, []map[string]any{})
		return
	}
	dbMu.Lock()
	rows, err := db.Query(`SELECT name,address,lat,lng FROM merchants ORDER BY updated_at DESC LIMIT 500`)
	dbMu.Unlock()
	if err != nil {
		log.Printf("WARN: merchants query failed: %v", err)
		http.Error(w, "db query failed", http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	type merch struct {
		ID      string  `json:"id"`
		Name    string  `json:"name"`
		Address string  `json:"address"`
		Lat     float64 `json:"lat"`
		Lng     float64 `json:"lng"`
	}
	var out []merch
	for rows.Next() {
		var m merch
		if err := rows.Scan(&m.Name, &m.Address, &m.Lat, &m.Lng); err == nil {
			m.ID = m.Name
			out = append(out, m)
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func handleAdminClear(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if db == nil {
		http.Error(w, "persistence disabled (no MYSQL_DSN)", http.StatusServiceUnavailable)
		return
	}
	tables := []string{"orders", "merchants", "droneports", "customers"}
	dbMu.Lock()
	defer dbMu.Unlock()
	for _, tbl := range tables {
		if _, err := db.Exec("DELETE FROM " + tbl); err != nil {
			http.Error(w, "failed to clear "+tbl, http.StatusInternalServerError)
			return
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"cleared": tables})
}

type node struct{ Lat, Lng float64 }

type aStarNode struct {
	I, J int
	G    float64
	H    float64
	F    float64
}

func parseKey(k string) (int, int, error) {
	parts := strings.Split(k, ",")
	if len(parts) != 2 {
		return 0, 0, fmt.Errorf("bad key")
	}
	ii, err1 := strconv.Atoi(parts[0])
	jj, err2 := strconv.Atoi(parts[1])
	if err1 != nil || err2 != nil {
		return 0, 0, fmt.Errorf("bad key")
	}
	return ii, jj, nil
}

type inBandFn func(lat, lng float64) bool

func makePolylineBand(path []node, bandWidthM float64) inBandFn {
	if len(path) < 2 || bandWidthM <= 0 {
		return nil
	}
	var sumLat, sumLng float64
	for _, p := range path {
		sumLat += p.Lat
		sumLng += p.Lng
	}
	lat0 := sumLat / float64(len(path))
	lng0 := sumLng / float64(len(path))

	const mPerDegLat = 111320.0
	mPerDegLng := mPerDegLat * math.Cos(degToRad(lat0))

	toXY := func(lat, lng float64) (float64, float64) {
		x := (lng - lng0) * mPerDegLng
		y := (lat - lat0) * mPerDegLat
		return x, y
	}
	segs := make([][4]float64, 0, len(path)-1)
	for i := 1; i < len(path); i++ {
		x1, y1 := toXY(path[i-1].Lat, path[i-1].Lng)
		x2, y2 := toXY(path[i].Lat, path[i].Lng)
		segs = append(segs, [4]float64{x1, y1, x2, y2})
	}

	bw2 := bandWidthM * bandWidthM

	dist2ToSeg := func(px, py, x1, y1, x2, y2 float64) float64 {
		vx, vy := x2-x1, y2-y1
		wx, wy := px-x1, py-y1
		denom := vx*vx + vy*vy
		var t float64
		if denom <= 1e-9 {
			t = 0
		} else {
			t = (wx*vx + wy*vy) / denom
			if t < 0 {
				t = 0
			} else if t > 1 {
				t = 1
			}
		}
		cx, cy := x1+t*vx, y1+t*vy
		dx, dy := px-cx, py-cy
		return dx*dx + dy*dy
	}

	return func(lat, lng float64) bool {
		px, py := toXY(lat, lng)
		ex1, ey1 := toXY(path[0].Lat, path[0].Lng)
		dx, dy := px-ex1, py-ey1
		if dx*dx+dy*dy <= bw2 {
			return true
		}
		ex2, ey2 := toXY(path[len(path)-1].Lat, path[len(path)-1].Lng)
		dx, dy = px-ex2, py-ey2
		if dx*dx+dy*dy <= bw2 {
			return true
		}

		for _, s := range segs {
			if dist2ToSeg(px, py, s[0], s[1], s[2], s[3]) <= bw2 {
				return true
			}
		}
		return false
	}
}

func planRouteAStar(
	ctx context.Context,
	oLat, oLng, dLat, dLng, airspeedMS, stepDeg float64,
	nfzPolys []Polygon, nfzCircles []NFZCircle,
	wx WxSampler, maxExpand int,
) ([]node, float64, float64, error) {
	return planRouteAStarCore(
		ctx, oLat, oLng, dLat, dLng, airspeedMS, stepDeg,
		nfzPolys, nfzCircles, wx, maxExpand, nil,
	)
}

func planRouteAStarCore(
	ctx context.Context,
	oLat, oLng, dLat, dLng, airspeedMS, stepDeg float64,
	nfzPolys []Polygon, nfzCircles []NFZCircle,
	wx WxSampler, maxExpand int,
	inBand inBandFn,
) ([]node, float64, float64, error) {

	minLat, maxLat := math.Min(oLat, dLat), math.Max(oLat, dLat)
	minLng, maxLng := math.Min(oLng, dLng), math.Max(oLng, dLng)
	pad := 0.05
	minLat -= pad
	maxLat += pad
	minLng -= pad
	maxLng += pad

	if stepDeg <= 0 {
		return nil, 0, 0, fmt.Errorf("step_deg must be > 0")
	}
	nI := int(math.Ceil((maxLat - minLat) / stepDeg))
	nJ := int(math.Ceil((maxLng - minLng) / stepDeg))
	if nI <= 0 || nJ <= 0 {
		return nil, 0, 0, fmt.Errorf("grid too small")
	}
	if nI*nJ > 2_000_000 {
		return nil, 0, 0, fmt.Errorf("grid too large; increase step_deg")
	}

	indexToLatLng := func(i, j int) (float64, float64) {
		return minLat + float64(i)*stepDeg, minLng + float64(j)*stepDeg
	}
	key := func(i, j int) string { return fmt.Sprintf("%d,%d", i, j) }
	clamp := func(v, lo, hi int) int {
		if v < lo {
			return lo
		}
		if v > hi {
			return hi
		}
		return v
	}
	isBlocked := func(i, j int) bool {
		lat, lng := indexToLatLng(i, j)
		for _, c := range nfzCircles {
			if haversine(lat, lng, c.Lat, c.Lng) <= c.RadiusM {
				return true
			}
		}
		for _, p := range nfzPolys {
			if pointInPolygon(lng, lat, p) {
				return true
			}
		}
		if inBand != nil && !inBand(lat, lng) {
			return true
		}
		return false
	}

	startI := int(math.Round((oLat - minLat) / stepDeg))
	startJ := int(math.Round((oLng - minLng) / stepDeg))
	goalI := int(math.Round((dLat - minLat) / stepDeg))
	goalJ := int(math.Round((dLng - minLng) / stepDeg))
	startI = clamp(startI, 0, nI)
	startJ = clamp(startJ, 0, nJ)
	goalI = clamp(goalI, 0, nI)
	goalJ = clamp(goalJ, 0, nJ)

	if isBlocked(startI, startJ) || isBlocked(goalI, goalJ) {
		return nil, 0, 0, errors.New("start or goal inside no-fly area or outside refinement band")
	}

	open := map[string]*aStarNode{}
	closed := map[string]bool{}
	cameFrom := map[string]string{}
	gScore := map[string]float64{}
	pq := newMinHeap()

	wMS, _, _, _, _ := wx.Sample((oLat+dLat)/2, (oLng+dLng)/2)
	optimisticGround := airspeedMS + math.Min(5, wMS)
	if optimisticGround < 3 {
		optimisticGround = 3
	}
	h := func(i, j int) float64 {
		lat, lng := indexToLatLng(i, j)
		dm := haversine(lat, lng, dLat, dLng)
		return dm / optimisticGround
	}

	startKey := key(startI, startJ)
	goalKey := key(goalI, goalJ)

	start := &aStarNode{I: startI, J: startJ, G: 0, H: h(startI, startJ)}
	start.F = start.G + start.H
	open[startKey] = start
	gScore[startKey] = 0
	cameFrom[startKey] = "" // root
	pq.push(start.F, startKey)

	expand := 0
	found := false

	getLatLngByKey := func(k string) (float64, float64) {
		ii, jj, err := parseKey(k)
		if err != nil {
			return 0, 0
		}
		return indexToLatLng(ii, jj)
	}

	approxCellM := 111320.0 * stepDeg

	for pq.len() > 0 {
		select {
		case <-ctx.Done():
			return nil, 0, 0, ctx.Err()
		default:
		}

		if expand > maxExpand {
			return nil, 0, 0, errors.New("search cap reached; widen step_deg or reduce distance")
		}
		expand++

		curKey := pq.pop()
		cur, ok := open[curKey]
		if !ok {
			continue
		}
		if curKey == goalKey {
			found = true
			break
		}
		delete(open, curKey)
		closed[curKey] = true

		for di := -1; di <= 1; di++ {
			for dj := -1; dj <= 1; dj++ {
				if di == 0 && dj == 0 {
					continue
				}
				ni, nj := cur.I+di, cur.J+dj
				if ni < 0 || nj < 0 || ni > nI || nj > nJ {
					continue
				}
				nk := key(ni, nj)
				if closed[nk] {
					continue
				}

				if isBlocked(ni, nj) {
					continue
				}

				costViaCur := edgeCost(indexToLatLng, cur.I, cur.J, ni, nj, airspeedMS, wx)
				gBest := cur.G + costViaCur
				parentBest := curKey

				if pKey := cameFrom[curKey]; pKey != "" {
					plat, plng := getLatLngByKey(pKey)
					nlat, nlng := indexToLatLng(ni, nj)
					if lineOfSight(plat, plng, nlat, nlng, nfzPolys, nfzCircles, inBand, math.Max(1.0, approxCellM*0.5)) {
						if gP, ok := gScore[pKey]; ok {
							costPN := edgeCostLatLng(plat, plng, nlat, nlng, airspeedMS, wx)
							if gP+costPN < gBest {
								gBest = gP + costPN
								parentBest = pKey
							}
						}
					}
				}

				if oldG, seen := gScore[nk]; seen && gBest >= oldG {
					continue
				}

				gScore[nk] = gBest
				n := &aStarNode{I: ni, J: nj, G: gBest, H: h(ni, nj)}
				n.F = n.G + n.H
				open[nk] = n
				cameFrom[nk] = parentBest
				pq.push(n.F, nk)
			}
		}
	}

	if !found {
		return nil, 0, 0, errors.New("no path found")
	}

	var pathIJ [][2]int
	for at := goalKey; at != ""; at = cameFrom[at] {
		ii, jj, err := parseKey(at)
		if err != nil {
			break
		}
		pathIJ = append(pathIJ, [2]int{ii, jj})
	}
	for i := 0; i < len(pathIJ)/2; i++ {
		j := len(pathIJ) - 1 - i
		pathIJ[i], pathIJ[j] = pathIJ[j], pathIJ[i]
	}

	raw := make([]node, 0, len(pathIJ))
	for i := 0; i < len(pathIJ); i++ {
		lat, lng := indexToLatLng(pathIJ[i][0], pathIJ[i][1])
		raw = append(raw, node{Lat: lat, Lng: lng})
	}

	smoothed := raw

	var distM float64
	var durS float64
	for i := 1; i < len(smoothed); i++ {
		distM += haversine(smoothed[i-1].Lat, smoothed[i-1].Lng, smoothed[i].Lat, smoothed[i].Lng)
		durS += edgeCostLatLng(smoothed[i-1].Lat, smoothed[i-1].Lng, smoothed[i].Lat, smoothed[i].Lng, airspeedMS, wx)
	}

	return smoothed, distM, durS, nil
}

func lineOfSight(
	lat0, lng0, lat1, lng1 float64,
	nfzPolys []Polygon, nfzCircles []NFZCircle,
	inBand inBandFn, stepM float64,
) bool {
	if stepM <= 0 {
		stepM = 2.0
	}
	dist := haversine(lat0, lng0, lat1, lng1)
	if dist == 0 {
		return true
	}
	steps := int(math.Ceil(dist / stepM))
	for s := 0; s <= steps; s++ {
		t := float64(s) / float64(steps)
		lat := lat0 + t*(lat1-lat0)
		lng := lng0 + t*(lng1-lng0)

		if inBand != nil && !inBand(lat, lng) {
			return false
		}
		for _, c := range nfzCircles {
			if haversine(lat, lng, c.Lat, c.Lng) <= c.RadiusM {
				return false
			}
		}
		for _, p := range nfzPolys {
			if pointInPolygon(lng, lat, p) {
				return false
			}
		}
	}
	return true
}

func edgeCost(indexToLatLng func(i, j int) (float64, float64), i0, j0, i1, j1 int, airspeed float64, wx WxSampler) float64 {
	lat0, lng0 := indexToLatLng(i0, j0)
	lat1, lng1 := indexToLatLng(i1, j1)
	return edgeCostLatLng(lat0, lng0, lat1, lng1, airspeed, wx)
}

func edgeCostLatLng(lat0, lng0, lat1, lng1, airspeed float64, wx WxSampler) float64 {
	dm := haversine(lat0, lng0, lat1, lng1)
	if dm == 0 {
		return 0
	}
	brg := bearing(lat0, lng0, lat1, lng1)
	wMS, wDirDeg, gustMS, precipPenalty, _ := wx.Sample((lat0+lat1)/2, (lng0+lng1)/2)
	rel := degDiff(wDirDeg, brg)
	tail := -wMS * math.Cos(degToRad(rel))
	ground := airspeed + tail
	if ground < 3 {
		ground = 3
	}
	baseTime := dm / ground
	gustPen := 0.0
	if gustMS > 6 {
		gustPen += 0.2
	}
	if gustMS > 10 {
		gustPen += 0.3
	}
	cw := math.Abs(wMS * math.Sin(degToRad(rel)))
	cwPen := 0.0
	if cw > 5 {
		cwPen += 0.25
	}
	if cw > 8 {
		cwPen += 0.3
	}

	return baseTime * (1.0 + precipPenalty + gustPen + cwPen)
}

func haversine(lat1, lng1, lat2, lng2 float64) float64 {
	const R = 6371000.0
	phi1 := degToRad(lat1)
	phi2 := degToRad(lat2)
	dphi := degToRad(lat2 - lat1)
	dlam := degToRad(lng2 - lng1)
	a := math.Sin(dphi/2)*math.Sin(dphi/2) + math.Cos(phi1)*math.Cos(phi2)*math.Sin(dlam/2)*math.Sin(dlam/2)
	c := 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))
	return R * c
}

func bearing(lat1, lng1, lat2, lng2 float64) float64 {
	phi1 := degToRad(lat1)
	phi2 := degToRad(lat2)
	dlam := degToRad(lng2 - lng1)
	y := math.Sin(dlam) * math.Cos(phi2)
	x := math.Cos(phi1)*math.Sin(phi2) - math.Sin(phi1)*math.Cos(phi2)*math.Cos(dlam)
	brg := math.Atan2(y, x)
	deg := radToDeg(brg)
	return math.Mod(deg+360.0, 360.0)
}

func degToRad(d float64) float64 { return d * math.Pi / 180.0 }
func radToDeg(r float64) float64 { return r * 180.0 / math.Pi }
func degDiff(a, b float64) float64 {
	d := math.Mod(a-b+540, 360) - 180
	return d
}

func pointInPolygon(lng, lat float64, poly Polygon) bool {
	inside := false
	for ringIdx, ring := range poly.Rings {
		in := pointInRing(lng, lat, ring)
		if ringIdx == 0 {
			inside = in
		} else {
			if in {
				inside = !inside
			}
		}
	}
	return inside
}

func pointInRing(lng, lat float64, ring [][2]float64) bool {
	n := len(ring)
	if n < 3 {
		return false
	}
	c := false
	for i, j := 0, n-1; i < n; j, i = i, i+1 {
		xi, yi := ring[i][0], ring[i][1]
		xj, yj := ring[j][0], ring[j][1]
		intersect := ((yi > lat) != (yj > lat)) &&
			(lng < (xj-xi)*(lat-yi)/(yj-yi)+xi)
		if intersect {
			c = !c
		}
	}
	return c
}

type heapItem struct {
	prio float64
	key  string
}
type minHeap struct{ a []heapItem }

func newMinHeap() *minHeap  { return &minHeap{a: []heapItem{}} }
func (h *minHeap) len() int { return len(h.a) }
func (h *minHeap) push(prio float64, key string) {
	h.a = append(h.a, heapItem{prio, key})
	h.up(len(h.a) - 1)
}
func (h *minHeap) pop() string {
	n := len(h.a) - 1
	if n < 0 {
		return ""
	}
	h.swap(0, n)
	out := h.a[n].key
	h.a = h.a[:n]
	h.down(0)
	return out
}
func (h *minHeap) up(i int) {
	for {
		p := (i - 1) / 2
		if i == 0 || !(h.a[i].prio < h.a[p].prio) {
			break
		}
		h.swap(i, p)
		i = p
	}
}
func (h *minHeap) down(i int) {
	for {
		l := 2*i + 1
		r := l + 1
		s := i
		if l < len(h.a) && h.a[l].prio < h.a[s].prio {
			s = l
		}
		if r < len(h.a) && h.a[r].prio < h.a[s].prio {
			s = r
		}
		if s == i {
			break
		}
		h.swap(i, s)
		i = s
	}
}
func (h *minHeap) swap(i, j int) { h.a[i], h.a[j] = h.a[j], h.a[i] }

func encodePolyline(path []node) string {
	var result strings.Builder
	var prevLat, prevLng int
	for _, p := range path {
		lat := int(math.Round(p.Lat * 1e5))
		lng := int(math.Round(p.Lng * 1e5))
		dlat := lat - prevLat
		dlng := lng - prevLng
		prevLat = lat
		prevLng = lng
		encodeSigned(dlat, &result)
		encodeSigned(dlng, &result)
	}
	return result.String()
}

func encodeSigned(v int, b *strings.Builder) {
	uv := v << 1
	if v < 0 {
		uv = ^uv
	}
	for uv >= 0x20 {
		b.WriteByte(byte((0x20 | (uv & 0x1f)) + 63))
		uv >>= 5
	}
	b.WriteByte(byte(uv + 63))
}

func decodePolyline(enc string) []node {
	var coords []node
	var lat, lng int
	i := 0
	for i < len(enc) {
		// Decode latitude
		var result int
		var shift uint
		for {
			if i >= len(enc) {
				return coords
			}
			b := int(enc[i]) - 63
			i++
			result |= (b & 0x1f) << shift
			shift += 5
			if b < 0x20 {
				break
			}
		}
		dlat := (result >> 1) ^ -(result & 1)
		lat += dlat

		// Decode longitude
		result = 0
		shift = 0
		for {
			if i >= len(enc) {
				return coords
			}
			b := int(enc[i]) - 63
			i++
			result |= (b & 0x1f) << shift
			shift += 5
			if b < 0x20 {
				break
			}
		}
		dlng := (result >> 1) ^ -(result & 1)
		lng += dlng

		coords = append(coords, node{
			Lat: float64(lat) / 1e5,
			Lng: float64(lng) / 1e5,
		})
	}
	return coords
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func spa(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Path
		if strings.HasPrefix(path, "/api/") || strings.HasPrefix(path, "/healthz") {
			next.ServeHTTP(w, r)
			return
		}
		fp := filepath.Join("public", filepath.Clean(path))
		if info, err := os.Stat(fp); err == nil && !info.IsDir() {
			next.ServeHTTP(w, r)
			return
		}
		http.ServeFile(w, r, filepath.Join("public", "index.html"))
	})
}

func parseFloatDefault(s string, def float64) float64 {
	if v, err := strconv.ParseFloat(strings.TrimSpace(s), 64); err == nil {
		return v
	}
	return def
}

func parseLatLng(s string) (float64, float64, error) {
	if strings.Contains(s, ",") {
		parts := strings.Split(s, ",")
		if len(parts) != 2 {
			return 0, 0, fmt.Errorf("bad lat,lng")
		}
		lat, err1 := strconv.ParseFloat(strings.TrimSpace(parts[0]), 64)
		lng, err2 := strconv.ParseFloat(strings.TrimSpace(parts[1]), 64)
		if err1 != nil || err2 != nil {
			return 0, 0, fmt.Errorf("bad lat,lng")
		}
		return lat, lng, nil
	}
	return 0, 0, fmt.Errorf("expect lat,lng")
}

func formatLatLng(lat, lng float64) string {
	return fmt.Sprintf("%.6f,%.6f", lat, lng)
}

type droneGridOut struct {
	GridDeg  float64       `json:"grid_deg"`
	BBox     [4]float64    `json:"bbox"`
	NI       int           `json:"n_i"`
	NJ       int           `json:"n_j"`
	LatLines [][]float64   `json:"lat_lines"`
	LngLines [][]float64   `json:"lng_lines"`
	Blocked  []blockedCell `json:"blocked"`

	NFZPolygons [][][][2]float64 `json:"nfz_polygons"`
	NFZCircles  []NFZCircle      `json:"nfz_circles"`
}

func handleDroneGrid(w http.ResponseWriter, r *http.Request, apiKey string) {
	q := r.URL.Query()
	origin := strings.TrimSpace(q.Get("origin"))
	destination := strings.TrimSpace(q.Get("destination"))
	gridDeg := parseFloatDefault(q.Get("grid_deg"), 0.003)
	nfzURL := strings.TrimSpace(q.Get("nfz_url"))

	if origin == "" || destination == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "origin and destination are required"})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	defer cancel()

	oLat, oLng, err := resolveLatLng(ctx, origin, apiKey)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid origin; provide 'lat,lng', address, or place_id:..."})
		return
	}
	dLat, dLng, err := resolveLatLng(ctx, destination, apiKey)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid destination; provide 'lat,lng', address, or place_id:..."})
		return
	}

	minLat, maxLat := math.Min(oLat, dLat), math.Max(oLat, dLat)
	minLng, maxLng := math.Min(oLng, dLng), math.Max(oLng, dLng)
	pad := 0.05
	minLat -= pad
	maxLat += pad
	minLng -= pad
	maxLng += pad

	nfzCircles := demoAirportNFZ()
	var nfzPolys []Polygon
	if nfzURL != "" {
		if pgs, err := fetchGeoJSONPolygons(ctx, nfzURL, [4]float64{minLat, minLng, maxLat, maxLng}); err == nil {
			nfzPolys = append(nfzPolys, pgs...)
		} else {
			log.Printf("WARN: nfz_url fetch failed: %v", err)
		}
	}

	if gridDeg <= 0 {
		gridDeg = 0.01
	}
	nI := int(math.Ceil((maxLat - minLat) / gridDeg))
	nJ := int(math.Ceil((maxLng - minLng) / gridDeg))
	if nI*nJ > 2_000_000 {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "grid too large; increase grid_deg"})
		return
	}

	indexToLatLng := func(i, j int) (float64, float64) {
		return minLat + float64(i)*gridDeg, minLng + float64(j)*gridDeg
	}

	isBlocked := func(i, j int) bool {
		swLat, swLng := indexToLatLng(i, j)
		neLat, neLng := swLat+gridDeg, swLng+gridDeg
		nwLat, nwLng := neLat, swLng
		seLat, seLng := swLat, neLng
		cLat, cLng := (swLat+neLat)/2, (swLng+neLng)/2

		pts := [][2]float64{
			{swLat, swLng}, {seLat, seLng},
			{nwLat, nwLng}, {neLat, neLng},
			{cLat, cLng},
		}

		pointBlocked := func(lat, lng float64) bool {
			for _, c := range nfzCircles {
				if haversine(lat, lng, c.Lat, c.Lng) <= c.RadiusM {
					return true
				}
			}
			for _, p := range nfzPolys {
				if pointInPolygon(lng, lat, p) {
					return true
				}
			}
			return false
		}

		for _, p := range pts {
			if pointBlocked(p[0], p[1]) {
				return true
			}
		}
		return false
	}

	out := droneGridOut{
		GridDeg: gridDeg,
		BBox:    [4]float64{minLat, minLng, maxLat, maxLng},
		NI:      nI,
		NJ:      nJ,
	}

	for i := 0; i <= nI; i++ {
		lat := minLat + float64(i)*gridDeg
		out.LatLines = append(out.LatLines, []float64{lat, minLng, maxLng})
	}
	for j := 0; j <= nJ; j++ {
		lng := minLng + float64(j)*gridDeg
		out.LngLines = append(out.LngLines, []float64{lng, minLat, maxLat})
	}

	for i := 0; i < nI; i++ {
		for j := 0; j < nJ; j++ {
			if isBlocked(i, j) {
				swLat, swLng := indexToLatLng(i, j)
				neLat, neLng := swLat+gridDeg, swLng+gridDeg
				out.Blocked = append(out.Blocked, blockedCell{
					SW: node{Lat: swLat, Lng: swLng},
					NE: node{Lat: neLat, Lng: neLng},
				})
			}
		}
	}

	out.NFZCircles = nfzCircles
	for _, p := range nfzPolys {
		out.NFZPolygons = append(out.NFZPolygons, p.Rings) // [][][2]float64 (lng,lat)
	}
	writeJSON(w, http.StatusOK, out)
}

func nearestDroneportLL(lat, lng float64) *DronePort {
	if len(houstonDronePorts) == 0 {
		return nil
	}
	best := &houstonDronePorts[0]
	bestDist := haversine(lat, lng, best.Lat, best.Lng)
	for i := 1; i < len(houstonDronePorts); i++ {
		d := haversine(lat, lng, houstonDronePorts[i].Lat, houstonDronePorts[i].Lng)
		if d < bestDist {
			bestDist = d
			best = &houstonDronePorts[i]
		}
	}
	return best
}

func handleOrders(w http.ResponseWriter, r *http.Request, apiKey string) {
	if db == nil {
		http.Error(w, "persistence disabled (no MYSQL_DSN)", http.StatusServiceUnavailable)
		return
	}

	switch r.Method {
	case http.MethodGet:
		user := strings.TrimSpace(r.URL.Query().Get("user"))
		dbMu.Lock()
		rows, err := func() (*sql.Rows, error) {
			if user == "" {
				return db.Query(`SELECT id,user,merchant_name,merchant_address,merchant_lat,merchant_lng,customer_address,droneport_id,droneport_name,status,leg1_polyline,leg2_polyline,created_at FROM orders ORDER BY created_at DESC LIMIT 500`)
			}
			return db.Query(`SELECT id,user,merchant_name,merchant_address,merchant_lat,merchant_lng,customer_address,droneport_id,droneport_name,status,leg1_polyline,leg2_polyline,created_at FROM orders WHERE user=? ORDER BY created_at DESC LIMIT 500`, user)
		}()
		dbMu.Unlock()
		if err != nil {
			http.Error(w, "db query failed", http.StatusInternalServerError)
			return
		}
		defer rows.Close()
		var out []storedOrder
		for rows.Next() {
			var o storedOrder
			if err := rows.Scan(&o.ID, &o.User, &o.MerchantName, &o.MerchantAddress, &o.MerchantLat, &o.MerchantLng, &o.CustomerAddress, &o.DroneportID, &o.DroneportName, &o.Status, &o.Leg1Polyline, &o.Leg2Polyline, &o.CreatedAt); err == nil {
				out = append(out, o)
			}
		}
		writeJSON(w, http.StatusOK, out)
	case http.MethodPost:
		var payload struct {
			User            string  `json:"user"`
			MerchantName    string  `json:"merchant_name"`
			MerchantAddress string  `json:"merchant_address"`
			MerchantLat     float64 `json:"merchant_lat"`
			MerchantLng     float64 `json:"merchant_lng"`
			CustomerAddress string  `json:"customer_address"`
			DroneportID     string  `json:"droneport_id"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			http.Error(w, "invalid JSON", http.StatusBadRequest)
			return
		}
		if payload.User == "" || payload.MerchantName == "" || payload.MerchantAddress == "" || payload.CustomerAddress == "" {
			http.Error(w, "user, merchant_name, merchant_address, customer_address required", http.StatusBadRequest)
			return
		}

		if payload.MerchantLat == 0 && payload.MerchantLng == 0 {
			lat, lng, err := resolveLatLng(r.Context(), payload.MerchantAddress, apiKey)
			if err != nil {
				http.Error(w, "failed to geocode merchant", http.StatusBadRequest)
				return
			}
			payload.MerchantLat, payload.MerchantLng = lat, lng
		}

		var candidates []DronePort
		seen := make(map[string]bool)
		if payload.DroneportID != "" {
			for i := range houstonDronePorts {
				if houstonDronePorts[i].ID == payload.DroneportID {
					candidates = append(candidates, houstonDronePorts[i])
					seen[houstonDronePorts[i].ID] = true
					break
				}
			}
		}
		remaining := make([]DronePort, 0, len(houstonDronePorts))
		for _, dp := range houstonDronePorts {
			if !seen[dp.ID] {
				remaining = append(remaining, dp)
			}
		}
		sort.Slice(remaining, func(i, j int) bool {
			di := haversine(payload.MerchantLat, payload.MerchantLng, remaining[i].Lat, remaining[i].Lng)
			dj := haversine(payload.MerchantLat, payload.MerchantLng, remaining[j].Lat, remaining[j].Lng)
			return di < dj
		})
		candidates = append(candidates, remaining...)
		if len(candidates) == 0 {
			http.Error(w, "no droneports configured", http.StatusBadRequest)
			return
		}

		dp, dr, leg1, leg2, requiredPct, ferr := findAndDispatchDrone(r.Context(), candidates, payload.MerchantLat, payload.MerchantLng, payload.CustomerAddress, apiKey)
		if ferr != nil {
			http.Error(w, "no available drone: "+ferr.Error(), http.StatusServiceUnavailable)
			return
		}
		success := false
		defer func() {
			if !success {
				parkDrone(dp.ID, dr)
			}
		}()

		var err error
		dbMu.Lock()
		_, err = db.Exec(`INSERT INTO merchants (name,address,lat,lng) VALUES (?,?,?,?)
			ON DUPLICATE KEY UPDATE address=VALUES(address), lat=VALUES(lat), lng=VALUES(lng)`,
			payload.MerchantName, payload.MerchantAddress, payload.MerchantLat, payload.MerchantLng)
		if err == nil {
			_, err = db.Exec(`INSERT INTO droneports (id,name,lat,lng) VALUES (?,?,?,?)
				ON DUPLICATE KEY UPDATE name=VALUES(name), lat=VALUES(lat), lng=VALUES(lng)`,
				dp.ID, dp.Name, dp.Lat, dp.Lng)
		}
		if err == nil {
			_, err = db.Exec(`INSERT INTO customers (username,address) VALUES (?,?)
				ON DUPLICATE KEY UPDATE address=VALUES(address)`,
				payload.User, payload.CustomerAddress)
		}
		dbMu.Unlock()
		if err != nil {
			http.Error(w, "db upsert failed", http.StatusInternalServerError)
			return
		}

		id := newUUID()
		if id == "" {
			id = fmt.Sprintf("%d", time.Now().UnixNano())
		}

		o := storedOrder{
			ID:                  id,
			User:                payload.User,
			MerchantName:        payload.MerchantName,
			MerchantAddress:     payload.MerchantAddress,
			MerchantLat:         payload.MerchantLat,
			MerchantLng:         payload.MerchantLng,
			CustomerAddress:     payload.CustomerAddress,
			DroneportID:         dp.ID,
			DroneportName:       dp.Name,
			Status:              "enroute",
			Leg1Polyline:        leg1.Polyline,
			Leg2Polyline:        leg2.Polyline,
			CreatedAt:           time.Now(),
			DroneID:             dr.ID,
			BatteryUsedPct:      requiredPct,
			BatteryRemainingPct: dr.BatteryPct,
		}

		dbMu.Lock()
		_, err = db.Exec(`INSERT INTO orders (id,user,merchant_name,merchant_address,merchant_lat,merchant_lng,customer_address,droneport_id,droneport_name,status,leg1_polyline,leg2_polyline) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
			o.ID, o.User, o.MerchantName, o.MerchantAddress, o.MerchantLat, o.MerchantLng, o.CustomerAddress, o.DroneportID, o.DroneportName, o.Status, o.Leg1Polyline, o.Leg2Polyline)
		dbMu.Unlock()
		if err != nil {
			http.Error(w, "db insert failed", http.StatusInternalServerError)
			return
		}
		rememberAssignment(o.ID, dp.ID, dr)
		success = true
		writeJSON(w, http.StatusCreated, o)
	case http.MethodPatch:
		if db == nil {
			http.Error(w, "persistence disabled (no MYSQL_DSN)", http.StatusServiceUnavailable)
			return
		}
		var payload struct {
			ID     string `json:"id"`
			Status string `json:"status"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			http.Error(w, "invalid JSON", http.StatusBadRequest)
			return
		}
		if payload.ID == "" {
			http.Error(w, "id required", http.StatusBadRequest)
			return
		}
		status := strings.ToLower(strings.TrimSpace(payload.Status))
		if status == "complete" || status == "completed" {
			dbMu.Lock()
			_, err := db.Exec(`DELETE FROM orders WHERE id=?`, payload.ID)
			dbMu.Unlock()
			if err != nil {
				http.Error(w, "db delete failed", http.StatusInternalServerError)
				return
			}
			assign := releaseAssignment(payload.ID)
			resp := map[string]any{"id": payload.ID, "deleted": true}
			if assign != nil && assign.Drone != nil {
				resp["drone_id"] = assign.Drone.ID
				resp["battery_remaining_pct"] = assign.Drone.BatteryPct
				resp["port_id"] = assign.PortID
			}
			writeJSON(w, http.StatusOK, resp)
			return
		}
		dbMu.Lock()
		_, err := db.Exec(`UPDATE orders SET status=? WHERE id=?`, payload.Status, payload.ID)
		dbMu.Unlock()
		if err != nil {
			http.Error(w, "db update failed", http.StatusInternalServerError)
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{"id": payload.ID, "status": payload.Status})
	default:
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
	}
}
