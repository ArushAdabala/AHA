$base = "http://localhost:8080"
$customer = "1 Greenway Plaza, Houston, TX"
$totalOrders = 10

$merchants = @(
    @{ name="Rosa's Pizza"; addr="201 Milam St, Houston, TX"; lat=29.7560; lng=-95.3610 }
    @{ name="Blue Bottle Coffee"; addr="711 Milam St, Houston, TX"; lat=29.7589; lng=-95.3677 }
    @{ name="Bird & Buffalo"; addr="5090 Smith St, Houston, TX"; lat=29.7425; lng=-95.3730 }
    @{ name="Omakase Sushi"; addr="909 Texas Ave, Houston, TX"; lat=29.7595; lng=-95.3650 }
    @{ name="Bayou Bites"; addr="1500 McKinney St, Houston, TX"; lat=29.7533; lng=-95.3595 }
    @{ name="Heights BBQ"; addr="101 E 20th St, Houston, TX"; lat=29.8033; lng=-95.3947 }
    @{ name="Rice Village Cafe"; addr="2400 Times Blvd, Houston, TX"; lat=29.7147; lng=-95.4100 }
    @{ name="Midtown Noodles"; addr="2700 Travis St, Houston, TX"; lat=29.7420; lng=-95.3725 }
)

$droneports = @("hou-downtown","hou-iah","hou-pearland","hou-sugarland","hou-deerpark","hou-baytown","hou-pasadena","hou-galleria","hou-greenspoint","hou-kingwood")

$placeJobs = @()
for ($i = 1; $i -le $totalOrders; $i++) {
    $placeJobs += Start-Job -ScriptBlock {
        pwaram($merchants, $droneports, $customer, $base, $i)
        $m = Get-Random -InputObject $merchants
        $dp = Get-Random -InputObject $droneports
        $user = "sim-user-$($i % 7)"
        $payload = @{
            user             = $user
            merchant_name    = $m.name
            merchant_address = $m.addr
            merchant_lat     = $m.lat
            merchant_lng     = $m.lng
            customer_address = $customer
            droneport_id     = $dp
        } | ConvertTo-Json
        try {
            $res = Invoke-RestMethod -Method Post -Uri "$base/api/orders" -ContentType "application/json" -Body $payload
            [PSCustomObject]@{
                id        = $res.id
                droneport = $dp
                merchant  = $m.name
                drone_id  = $res.drone_id
                used_pct  = $res.battery_used_pct
                remain_pct= $res.battery_remaining_pct
                status    = "placed"
            }
        } catch {
            Write-Warning "Failed placing order $($i): $($_.Exception.Message)"
        }
    } -ArgumentList @($merchants, $droneports, $customer, $base, $i)
}

$placements = Receive-Job -Job $placeJobs -Wait -AutoRemoveJob | Where-Object { $_ -and $_.id }
$orders = $placements | ForEach-Object { $_.id }

$placements | ForEach-Object {
    $used = if ($_.used_pct) { "{0:n1}%" -f $_.used_pct } else { "n/a" }
    $rem  = if ($_.remain_pct) { "{0:n1}%" -f $_.remain_pct } else { "n/a" }
    $drid = if ($_.drone_id) { $_.drone_id } else { "n/a" }
    Write-Host ("PLACED {0} via {1} from {2} • drone {3} • used {4} remaining {5}" -f $_.id, $_.droneport, $_.merchant, $drid, $used, $rem)
}

if ($orders.Count -gt 0) {
    $completeJobs = @()
    foreach ($id in $orders) {
        $completeJobs += Start-Job -ScriptBlock {
            param($id, $base)
            $body = @{ id = $id; status = "complete" } | ConvertTo-Json
            try {
                $resp = Invoke-RestMethod -Method Patch -Uri "$base/api/orders" -ContentType "application/json" -Body $body
                $rem = if ($resp.battery_remaining_pct) { "{0:n1}%" -f $resp.battery_remaining_pct } else { "n/a" }
                $drid = if ($resp.drone_id) { $resp.drone_id } else { "n/a" }
                Write-Host ("COMPLETED {0} • drone {1} • remaining {2}" -f $id, $drid, $rem)
            } catch {
                Write-Warning "Failed completing $($id): $($_.Exception.Message)"
            }
        } -ArgumentList @($id, $base)
    }

    Receive-Job -Job $completeJobs -Wait -AutoRemoveJob | Out-Null
}

Write-Host "Simulated $($orders.Count) orders placed and completed concurrently."
