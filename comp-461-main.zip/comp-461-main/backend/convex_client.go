package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"
)

type convexClient struct {
	baseURL string
	token   string
	http    *http.Client
}

func newConvexClientFromEnv() *convexClient {
	base := strings.TrimSpace(os.Getenv("CONVEX_ROUTER_URL"))
	if base == "" {
		base = strings.TrimSpace(os.Getenv("CONVEX_URL"))
	}
	if base == "" {
		base = strings.TrimSpace(os.Getenv("NEXT_PUBLIC_CONVEX_URL"))
	}
	if base == "" {
		return nil
	}
	base = strings.TrimSuffix(base, "/")
	return &convexClient{
		baseURL: base,
		token:   strings.TrimSpace(os.Getenv("CONVEX_ROUTER_TOKEN")),
		http:    &http.Client{Timeout: 15 * time.Second},
	}
}

func (c *convexClient) apiURL(path string) string {
	p := strings.TrimPrefix(path, "/")
	// Convex HTTP actions on `.convex.site` are mounted at the root, e.g. https://<deployment>.convex.site/router/pull.
	return fmt.Sprintf("%s/%s", strings.TrimSuffix(c.baseURL, "/"), p)
}

func (c *convexClient) doJSON(ctx context.Context, method, path string, reqBody any, respBody any) error {
	var body io.Reader
	if reqBody != nil {
		buf, err := json.Marshal(reqBody)
		if err != nil {
			return err
		}
		body = bytes.NewReader(buf)
	}
	req, err := http.NewRequestWithContext(ctx, method, c.apiURL(path), body)
	if err != nil {
		return err
	}
	if reqBody != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if c.token != "" {
		req.Header.Set("Authorization", "Bearer "+c.token)
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
		return fmt.Errorf("convex %s %s -> %d: %s", method, path, resp.StatusCode, strings.TrimSpace(string(b)))
	}
	if respBody != nil {
		dec := json.NewDecoder(resp.Body)
		if err := dec.Decode(respBody); err != nil {
			return err
		}
	}
	return nil
}

type convexMerchant struct {
	ID      string   `json:"id,omitempty"`
	Name    string   `json:"name,omitempty"`
	Address string   `json:"address,omitempty"`
	Lat     *float64 `json:"lat,omitempty"`
	Lng     *float64 `json:"lng,omitempty"`
}

type convexOrder struct {
	ID                  string          `json:"id"`
	Status              string          `json:"status"`
	DeliveryMethod      string          `json:"delivery_method"`
	DeliveryAddressText string          `json:"delivery_address_text"`
	DeliveryLat         *float64        `json:"delivery_lat,omitempty"`
	DeliveryLng         *float64        `json:"delivery_lng,omitempty"`
	UserID              string          `json:"user_id"`
	CustomerID          string          `json:"customer_id"`
	Merchant            *convexMerchant `json:"merchant,omitempty"`
	SubtotalCents       float64         `json:"subtotal_cents,omitempty"`
	TotalCents          float64         `json:"total_cents,omitempty"`
}

type convexRouteResult struct {
	OrderID              string          `json:"order_id"`
	DroneportID          string          `json:"droneport_id,omitempty"`
	DroneportName        string          `json:"droneport_name,omitempty"`
	Leg1Polyline         string          `json:"leg1_polyline,omitempty"`
	Leg2Polyline         string          `json:"leg2_polyline,omitempty"`
	ReturnPolyline       string          `json:"return_polyline,omitempty"`
	DistanceM            float64         `json:"distance_m,omitempty"`
	DurationS            float64         `json:"duration_s,omitempty"`
	Leg1DurationS        float64         `json:"leg1_duration_s,omitempty"`
	Leg2DurationS        float64         `json:"leg2_duration_s,omitempty"`
	ReturnDurationS      float64         `json:"return_duration_s,omitempty"`
	Leg1CompletedAt      int64           `json:"leg1_completed_at,omitempty"`
	Leg2StartedAt        int64           `json:"leg2_started_at,omitempty"`
	DeliveredAt          int64           `json:"delivered_at,omitempty"`
	LoadConfirmedAt      int64           `json:"load_confirmed_at,omitempty"`
	ReturnStartedAt      int64           `json:"return_started_at,omitempty"`
	ReturnCompletedAt    int64           `json:"return_completed_at,omitempty"`
	DroneID              string          `json:"drone_id,omitempty"`
	BatteryUsedPct       float64         `json:"battery_used_pct,omitempty"`
	BatteryRemainingPct  float64         `json:"battery_remaining_pct,omitempty"`
	Merchant             *convexMerchant `json:"merchant,omitempty"`
	CustomerAddressText  string          `json:"customer_address_text,omitempty"`
	Error                string          `json:"error,omitempty"`
	DroneportLat         *float64        `json:"droneport_lat,omitempty"`
	DroneportLng         *float64        `json:"droneport_lng,omitempty"`
	MerchantBusinessID   string          `json:"merchant_business_id,omitempty"`
	MerchantBusinessName string          `json:"merchant_business_name,omitempty"`
	RoutingStatus        string          `json:"routing_status,omitempty"`
}

func (c *convexClient) fetchOrders(ctx context.Context, limit int) ([]convexOrder, error) {
	if limit <= 0 {
		limit = 5
	}
	var resp struct {
		Orders []convexOrder `json:"orders"`
	}
	if err := c.doJSON(ctx, http.MethodPost, "router/pull", map[string]any{"limit": limit}, &resp); err != nil {
		return nil, err
	}
	return resp.Orders, nil
}

type convexDroneport struct {
	ID      string   `json:"id"`
	Name    string   `json:"name"`
	Address string   `json:"address"`
	Lat     *float64 `json:"lat,omitempty"`
	Lng     *float64 `json:"lng,omitempty"`
}

func (c *convexClient) fetchDroneports(ctx context.Context) ([]DronePort, error) {
	var resp struct {
		Droneports []convexDroneport `json:"droneports"`
	}
	if err := c.doJSON(ctx, http.MethodGet, "router/droneports", nil, &resp); err != nil {
		return nil, err
	}
	ports := make([]DronePort, 0, len(resp.Droneports))
	for _, dp := range resp.Droneports {
		if dp.Lat == nil || dp.Lng == nil {
			continue
		}
		ports = append(ports, DronePort{
			ID:   dp.ID,
			Name: dp.Name,
			Lat:  *dp.Lat,
			Lng:  *dp.Lng,
		})
	}
	return ports, nil
}

func (c *convexClient) reportRoute(ctx context.Context, res convexRouteResult) error {
	return c.doJSON(ctx, http.MethodPost, "router/result", res, nil)
}

func (c *convexClient) checkLoadStatus(ctx context.Context, orderID string) (bool, error) {
	var resp struct {
		Confirmed bool   `json:"confirmed"`
		Status    string `json:"status"`
	}
	if err := c.doJSON(ctx, http.MethodGet, "router/loadStatus?order_id="+orderID, nil, &resp); err != nil {
		return false, err
	}
	return resp.Confirmed, nil
}

type convexFleetDrone struct {
	Code         string  `json:"code"`
	DroneportID  string  `json:"droneport_id,omitempty"`
	Droneport    string  `json:"droneport_name,omitempty"`
	Status       string  `json:"status"`
	BatteryPct   float64 `json:"battery_percent"`
	AtDroneport  bool    `json:"at_droneport"`
	CurrentOrder string  `json:"current_order_id,omitempty"`
	Lat          float64 `json:"lat"`
	Lng          float64 `json:"lng"`
}

func (c *convexClient) sendFleetSnapshot(ctx context.Context, drones []convexFleetDrone) error {
	payload := map[string]any{"drones": drones}
	// HTTP actions in router.ts follow /router/<name>
	return c.doJSON(ctx, http.MethodPost, "router/fleet", payload, nil)
}
