# Comp 461 Monorepo (Turborepo + pnpm)

Run all commands from this `frontend/` directory unless noted otherwise.

This workspace groups three TypeScript Next.js apps into a single Turborepo:

- `business_frontend`
- `customer_frontend`
- `droneport_frontend`

## Convex backend

Minimal Convex backend is set up in `frontend/convex/` with an empty schema.

- Start Convex dev server:

```bash
pnpm convex:dev
```

You can add queries/mutations in `frontend/convex/` later. See Convex docs at [convex.dev](https://www.convex.dev/).

## Prerequisites

- pnpm 9.x installed (`npm i -g pnpm`)

## Install

```bash
pnpm install
```

## Common scripts

- Run all apps in dev (parallel):

```bash
pnpm dev
```

- Run a single app in dev:

```bash
# Using turbo filter
pnpm turbo run dev --filter=business_frontend
pnpm turbo run dev --filter=customer_frontend
pnpm turbo run dev --filter=droneport_frontend

# Or using pnpm filter
pnpm --filter business_frontend dev
```

- Build all apps (topologically):

```bash
pnpm build
```

- Lint all apps:

```bash
pnpm lint
```

- Start a single built app:

```bash
pnpm --filter droneport_frontend start
```

## Notes

- Each app keeps its own Next.js version. No cross-app deps are required.
- Consider removing `package-lock.json` in `customer_frontend` to avoid confusion with pnpm.
