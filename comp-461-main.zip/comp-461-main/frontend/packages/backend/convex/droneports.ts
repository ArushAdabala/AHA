import { query } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {
    onlyActive: v.optional(v.boolean()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    let q = ctx.db.query("droneports").withIndex("by_createdAt").order("desc");

    if (args.onlyActive) {
      q = q.filter((qb) => qb.eq(qb.field("isActive"), true));
    }

    const droneports = await q.collect();
    return args.limit ? droneports.slice(0, args.limit) : droneports;
  },
});

export const getById = query({
  args: {
    droneportId: v.id("droneports"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.droneportId);
  },
});
