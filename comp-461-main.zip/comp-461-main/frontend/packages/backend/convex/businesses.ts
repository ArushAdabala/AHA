import { query } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {
    onlyActive: v.optional(v.boolean()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    let q = ctx.db.query("businesses").withIndex("by_createdAt").order("desc");
    if (args.onlyActive) {
      q = q.filter((qb) => qb.eq(qb.field("isActive"), true));
    }
    const businesses = await q.collect();
    return args.limit ? businesses.slice(0, args.limit) : businesses;
  },
});

export const getById = query({
  args: {
    businessId: v.id("businesses"),
  },
  handler: async (ctx, args) => {
    const business = await ctx.db.get(args.businessId);
    return business;
  },
});
