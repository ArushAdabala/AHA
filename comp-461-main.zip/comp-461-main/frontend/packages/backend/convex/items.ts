import { query } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {
    onlyAvailable: v.optional(v.boolean()),
    category: v.optional(v.string()),
    limit: v.optional(v.number()),
    businessId: v.optional(v.id("businesses")),
  },
  handler: async (ctx, args) => {
    let q = ctx.db.query("items").withIndex("by_createdAt").order("desc");
    if (args.onlyAvailable) {
      q = q.filter((qb) => qb.eq(qb.field("isAvailable"), true));
    }
    if (args.category) {
      q = q.filter((qb) =>
        qb.eq(qb.field("category"), args.category as string)
      );
    }
    if (args.businessId) {
      q = q.filter((qb) => qb.eq(qb.field("businessId"), args.businessId!));
    }
    const items = await q.collect();
    return args.limit ? items.slice(0, args.limit) : items;
  },
});
