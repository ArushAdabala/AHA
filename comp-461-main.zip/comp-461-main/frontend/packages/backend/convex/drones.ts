import { query } from "./_generated/server";
import { v } from "convex/values";
import { mutation } from "./_generated/server";

export const list = query({
  args: {
    droneportId: v.optional(v.id("droneports")),
    status: v.optional(
      v.union(
        v.literal("idle"),
        v.literal("in-flight"),
        v.literal("charging"),
        v.literal("maintenance")
      )
    ),
    atDroneport: v.optional(v.boolean()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    let q = ctx.db.query("drones").withIndex("by_createdAt").order("desc");

    if (args.droneportId) {
      q = q.filter((qb) => qb.eq(qb.field("droneportId"), args.droneportId!));
    }

    if (args.status) {
      q = q.filter((qb) => qb.eq(qb.field("status"), args.status!));
    }

    if (args.atDroneport !== undefined) {
      q = q.filter((qb) => qb.eq(qb.field("atDroneport"), args.atDroneport!));
    }

    const drones = await q.collect();
    return args.limit ? drones.slice(0, args.limit) : drones;
  },
});

export const getById = query({
  args: {
    droneId: v.id("drones"),
  },
  handler: async (ctx, args) => {
    const drone = await ctx.db.get(args.droneId);
    if (!drone) return null;

    // Optionally fetch droneport info
    let droneport = null;
    if (drone.droneportId) {
      droneport = await ctx.db.get(drone.droneportId);
    }

    return {
      ...drone,
      droneport,
    };
  },
});

// Admin helper: reset fleet batteries/positions and top up drone count across ports
export const resetFleet = mutation({
  args: {
    total: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const ports = await ctx.db.query("droneports").collect();
    if (!ports.length) return { ok: false, error: "no droneports" };

    // Gather existing drones
    const drones = await ctx.db.query("drones").collect();

    // Decide how many we want total; default to current, but honor requested count exactly if provided
    const desiredTotal =
      args.total && args.total > 0 ? args.total : drones.length;

    // Compute balanced target per port
    const base = Math.floor(desiredTotal / ports.length);
    const extra = desiredTotal % ports.length;
    const targets = ports.map((_, idx) => base + (idx < extra ? 1 : 0));

    // Build assignment pool: existing drones plus any new ones needed to hit desiredTotal
    const pool: Array<{ existing?: typeof drones[number]; portIdx?: number }> = [];
    for (const d of drones) {
      if (pool.length < desiredTotal) {
        pool.push({ existing: d });
      } else {
        // extra drones beyond desired total; delete them
        await ctx.db.delete(d._id);
      }
    }
    while (pool.length < desiredTotal) pool.push({});

    let poolIdx = 0;
    for (let i = 0; i < ports.length; i++) {
      const needed = targets[i];
      for (let j = 0; j < needed; j++) {
        const slot = pool[poolIdx];
        poolIdx++;
        if (slot.existing) {
          const d = slot.existing;
          await ctx.db.patch(d._id, {
            batteryPercent: 100,
            atDroneport: true,
            status: "idle",
            currentOrderId: undefined,
            longitude: (ports[i].address as any)?.lng ?? d.longitude,
            latitude: (ports[i].address as any)?.lat ?? d.latitude,
            droneportId: ports[i]._id,
            lastLocationUpdate: now,
            updatedAt: now,
          });
        } else {
          await ctx.db.insert("drones", {
            batteryPercent: 100,
            longitude: (ports[i].address as any)?.lng ?? 0,
            latitude: (ports[i].address as any)?.lat ?? 0,
            droneportId: ports[i]._id,
            atDroneport: true,
            status: "idle",
            currentOrderId: undefined,
            lastLocationUpdate: now,
            createdAt: now,
            updatedAt: now,
          });
        }
      }
    }

    return { ok: true, total: (await ctx.db.query("drones").collect()).length };
  },
});
