import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  businesses: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    address: v.optional(
      v.object({
        line1: v.string(),
        line2: v.optional(v.string()),
        city: v.string(),
        state: v.optional(v.string()),
        postalCode: v.optional(v.string()),
        lat: v.optional(v.number()),
        lng: v.optional(v.number()),
      })
    ),
    categories: v.optional(v.array(v.string())),
    isActive: v.boolean(),
    ownerUserId: v.optional(v.string()),
    // Storefront display fields
    averageRating: v.optional(v.number()),
    ratingCount: v.optional(v.number()),
    priceRating: v.optional(v.number()), // 1-4 scale for price level ($ to $$$$)
    operationHours: v.optional(
      v.array(
        v.object({
          openHour: v.number(),
          openMinute: v.number(),
          closeHour: v.number(),
          closeMinute: v.number(),
        })
      )
    ),
    isDashPass: v.optional(v.boolean()), // Whether business participates in DashPass
    deliveryTime: v.optional(v.string()), // e.g., "30 min"
    pickupTime: v.optional(v.string()), // e.g., "20 min"
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_active", ["isActive"])
    .index("by_name", ["name"])
    .index("by_createdAt", ["createdAt"]),

  items: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    sku: v.optional(v.string()),
    priceCents: v.number(),
    currency: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    category: v.optional(v.string()),
    isAvailable: v.boolean(),
    businessId: v.id("businesses"),
    // Item rating and display fields
    ratingPercentage: v.optional(v.number()), // 0-100 percentage
    ratingCount: v.optional(v.number()),
    lastOrdered: v.optional(v.string()), // Date string, e.g., "12/18/22"
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_availability", ["isAvailable"])
    .index("by_category", ["category"])
    .index("by_business", ["businessId"])
    .index("by_createdAt", ["createdAt"]),

  customers: defineTable({
    userId: v.string(), // Clerk user ID
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    defaultDeliveryAddress: v.optional(
      v.object({
        line1: v.string(),
        line2: v.optional(v.string()),
        city: v.string(),
        state: v.optional(v.string()),
        postalCode: v.optional(v.string()),
        lat: v.optional(v.number()),
        lng: v.optional(v.number()),
      })
    ),
    preferences: v.optional(
      v.object({
        deliveryInstructions: v.optional(v.string()),
        dietaryRestrictions: v.optional(v.array(v.string())),
        favoriteBusinesses: v.optional(v.array(v.id("businesses"))),
      })
    ),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_userId", ["userId"])
    .index("by_email", ["email"])
    .index("by_createdAt", ["createdAt"]),

  orders: defineTable({
    status: v.union(
      v.literal("pending"),
      v.literal("paid"),
      v.literal("preparing"),
      v.literal("delivering"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
    lineItems: v.array(
      v.object({
        itemId: v.id("items"),
        quantity: v.number(),
        priceCents: v.number(),
      })
    ),
    subtotalCents: v.number(),
    taxCents: v.optional(v.number()),
    deliveryFeeCents: v.optional(v.number()),
    totalCents: v.number(),
    userId: v.optional(v.string()),
    customerId: v.optional(v.id("customers")),
    deliveryMethod: v.optional(
      v.union(v.literal("delivery"), v.literal("pickup"))
    ),
    deliveryAddress: v.optional(
      v.object({
        line1: v.string(),
        line2: v.optional(v.string()),
        city: v.string(),
        state: v.optional(v.string()),
        postalCode: v.optional(v.string()),
        lat: v.optional(v.number()),
        lng: v.optional(v.number()),
      })
    ),
    customer: v.optional(
      v.object({
        name: v.optional(v.string()),
        email: v.optional(v.string()),
        phone: v.optional(v.string()),
      })
    ),
    notes: v.optional(v.string()),
    droneRouting: v.optional(
      v.object({
        status: v.union(
          v.literal("pending"),
      v.literal("routing"),
      v.literal("routed"),
      v.literal("enroute_merchant"),
      v.literal("waiting_load"),
      v.literal("load_confirmed"),
      v.literal("enroute_customer"),
      v.literal("enroute_return"),
      v.literal("returned"),
      v.literal("delivered"),
      v.literal("failed")
    ),
        error: v.optional(v.string()),
        startedAt: v.optional(v.number()),
        completedAt: v.optional(v.number()),
        departedAt: v.optional(v.number()),
        arrivedMerchantAt: v.optional(v.number()),
        loadConfirmedAt: v.optional(v.number()),
        departedMerchantAt: v.optional(v.number()),
        deliveredAt: v.optional(v.number()),
        droneportId: v.optional(v.id("droneports")),
        droneportName: v.optional(v.string()),
        leg1Polyline: v.optional(v.string()),
        leg2Polyline: v.optional(v.string()),
        distanceMeters: v.optional(v.number()),
        leg1DurationSeconds: v.optional(v.number()),
        leg2DurationSeconds: v.optional(v.number()),
        returnPolyline: v.optional(v.string()),
        returnDurationSeconds: v.optional(v.number()),
        durationSeconds: v.optional(v.number()),
        droneId: v.optional(v.string()),
        batteryUsedPct: v.optional(v.number()),
        batteryRemainingPct: v.optional(v.number()),
        returnStartedAt: v.optional(v.number()),
        returnCompletedAt: v.optional(v.number()),
        merchant: v.optional(
          v.object({
            businessId: v.optional(v.id("businesses")),
            name: v.optional(v.string()),
            address: v.optional(v.string()),
            lat: v.optional(v.number()),
            lng: v.optional(v.number()),
          })
        ),
        customerAddressText: v.optional(v.string()),
      })
    ),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_status", ["status"])
    .index("by_user", ["userId"])
    .index("by_customer", ["customerId"])
    .index("by_createdAt", ["createdAt"]),

  droneports: defineTable({
    name: v.string(),
    address: v.object({
      line1: v.string(),
      line2: v.optional(v.string()),
      city: v.string(),
      state: v.optional(v.string()),
      postalCode: v.optional(v.string()),
      lat: v.optional(v.number()),
      lng: v.optional(v.number()),
    }),
    isActive: v.boolean(),
    capacity: v.optional(v.number()), // Max number of drones the droneport can hold
    description: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_name", ["name"])
    .index("by_active", ["isActive"])
    .index("by_createdAt", ["createdAt"]),

  drones: defineTable({
    code: v.optional(v.string()),
    batteryPercent: v.number(), // 0-100
    longitude: v.number(),
    latitude: v.number(),
    droneportId: v.optional(v.id("droneports")), // Droneport assigned to
    atDroneport: v.boolean(), // Whether drone is currently at the droneport
    status: v.optional(
      v.union(
        v.literal("idle"),
        v.literal("in-flight"),
        v.literal("charging"),
        v.literal("maintenance")
      )
    ),
    currentOrderId: v.optional(v.id("orders")), // Order currently assigned to this drone
    lastLocationUpdate: v.optional(v.number()), // Timestamp of last location update
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_code", ["code"])
    .index("by_droneport", ["droneportId"])
    .index("by_status", ["status"])
    .index("by_atDroneport", ["atDroneport"])
    .index("by_currentOrder", ["currentOrderId"])
    .index("by_createdAt", ["createdAt"]),
});
