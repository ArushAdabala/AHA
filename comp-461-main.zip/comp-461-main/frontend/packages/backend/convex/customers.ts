import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { Auth } from "convex/server";

const getUserId = async (ctx: { auth: Auth }) => {
  return (await ctx.auth.getUserIdentity())?.subject;
};

export const getCurrent = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getUserId(ctx);
    if (!userId) return null;

    return await ctx.db
      .query("customers")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .first();
  },
});

export const get = query({
  args: { customerId: v.id("customers") },
  handler: async (ctx, { customerId }) => {
    const userId = await getUserId(ctx);
    if (!userId) return null;

    const customer = await ctx.db.get(customerId);
    if (!customer || customer.userId !== userId) return null;
    return customer;
  },
});

export const create = mutation({
  args: {
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    defaultDeliveryAddress: v.optional(
      v.object({
        line1: v.string(),
        line2: v.optional(v.string()),
        city: v.string(),
        state: v.optional(v.string()),
        postalCode: v.optional(v.string()),
        lat: v.optional(v.number()),
        lng: v.optional(v.number()),
      })
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    // Check if customer already exists
    const existing = await ctx.db
      .query("customers")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .first();

    if (existing) {
      return existing._id;
    }

    const customerId = await ctx.db.insert("customers", {
      userId,
      name: args.name,
      email: args.email,
      phone: args.phone,
      defaultDeliveryAddress: args.defaultDeliveryAddress,
      createdAt: Date.now(),
    });

    return customerId;
  },
});

export const update = mutation({
  args: {
    customerId: v.id("customers"),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    defaultDeliveryAddress: v.optional(
      v.object({
        line1: v.string(),
        line2: v.optional(v.string()),
        city: v.string(),
        state: v.optional(v.string()),
        postalCode: v.optional(v.string()),
        lat: v.optional(v.number()),
        lng: v.optional(v.number()),
      })
    ),
    preferences: v.optional(
      v.object({
        deliveryInstructions: v.optional(v.string()),
        dietaryRestrictions: v.optional(v.array(v.string())),
        favoriteBusinesses: v.optional(v.array(v.id("businesses"))),
      })
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    const customer = await ctx.db.get(args.customerId);
    if (!customer || customer.userId !== userId) {
      throw new Error("Customer not found or unauthorized");
    }

    const updates: {
      name?: string;
      email?: string;
      phone?: string;
      defaultDeliveryAddress?: typeof args.defaultDeliveryAddress;
      preferences?: typeof args.preferences;
      updatedAt: number;
    } = {
      updatedAt: Date.now(),
    };

    if (args.name !== undefined) updates.name = args.name;
    if (args.email !== undefined) updates.email = args.email;
    if (args.phone !== undefined) updates.phone = args.phone;
    if (args.defaultDeliveryAddress !== undefined)
      updates.defaultDeliveryAddress = args.defaultDeliveryAddress;
    if (args.preferences !== undefined) updates.preferences = args.preferences;

    await ctx.db.patch(args.customerId, updates);
  },
});

export const updateDefaultAddress = mutation({
  args: {
    address: v.object({
      line1: v.string(),
      line2: v.optional(v.string()),
      city: v.string(),
      state: v.optional(v.string()),
      postalCode: v.optional(v.string()),
      lat: v.optional(v.number()),
      lng: v.optional(v.number()),
    }),
  },
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    const customer = await ctx.db
      .query("customers")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .first();

    if (!customer) {
      throw new Error("Customer profile not found");
    }

    await ctx.db.patch(customer._id, {
      defaultDeliveryAddress: args.address,
      updatedAt: Date.now(),
    });
  },
});
