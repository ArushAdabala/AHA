import { mutation } from "./_generated/server";
import { v } from "convex/values";

export const seedMockData = mutation({
  args: {
    force: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    const existingBiz = await ctx.db.query("businesses").first();
    if (existingBiz && !args.force) {
      return { skipped: true, reason: "data already exists" };
    }

    // Basic helpers to avoid duplicate names if re-run with force.
    const findBusinessByName = async (name: string) =>
      ctx.db
        .query("businesses")
        .withIndex("by_name", (q) => q.eq("name", name))
        .first();

    const upsertBusiness = async (biz: {
      name: string;
      description?: string;
      categories?: string[];
      imageUrl?: string;
      address?: {
        line1: string;
        line2?: string;
        city: string;
        state?: string;
        postalCode?: string;
        lat?: number;
        lng?: number;
      };
    }) => {
      const existing = await findBusinessByName(biz.name);
      if (existing) return existing._id;
      return ctx.db.insert("businesses", {
        ...biz,
        isActive: true,
        ownerUserId: undefined,
        createdAt: now,
      });
    };

    const businessIds = {
      bayouBites: await upsertBusiness({
        name: "Bayou Bites",
        description: "Local Houston comfort food with quick prep.",
        categories: ["comfort", "sandwiches"],
        address: {
          line1: "201 Milam St",
          city: "Houston",
          state: "TX",
          postalCode: "77002",
          lat: 29.7635,
          lng: -95.3648,
        },
      }),
      spaceCitySushi: await upsertBusiness({
        name: "Space City Sushi",
        description: "Fresh rolls and poke bowls",
        categories: ["sushi", "poke"],
        imageUrl:
          "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1200&q=80",
        address: {
          line1: "4701 Calhoun Rd",
          city: "Houston",
          state: "TX",
          postalCode: "77004",
          lat: 29.7205,
          lng: -95.3425,
        },
      }),
      greenspointGrocer: await upsertBusiness({
        name: "Greenspoint Grocer",
        description: "Neighborhood essentials and snacks.",
        categories: ["grocery"],
        imageUrl:
          "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80",
        address: {
          line1: "1230 Greens Pkwy",
          city: "Houston",
          state: "TX",
          postalCode: "77067",
          lat: 29.9449,
          lng: -95.4446,
        },
      }),
      tacoLucha: await upsertBusiness({
        name: "Taco Lucha",
        description: "Street tacos with a Houston twist.",
        categories: ["mexican", "tacos"],
        imageUrl:
          "https://images.unsplash.com/photo-1608034043139-77b3ffc5c45f?auto=format&fit=crop&w=1200&q=80",
        address: {
          line1: "2130 Richmond Ave",
          city: "Houston",
          state: "TX",
          postalCode: "77098",
          lat: 29.7357,
          lng: -95.4103,
        },
      }),
      bayouVegan: await upsertBusiness({
        name: "Bayou Vegan",
        description: "Plant-based plates inspired by Gulf flavors.",
        categories: ["vegan", "bowls"],
        imageUrl:
          "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80",
        address: {
          line1: "1901 Taylor St",
          city: "Houston",
          state: "TX",
          postalCode: "77007",
          lat: 29.7712,
          lng: -95.3785,
        },
      }),
      phoStation: await upsertBusiness({
        name: "Pho Station",
        description: "Brothy comfort with brisket and veggie options.",
        categories: ["vietnamese", "soup"],
        imageUrl:
          "https://images.unsplash.com/photo-1604908177453-74629501c4c2?auto=format&fit=crop&w=1200&q=80",
        address: {
          line1: "4010 Bellaire Blvd",
          city: "Houston",
          state: "TX",
          postalCode: "77025",
          lat: 29.7068,
          lng: -95.4409,
        },
      }),
      nolaBeignets: await upsertBusiness({
        name: "NOLA Beignets",
        description: "Beignets, chicory coffee, and pralines.",
        categories: ["dessert", "coffee"],
        imageUrl:
          "https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1200&q=80",
        address: {
          line1: "1201 Caroline St",
          city: "Houston",
          state: "TX",
          postalCode: "77002",
          lat: 29.7543,
          lng: -95.3679,
        },
      }),
    };

    const addItem = async (bizId: typeof businessIds[keyof typeof businessIds], item: any) => {
      return ctx.db.insert("items", {
        ...item,
        businessId: bizId,
        isAvailable: true,
        currency: "USD",
        createdAt: now,
      });
    };

    await addItem(businessIds.bayouBites, {
      name: "BBQ Brisket Sandwich",
      description: "Smoked brisket on brioche, pickles & slaw",
      priceCents: 1399,
      category: "sandwich",
      imageUrl:
        "https://images.unsplash.com/photo-1604908177796-0ac1c9bb646c?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.bayouBites, {
      name: "Cajun Shrimp Po'boy",
      priceCents: 1299,
      category: "sandwich",
      imageUrl:
        "https://images.unsplash.com/photo-1552332386-f8dd00dc2f85?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.spaceCitySushi, {
      name: "Dragon Roll",
      description: "Eel, avocado, spicy tuna",
      priceCents: 1599,
      category: "rolls",
      imageUrl:
        "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.spaceCitySushi, {
      name: "Salmon Poke Bowl",
      priceCents: 1399,
      category: "bowls",
      imageUrl:
        "https://images.unsplash.com/photo-1545249351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.greenspointGrocer, {
      name: "Cold Brew Coffee",
      priceCents: 499,
      category: "drinks",
      imageUrl:
        "https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.greenspointGrocer, {
      name: "Trail Mix",
      priceCents: 349,
      category: "snacks",
      imageUrl:
        "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.tacoLucha, {
      name: "Carne Asada Taco Trio",
      description: "Skirt steak, cilantro, onion, lime",
      priceCents: 1199,
      category: "tacos",
      imageUrl:
        "https://images.unsplash.com/photo-1608034779866-27c5eb348b6e?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.tacoLucha, {
      name: "Al Pastor Tacos",
      priceCents: 1099,
      category: "tacos",
      imageUrl:
        "https://images.unsplash.com/photo-1529699211952-734e80c4d42b?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.bayouVegan, {
      name: "Crispy Tofu Bowl",
      description: "Charred veggies, rice, remoulade",
      priceCents: 1299,
      category: "bowls",
      imageUrl:
        "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.bayouVegan, {
      name: "Jackfruit Po'boy",
      priceCents: 1199,
      category: "sandwich",
      imageUrl:
        "https://images.unsplash.com/photo-1604908177521-d4314f70c10c?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.phoStation, {
      name: "Pho Tai",
      description: "Rare beef, rice noodles, herbs",
      priceCents: 1299,
      category: "soup",
      imageUrl:
        "https://images.unsplash.com/photo-1604908177302-8879c7d68f0d?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.phoStation, {
      name: "Lemongrass Chicken Vermicelli",
      priceCents: 1299,
      category: "noodles",
      imageUrl:
        "https://images.unsplash.com/photo-1604908177818-13bae0b0a33d?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.nolaBeignets, {
      name: "Beignet Trio",
      priceCents: 699,
      category: "dessert",
      imageUrl:
        "https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1200&q=80",
    });
    await addItem(businessIds.nolaBeignets, {
      name: "Chicory Latte",
      priceCents: 499,
      category: "coffee",
      imageUrl:
        "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=1200&q=80",
    });

    const droneportSeeds = [
      {
        name: "Downtown Hub",
        address: {
          line1: "901 Bagby St",
          city: "Houston",
          state: "TX",
          postalCode: "77002",
          lat: 29.7604,
          lng: -95.3698,
        },
      },
      {
        name: "Texas Medical Center Port",
        address: {
          line1: "7200 Cambridge St",
          city: "Houston",
          state: "TX",
          postalCode: "77030",
          lat: 29.7099,
          lng: -95.401,
        },
      },
      {
        name: "Greenspoint North Port",
        address: {
          line1: "1230 Greens Pkwy",
          city: "Houston",
          state: "TX",
          postalCode: "77067",
          lat: 29.9451,
          lng: -95.4116,
        },
      },
    ];

    const droneportIds = [];
    for (const dp of droneportSeeds) {
      const existing = await ctx.db
        .query("droneports")
        .withIndex("by_name", (q) => q.eq("name", dp.name))
        .first();
      if (existing) {
        droneportIds.push(existing._id);
        continue;
      }
      const id = await ctx.db.insert("droneports", {
        ...dp,
        isActive: true,
        createdAt: now,
      });
      droneportIds.push(id);
    }

    // Seed a couple of drones per port.
    for (const dpId of droneportIds) {
      for (let i = 1; i <= 3; i++) {
        await ctx.db.insert("drones", {
          batteryPercent: 100,
          longitude: 0,
          latitude: 0,
          droneportId: dpId,
          atDroneport: true,
          status: "idle",
          currentOrderId: undefined,
          lastLocationUpdate: now,
          createdAt: now,
        });
      }
    }

    return {
      ok: true,
      businesses: businessIds,
      droneports: droneportIds.length,
    };
  },
});
