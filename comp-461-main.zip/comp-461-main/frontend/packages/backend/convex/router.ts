import { httpAction, mutation, query } from "./_generated/server";
import { Id } from "./_generated/dataModel";
import { api } from "./_generated/api";
import { v } from "convex/values";

const json = (payload: unknown, status = 200) =>
  new Response(JSON.stringify(payload), {
    status,
    headers: { "Content-Type": "application/json" },
  });

const requireAuth = (request: Request) => {
  const expected = process.env.ROUTER_ACCESS_TOKEN;
  if (!expected) return null;
  const header = request.headers.get("authorization") || "";
  if (header === `Bearer ${expected}`) return null;
  return new Response("unauthorized", { status: 401 });
};

type Address = {
  line1: string;
  line2?: string;
  city: string;
  state?: string;
  postalCode?: string;
  lat?: number;
  lng?: number;
};

const formatAddress = (addr?: Address) =>
  addr
    ? [
        addr.line1,
        addr.line2,
        addr.city,
        addr.state,
        addr.postalCode,
      ]
        .filter(Boolean)
        .join(", ")
    : undefined;

export const pullOrdersInternal = mutation({
  args: { limit: v.number() },
  handler: async (ctx, { limit }) => {
    const pending = await ctx.db
      .query("orders")
      .withIndex("by_status", (q) => q.eq("status", "pending"))
      .order("desc")
      .collect();

    const candidates = pending.filter(
      (o) =>
        (o.deliveryMethod ?? "delivery") === "delivery" &&
        (o.droneRouting?.status ?? "pending") === "pending"
    );

    const now = Date.now();

    const hydrated = await Promise.all(
      candidates.slice(0, limit).map(async (order) => {
        let merchant:
          | {
              id: Id<"businesses">;
              name: string;
              address?: string;
              lat?: number;
              lng?: number;
            }
          | undefined;

        if (order.lineItems.length > 0) {
          const firstItem = await ctx.db.get(order.lineItems[0].itemId);
          if (firstItem?.businessId) {
            const biz = await ctx.db.get(firstItem.businessId);
            if (biz) {
              merchant = {
                id: biz._id,
                name: biz.name,
                address: formatAddress(biz.address),
                lat: biz.address?.lat ?? undefined,
                lng: biz.address?.lng ?? undefined,
              };
            }
          }
        }

        await ctx.db.patch(order._id, {
          droneRouting: {
            ...(order.droneRouting ?? {}),
            status: "routing",
            startedAt: now,
            error: undefined,
          },
          updatedAt: now,
        });

        return {
          id: order._id,
          status: order.status,
          user_id: order.userId,
          customer_id: order.customerId,
          delivery_method: order.deliveryMethod ?? "delivery",
          delivery_address_text: formatAddress(order.deliveryAddress),
          delivery_lat: order.deliveryAddress?.lat,
          delivery_lng: order.deliveryAddress?.lng,
          subtotal_cents: order.subtotalCents,
          total_cents: order.totalCents,
          merchant,
        };
      })
    );

    return { orders: hydrated };
  },
});

export const routerResultInternal = mutation({
  args: {
    orderId: v.id("orders"),
    error: v.optional(v.string()),
    droneportId: v.optional(v.id("droneports")),
    droneportName: v.optional(v.string()),
    leg1Polyline: v.optional(v.string()),
    leg2Polyline: v.optional(v.string()),
    distanceM: v.optional(v.number()),
    durationS: v.optional(v.number()),
    leg1DurationS: v.optional(v.number()),
    leg2DurationS: v.optional(v.number()),
    returnPolyline: v.optional(v.string()),
    returnDurationS: v.optional(v.number()),
    returnStartedAt: v.optional(v.number()),
    returnCompletedAt: v.optional(v.number()),
    leg1CompletedAt: v.optional(v.number()),
    leg2StartedAt: v.optional(v.number()),
    deliveredAt: v.optional(v.number()),
    loadConfirmedAt: v.optional(v.number()),
    droneId: v.optional(v.string()),
    batteryUsedPct: v.optional(v.number()),
    batteryRemainingPct: v.optional(v.number()),
    routingStatus: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("routing"),
        v.literal("routed"),
        v.literal("enroute_merchant"),
        v.literal("waiting_load"),
        v.literal("load_confirmed"),
        v.literal("enroute_customer"),
        v.literal("enroute_return"),
        v.literal("returned"),
        v.literal("delivered"),
        v.literal("failed")
      )
    ),
    merchant: v.optional(
      v.object({
        businessId: v.optional(v.id("businesses")),
        id: v.optional(v.id("businesses")),
        name: v.optional(v.string()),
        address: v.optional(v.string()),
        lat: v.optional(v.number()),
        lng: v.optional(v.number()),
      })
    ),
    customerAddressText: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const order = await ctx.db.get(args.orderId);
    if (!order) return { ok: false, error: "order not found" };

    const now = Date.now();
    const succeeded = !args.error;

    const routingStatus =
      args.routingStatus ??
      (succeeded ? "routed" : (order.droneRouting?.status ?? "failed"));

    const merchant =
      args.merchant && (args.merchant.businessId || args.merchant.id)
        ? {
            businessId:
              args.merchant.businessId ??
              (args.merchant.id as Id<"businesses"> | undefined),
            name: args.merchant.name,
            address: args.merchant.address,
            lat: args.merchant.lat,
            lng: args.merchant.lng,
          }
        : args.merchant
          ? {
              name: args.merchant.name,
              address: args.merchant.address,
              lat: args.merchant.lat,
              lng: args.merchant.lng,
            }
          : order.droneRouting?.merchant;

    await ctx.db.patch(args.orderId, {
      droneRouting: {
        ...(order.droneRouting ?? {}),
        status: routingStatus,
        error: args.error ?? undefined,
        completedAt: now,
        departedAt: args.leg1CompletedAt ? order.droneRouting?.departedAt ?? now : order.droneRouting?.departedAt,
        arrivedMerchantAt: args.leg1CompletedAt ?? order.droneRouting?.arrivedMerchantAt,
        loadConfirmedAt: args.loadConfirmedAt ?? order.droneRouting?.loadConfirmedAt,
        departedMerchantAt: args.leg2StartedAt ?? order.droneRouting?.departedMerchantAt,
        deliveredAt: args.deliveredAt ?? order.droneRouting?.deliveredAt,
        returnStartedAt: args.returnStartedAt ?? order.droneRouting?.returnStartedAt,
        returnCompletedAt:
          args.returnCompletedAt ?? order.droneRouting?.returnCompletedAt,
        droneportId: args.droneportId ?? order.droneRouting?.droneportId,
        droneportName: args.droneportName ?? order.droneRouting?.droneportName,
        leg1Polyline: args.leg1Polyline ?? order.droneRouting?.leg1Polyline,
        leg2Polyline: args.leg2Polyline ?? order.droneRouting?.leg2Polyline,
        returnPolyline: args.returnPolyline ?? order.droneRouting?.returnPolyline,
        distanceMeters: args.distanceM ?? order.droneRouting?.distanceMeters,
        durationSeconds: args.durationS ?? order.droneRouting?.durationSeconds,
        leg1DurationSeconds:
          args.leg1DurationS ?? order.droneRouting?.leg1DurationSeconds,
        leg2DurationSeconds:
          args.leg2DurationS ?? order.droneRouting?.leg2DurationSeconds,
        returnDurationSeconds:
          args.returnDurationS ?? order.droneRouting?.returnDurationSeconds,
        droneId: args.droneId ?? order.droneRouting?.droneId,
        batteryUsedPct:
          args.batteryUsedPct ?? order.droneRouting?.batteryUsedPct,
        batteryRemainingPct:
          args.batteryRemainingPct ?? order.droneRouting?.batteryRemainingPct,
        merchant,
        customerAddressText:
          args.customerAddressText ?? order.droneRouting?.customerAddressText,
      },
      status:
        routingStatus === "returned"
          ? "completed"
          : order.status === "completed"
            ? order.status
            : routingStatus === "failed"
              ? order.status
              : "delivering",
      updatedAt: now,
    });

    return { ok: true };
  },
});

export const routerDroneportsInternal = query({
  args: {},
  handler: async (ctx) => {
    const ports = await ctx.db.query("droneports").collect();
    const active = ports.filter((p) => p.isActive);
    return {
      droneports: active.map((p) => ({
        id: p._id,
        name: p.name,
        address: formatAddress(p.address as Address),
        lat: (p.address as Address | undefined)?.lat,
        lng: (p.address as Address | undefined)?.lng,
      })),
    };
  },
});

export const routerPull = httpAction(async (ctx, request) => {
  const authErr = requireAuth(request);
  if (authErr) return authErr;

  const url = new URL(request.url);
  let limit = Number(url.searchParams.get("limit")) || 5;
  if (request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    if (typeof body.limit === "number") {
      limit = body.limit;
    }
  }
  if (limit <= 0) limit = 5;
  if (limit > 25) limit = 25;

  const result = await ctx.runMutation(api.router.pullOrdersInternal, {
    limit,
  });
  return json(result);
});

export const routerResult = httpAction(async (ctx, request) => {
  const authErr = requireAuth(request);
  if (authErr) return authErr;

  const body = await request.json().catch(() => null);
  if (!body || typeof body.order_id !== "string") {
    return json({ error: "order_id required" }, 400);
  }

  const result = await ctx.runMutation(api.router.routerResultInternal, {
    orderId: body.order_id as Id<"orders">,
    error: body.error,
    droneportId: body.droneport_id as Id<"droneports"> | undefined,
    droneportName: body.droneport_name,
    leg1Polyline: body.leg1_polyline,
    leg2Polyline: body.leg2_polyline,
    distanceM: body.distance_m,
    durationS: body.duration_s,
    droneId: body.drone_id,
    batteryUsedPct: body.battery_used_pct,
    batteryRemainingPct: body.battery_remaining_pct,
    routingStatus: body.routing_status,
    leg1DurationS: body.leg1_duration_s,
    leg2DurationS: body.leg2_duration_s,
    returnPolyline: body.return_polyline,
    returnDurationS: body.return_duration_s,
    returnStartedAt: body.return_started_at,
    returnCompletedAt: body.return_completed_at,
    leg1CompletedAt: body.leg1_completed_at,
    leg2StartedAt: body.leg2_started_at,
    deliveredAt: body.delivered_at,
    loadConfirmedAt: body.load_confirmed_at,
    merchant: body.merchant,
    customerAddressText: body.customer_address_text,
  });
  if (!result.ok) {
    return json({ error: result.error }, 404);
  }
  return json({ ok: true });
});

export const confirmLoad = mutation({
  args: { orderId: v.id("orders") },
  handler: async (ctx, { orderId }) => {
    const order = await ctx.db.get(orderId);
    if (!order) return { ok: false, error: "order not found" };
    const now = Date.now();
    await ctx.db.patch(orderId, {
      droneRouting: {
        ...(order.droneRouting ?? {}),
        status: "load_confirmed",
        loadConfirmedAt: now,
      },
      updatedAt: now,
    });
    return { ok: true };
  },
});

export const loadStatus = httpAction(async (ctx, request) => {
  const authErr = requireAuth(request);
  if (authErr) return authErr;
  const url = new URL(request.url);
  const orderId = url.searchParams.get("order_id");
  if (!orderId) return json({ error: "order_id required" }, 400);
  const order = await ctx.runQuery(api.orders.getAdmin, {
    orderId: orderId as Id<"orders">,
  });
  const confirmed = Boolean(order?.droneRouting?.loadConfirmedAt);
  return json({ confirmed, status: order?.droneRouting?.status });
});

export const routerFleetInternal = mutation({
  args: {
    drones: v.array(
      v.object({
        code: v.string(),
        droneportId: v.optional(v.id("droneports")),
        droneportName: v.optional(v.string()),
        status: v.union(
          v.literal("idle"),
          v.literal("in-flight"),
          v.literal("charging"),
          v.literal("maintenance")
        ),
        batteryPercent: v.number(),
        atDroneport: v.boolean(),
        currentOrderId: v.optional(v.id("orders")),
        latitude: v.number(),
        longitude: v.number(),
      })
    ),
  },
  handler: async (ctx, { drones }) => {
    const now = Date.now();
    for (const d of drones) {
      const existing = await ctx.db
        .query("drones")
        .withIndex("by_code", (q) => q.eq("code", d.code))
        .first();
      if (existing) {
        await ctx.db.patch(existing._id, {
          batteryPercent: d.batteryPercent,
          longitude: d.longitude,
          latitude: d.latitude,
          droneportId: d.droneportId ?? existing.droneportId,
          atDroneport: d.atDroneport,
          status: d.status,
          currentOrderId: d.currentOrderId,
          updatedAt: now,
        });
      } else {
        await ctx.db.insert("drones", {
          code: d.code,
          batteryPercent: d.batteryPercent,
          longitude: d.longitude,
          latitude: d.latitude,
          droneportId: d.droneportId,
          atDroneport: d.atDroneport,
          status: d.status,
          currentOrderId: d.currentOrderId,
          createdAt: now,
          updatedAt: now,
        });
      }
    }
    return { ok: true, count: drones.length };
  },
});

export const routerDroneports = httpAction(async (ctx, request) => {
  const authErr = requireAuth(request);
  if (authErr) return authErr;

  const result = await ctx.runQuery(api.router.routerDroneportsInternal, {});
  return json(result);
});

export const routerFleet = httpAction(async (ctx, request) => {
  const authErr = requireAuth(request);
  if (authErr) return authErr;
  const body = await request.json().catch(() => null);
  if (!body || !Array.isArray(body.drones)) {
    return json({ error: "drones array required" }, 400);
  }
  const payload = body.drones.map((d: any) => ({
    code: String(d.code),
    droneportId: d.droneport_id as Id<"droneports"> | undefined,
    droneportName: d.droneport_name as string | undefined,
    status: d.status as any,
    batteryPercent: Number(d.battery_percent ?? 0),
    atDroneport: Boolean(d.at_droneport),
    currentOrderId: d.current_order_id as Id<"orders"> | undefined,
    latitude: Number(d.lat ?? d.latitude ?? 0),
    longitude: Number(d.lng ?? d.longitude ?? 0),
  }));
  const result = await ctx.runMutation(api.router.routerFleetInternal, {
    drones: payload,
  });
  return json(result);
});
