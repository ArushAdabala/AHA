import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { Auth } from "convex/server";
import { Id } from "./_generated/dataModel";

const getUserId = async (ctx: { auth: Auth }) => {
  return (await ctx.auth.getUserIdentity())?.subject;
};

export const create = mutation({
  args: {
    lineItems: v.array(
      v.object({
        itemId: v.id("items"),
        quantity: v.number(),
        priceCents: v.number(),
      })
    ),
    deliveryMethod: v.optional(
      v.union(v.literal("delivery"), v.literal("pickup"))
    ),
    deliveryAddress: v.optional(
      v.object({
        line1: v.string(),
        line2: v.optional(v.string()),
        city: v.string(),
        state: v.optional(v.string()),
        postalCode: v.optional(v.string()),
        lat: v.optional(v.number()),
        lng: v.optional(v.number()),
      })
    ),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    // Get or create customer
    let customer = await ctx.db
      .query("customers")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .first();

    if (!customer) {
      // Create customer if doesn't exist
      const customerId = await ctx.db.insert("customers", {
        userId,
        createdAt: Date.now(),
      });
      customer = await ctx.db.get(customerId);
      if (!customer) {
        throw new Error("Failed to create customer");
      }
    }

    // Calculate totals
    const subtotalCents = args.lineItems.reduce(
      (sum, item) => sum + item.priceCents * item.quantity,
      0
    );

    // Simple tax calculation (8% - adjust as needed)
    const taxCents = Math.round(subtotalCents * 0.08);

    // Delivery fee (if delivery method is delivery)
    const deliveryFeeCents =
      args.deliveryMethod === "delivery" ? 299 : undefined; // $2.99 in cents

    const totalCents = subtotalCents + taxCents + (deliveryFeeCents || 0);

    // Get customer info for order
    const customerInfo = customer
      ? {
          name: customer.name,
          email: customer.email,
          phone: customer.phone,
        }
      : undefined;

    // Create order
    const orderId = await ctx.db.insert("orders", {
      status: "pending",
      lineItems: args.lineItems,
      subtotalCents,
      taxCents,
      deliveryFeeCents,
      totalCents,
      userId,
      customerId: customer._id,
      deliveryMethod: args.deliveryMethod,
      deliveryAddress: args.deliveryAddress,
      customer: customerInfo,
      notes: args.notes,
      createdAt: Date.now(),
    });

    return orderId;
  },
});

export const list = query({
  args: {
    status: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("paid"),
        v.literal("preparing"),
        v.literal("delivering"),
        v.literal("completed"),
        v.literal("cancelled")
      )
    ),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    if (!userId) return [];

    let q = ctx.db
      .query("orders")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc");

    if (args.status) {
      q = q.filter((qb) => qb.eq(qb.field("status"), args.status!));
    }

    const orders = await q.collect();
    return args.limit ? orders.slice(0, args.limit) : orders;
  },
});

export const listAll = query({
  args: {
    status: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("paid"),
        v.literal("preparing"),
        v.literal("delivering"),
        v.literal("completed"),
        v.literal("cancelled")
      )
    ),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    // Get all orders (for droneport/admin view)
    let q = ctx.db.query("orders").withIndex("by_createdAt").order("desc");

    if (args.status) {
      q = q.filter((qb) => qb.eq(qb.field("status"), args.status!));
    }

    const orders = await q.collect();
    const limitedOrders = args.limit ? orders.slice(0, args.limit) : orders;

    // Enrich orders with business information and item details
    const enrichedOrders = await Promise.all(
      limitedOrders.map(async (order) => {
        // Fetch item details for each line item
        const lineItemsWithDetails = await Promise.all(
          order.lineItems.map(async (lineItem) => {
            const item = await ctx.db.get(lineItem.itemId);
            return {
              ...lineItem,
              item: item
                ? {
                    name: item.name,
                    imageUrl: item.imageUrl,
                    description: item.description,
                  }
                : null,
            };
          })
        );

        // Get business from first item (assuming all items are from same business)
        let business = null;
        if (order.lineItems.length > 0) {
          const firstItem = await ctx.db.get(order.lineItems[0].itemId);
          if (firstItem?.businessId) {
            business = await ctx.db.get(firstItem.businessId);
          }
        }

        return {
          ...order,
          lineItems: lineItemsWithDetails,
          business,
        };
      })
    );

    return enrichedOrders;
  },
});

export const get = query({
  args: {
    orderId: v.id("orders"),
  },
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    if (!userId) return null;

    const order = await ctx.db.get(args.orderId);
    if (!order || order.userId !== userId) return null;

    // Fetch item details for each line item
    const lineItemsWithDetails = await Promise.all(
      order.lineItems.map(async (lineItem) => {
        const item = await ctx.db.get(lineItem.itemId);
        return {
          ...lineItem,
          item: item
            ? {
                name: item.name,
                imageUrl: item.imageUrl,
                description: item.description,
              }
            : null,
        };
      })
    );

    // Get business from first item (assuming all items are from same business)
    let business = null;
    if (order.lineItems.length > 0) {
      const firstItem = await ctx.db.get(order.lineItems[0].itemId);
      if (firstItem?.businessId) {
        business = await ctx.db.get(firstItem.businessId);
      }
    }

    return {
      ...order,
      lineItems: lineItemsWithDetails,
      business,
    };
  },
});

// Admin/system read without auth check (used by router/loadStatus)
export const getAdmin = query({
  args: { orderId: v.id("orders") },
  handler: async (ctx, args) => {
    return ctx.db.get(args.orderId);
  },
});

// Seed a batch of demo orders for load/UX testing
export const seedDemoOrders = mutation({
  args: { count: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const count = Math.max(1, Math.min(args.count ?? 30, 100));
    const now = Date.now();

    const businesses = await ctx.db.query("businesses").collect();
    const itemsByBiz = new Map<string, any[]>();
    for (const biz of businesses) {
      const items = await ctx.db
        .query("items")
        .withIndex("by_business", (q) => q.eq("businessId", biz._id))
        .collect();
      if (items.length) {
        itemsByBiz.set(String(biz._id), items);
      }
    }

    const addresses = [
      {
        line1: "201 Milam St",
        city: "Houston",
        state: "TX",
        postalCode: "77002",
        lat: 29.7635,
        lng: -95.3648,
      },
      {
        line1: "6320 Main St",
        city: "Houston",
        state: "TX",
        postalCode: "77005",
        lat: 29.7133,
        lng: -95.4010,
      },
      {
        line1: "901 Bagby St",
        city: "Houston",
        state: "TX",
        postalCode: "77002",
        lat: 29.7604,
        lng: -95.3698,
      },
      {
        line1: "4701 Calhoun Rd",
        city: "Houston",
        state: "TX",
        postalCode: "77004",
        lat: 29.7205,
        lng: -95.3425,
      },
      {
        line1: "2130 Richmond Ave",
        city: "Houston",
        state: "TX",
        postalCode: "77098",
        lat: 29.7357,
        lng: -95.4103,
      },
      {
        line1: "4010 Bellaire Blvd",
        city: "Houston",
        state: "TX",
        postalCode: "77025",
        lat: 29.7068,
        lng: -95.4409,
      },
      {
        line1: "1201 Caroline St",
        city: "Houston",
        state: "TX",
        postalCode: "77002",
        lat: 29.7543,
        lng: -95.3679,
      },
      {
        line1: "1901 Taylor St",
        city: "Houston",
        state: "TX",
        postalCode: "77007",
        lat: 29.7712,
        lng: -95.3785,
      },
      {
        line1: "1230 Greens Pkwy",
        city: "Houston",
        state: "TX",
        postalCode: "77067",
        lat: 29.9449,
        lng: -95.4446,
      },
      {
        line1: "7200 Cambridge St",
        city: "Houston",
        state: "TX",
        postalCode: "77030",
        lat: 29.7099,
        lng: -95.401,
      },
    ];

    const ensureCustomer = async (email: string, name: string) => {
      const existing = await ctx.db
        .query("customers")
        .withIndex("by_email", (q) => q.eq("email", email))
        .first();
      if (existing) return existing;
      const userId = `demo-${email}`;
      const id = await ctx.db.insert("customers", {
        userId,
        name,
        email,
        createdAt: now,
      });
      return await ctx.db.get(id);
    };

    let created = 0;
    for (let i = 0; i < count; i++) {
      const biz = businesses[i % businesses.length];
      const bizItems = itemsByBiz.get(String(biz._id)) ?? [];
      if (!biz || !bizItems.length) continue;

      const item = bizItems[i % bizItems.length];
      const addr = addresses[i % addresses.length];
      const email = `demo${i + 1}@example.com`;
      const customer = await ensureCustomer(email, `Demo Customer ${i + 1}`);

      const lineItems = [
        {
          itemId: item._id,
          quantity: 1 + (i % 2),
          priceCents: item.priceCents,
        },
      ];
      const subtotalCents = lineItems.reduce(
        (sum, li) => sum + li.priceCents * li.quantity,
        0
      );
      const taxCents = Math.round(subtotalCents * 0.08);
      const deliveryFeeCents = 299;
      const totalCents = subtotalCents + taxCents + deliveryFeeCents;

      await ctx.db.insert("orders", {
        status: "pending",
        lineItems,
        subtotalCents,
        taxCents,
        deliveryFeeCents,
        totalCents,
        userId: customer?.userId,
        customerId: customer?._id,
        deliveryMethod: "delivery",
        deliveryAddress: addr,
        customer: {
          name: customer?.name,
          email: customer?.email,
        },
        notes: "Demo order",
        createdAt: now + i, // slight stagger
      });
      created++;
    }

    return { created, count };
  },
});

export const updateStatus = mutation({
  args: {
    orderId: v.id("orders"),
    status: v.union(
      v.literal("pending"),
      v.literal("paid"),
      v.literal("preparing"),
      v.literal("delivering"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    const order = await ctx.db.get(args.orderId);
    if (!order || order.userId !== userId) {
      throw new Error("Order not found or unauthorized");
    }

    await ctx.db.patch(args.orderId, {
      status: args.status,
      updatedAt: Date.now(),
    });
  },
});
