/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as businesses from "../businesses.js";
import type * as customers from "../customers.js";
import type * as droneports from "../droneports.js";
import type * as drones from "../drones.js";
import type * as http from "../http.js";
import type * as items from "../items.js";
import type * as orders from "../orders.js";
import type * as router from "../router.js";
import type * as seeds from "../seeds.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  businesses: typeof businesses;
  customers: typeof customers;
  droneports: typeof droneports;
  drones: typeof drones;
  http: typeof http;
  items: typeof items;
  orders: typeof orders;
  router: typeof router;
  seeds: typeof seeds;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
