import { httpRouter } from "convex/server";
import {
  routerPull,
  routerResult,
  routerDroneports,
  routerFleet,
  loadStatus,
} from "./router";

const http = httpRouter();

http.route({
  path: "/router/pull",
  method: "POST",
  handler: routerPull,
});

http.route({
  path: "/router/result",
  method: "POST",
  handler: routerResult,
});

http.route({
  path: "/router/droneports",
  method: "GET",
  handler: routerDroneports,
});

http.route({
  path: "/router/fleet",
  method: "POST",
  handler: routerFleet,
});

http.route({
  path: "/router/loadStatus",
  method: "GET",
  handler: loadStatus,
});

export default http;
