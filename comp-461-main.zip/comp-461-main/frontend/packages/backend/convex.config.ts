import { defineConfig } from "convex";

export default defineConfig({
  functions: {
    // Route HTTP actions defined in convex/http.ts
    http: {
      router: "./convex/http.js",
    },
  },
});
