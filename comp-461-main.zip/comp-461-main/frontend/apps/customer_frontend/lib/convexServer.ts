import "server-only";

import { getAuth } from "@clerk/nextjs/server";
import type { GetServerSidePropsContext } from "next";

/**
 * Get Clerk auth token for server-side Convex queries
 * Use this with fetchQuery from convex/nextjs
 *
 * This is a server-only function and should only be imported in:
 * - getServerSideProps
 * - getStaticProps
 * - API routes
 * - Server Components
 *
 * @param req - Next.js request object from getServerSideProps context
 * @returns Clerk JWT token or undefined if not authenticated
 */
export async function getConvexAuthToken(
  req?: GetServerSidePropsContext["req"]
): Promise<string | undefined> {
  try {
    if (!req) {
      return undefined;
    }

    const authResult = await getAuth(req);
    if (authResult?.getToken) {
      const token = await authResult.getToken({ template: "convex" });
      return token || undefined;
    }
  } catch (error) {
    // If auth is not available (e.g., public route), return undefined
    // This allows public pages to work without authentication
    console.debug("No auth token available for Convex query");
  }

  return undefined;
}
