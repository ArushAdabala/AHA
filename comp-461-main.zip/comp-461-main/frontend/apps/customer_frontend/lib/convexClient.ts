"use client";

import { ConvexReactClient } from "convex/react";

const convexUrl = process.env.NEXT_PUBLIC_CONVEX_URL;

if (!convexUrl) {
  throw new Error("NEXT_PUBLIC_CONVEX_URL environment variable is not set");
}

// Single instance of Convex client for client-side usage
// This is used by ConvexProviderWithClerk which handles authentication automatically
export const convexClient = new ConvexReactClient(convexUrl, {
  verbose: true,
});
