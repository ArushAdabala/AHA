import Head from "next/head";
import { useRouter } from "next/router";
import { createContext, useMemo, useEffect, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../../../packages/backend/convex/_generated/api";
import { Id } from "../../../../packages/backend/convex/_generated/dataModel";
import {
  TRestaurantDataPrimary,
  TStorefrontData,
  TStoreItem,
} from "../../global";
import { useAppDispatch } from "../../app-redux/hooks";
import {
  setPageViewingBusinessId,
  setBusinessId,
} from "../../app-redux/features/cart/cartSlice";

import StoreLayout from "../../components/Layouts/StoreLayout";
import HeroComponent from "../../components/StoreComponents/HeroComponent/HeroComponent";
import CartOverview from "../../components/StoreComponents/CartOverviewComponent/CartOverview";
// eslint-disable-next-line import/no-cycle
import QuickActions from "../../components/StoreComponents/QuickActionsComponent/QuickActions";

export const StoreItemsContext = createContext<TStoreItem[] | null>(null);

export default function Store() {
  const router = useRouter();
  const storeID = router.query.slug as string;
  const businessId = storeID; // Convex business ID
  const dispatch = useAppDispatch();
  const [distanceLabel, setDistanceLabel] = useState("0.0 mi");

  const haversineMiles = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const toRad = (d: number) => (d * Math.PI) / 180;
    const R = 6371000; // meters
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const meters = R * c;
    return meters / 1609.34;
  };

  // Fetch business data
  const business = useQuery(api.businesses.getById, {
    businessId: storeID as Id<"businesses">,
  });

  // Fetch items for this business
  const items = useQuery(api.items.list, {
    businessId: storeID as Id<"businesses">,
    onlyAvailable: true,
  });

  // Set business ID in Redux when page loads
  useEffect(() => {
    if (businessId) {
      dispatch(setPageViewingBusinessId(businessId));
    }
  }, [businessId, dispatch]);

  // Transform Convex data to match expected format
  const restaurant = useMemo(() => {
    if (!business || !items) return null;

    const restaurantData: TRestaurantDataPrimary = {
      restaurantName: business.name,
      restaurantImage: {
        src: business.imageUrl || "/images/default-restaurant.webp",
        alt: `Image from ${business.name}`,
      },
      distance: distanceLabel,
      deliveryTime: business.deliveryTime || "30 min",
      pickupTime: business.pickupTime || "20 min",
      isDashPass: business.isDashPass ?? false,
    };

    const storefrontData: TStorefrontData = {
      operationHours: business.operationHours || [],
      items: items.map((item, index) => {
        const itemData: TStoreItem = {
          itemID: index + 1, // Legacy numeric ID for backward compatibility
          convexItemId: item._id, // Convex item ID
          image: {
            src: item.imageUrl || "/images/default-item.webp",
            alt: item.name,
          },
          itemName: item.name,
          price: item.priceCents / 100, // Convert cents to dollars
          ratingPercentage: item.ratingPercentage ?? 95, // Default to 95 if not set
          ratingCount: item.ratingCount ?? 0,
        };
        // Only include optional fields if they exist
        if (item.description) {
          itemData.description = item.description;
        }
        if (item.lastOrdered) {
          itemData.lastOrdered = item.lastOrdered;
        }
        return itemData;
      }),
    };

    // Only include optional fields if they exist
    if (business.description) {
      storefrontData.shortDescription = business.description;
    }
    if (business.averageRating !== undefined) {
      storefrontData.averageRating = business.averageRating;
    }
    if (business.ratingCount !== undefined) {
      storefrontData.ratingCount = business.ratingCount;
    }
    if (business.priceRating !== undefined) {
      storefrontData.priceRating = business.priceRating;
    }

    return {
      restaurantData,
      storefrontData,
    };
  }, [business, items, distanceLabel]);

  // Compute distance from user to business (if geolocation permitted and business has lat/lng)
  useEffect(() => {
    if (!business?.address?.lat || !business?.address?.lng) return;
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const miles = haversineMiles(
          pos.coords.latitude,
          pos.coords.longitude,
          business.address!.lat!,
          business.address!.lng!
        );
        setDistanceLabel(`${miles.toFixed(1)} mi`);
      },
      () => {
        // ignore errors; keep default distance
      },
      { enableHighAccuracy: false, timeout: 3000 }
    );
  }, [business]);

  // Loading state
  if (business === undefined || items === undefined) {
    return (
      <>
        <Head>
          <title>Loading...</title>
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <link rel="icon" href="/favicon.ico" />
        </Head>
        <StoreLayout>
          <div style={{ padding: "2rem", textAlign: "center" }}>
            <p>Loading restaurant...</p>
          </div>
        </StoreLayout>
      </>
    );
  }

  // Not found state
  if (!business || !restaurant) {
    return (
      <>
        <Head>
          <title>Restaurant Not Found</title>
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <link rel="icon" href="/favicon.ico" />
        </Head>
        <StoreLayout>
          <div style={{ padding: "2rem", textAlign: "center" }}>
            <h1>Restaurant Not Found</h1>
            <p>The restaurant you're looking for doesn't exist.</p>
          </div>
        </StoreLayout>
      </>
    );
  }

  return (
    <>
      <Head>
        <title>{restaurant.restaurantData.restaurantName}</title>
        <meta
          name="Aha"
          content="Aha Drone Delivery - Fast drone deliveries from nearby partners"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <StoreLayout>
        <HeroComponent
          restaurantData={restaurant.restaurantData}
          storefrontData={restaurant.storefrontData}
        />
        {/* Insert Rest of the Store's components */}
        <StoreItemsContext.Provider value={restaurant.storefrontData.items}>
          <QuickActions />
        </StoreItemsContext.Provider>
        <CartOverview isInCartSheet={false} />
      </StoreLayout>
    </>
  );
}
