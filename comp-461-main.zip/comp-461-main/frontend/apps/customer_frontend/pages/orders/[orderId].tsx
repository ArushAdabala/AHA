import Head from "next/head";
import { useRouter } from "next/router";
import { useEffect, useRef } from "react";
import { useQuery } from "convex/react";
import mapboxgl from "mapbox-gl";
import styled from "styled-components";
import Navbar from "../../components/Navigation/Navbar";
import { api } from "../../../../packages/backend/convex/_generated/api";
import { Id } from "../../../../packages/backend/convex/_generated/dataModel";

const PageContainer = styled.div`
  min-height: 100vh;
  background: var(--primary-white);
  padding-top: 64px;
`;

const Content = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px 16px;
  display: flex;
  flex-direction: column;
  gap: 16px;
`;

const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const Title = styled.h1`
  font-size: 32px;
  font-weight: 600;
  color: var(--primary-black);
`;

const StatusBadge = styled.span<{ status: string }>`
  padding: 6px 12px;
  border-radius: 999px;
  font-weight: 600;
  text-transform: capitalize;
  background: ${(p) =>
    p.status === "completed"
      ? "#d1fae5"
      : p.status === "delivering"
        ? "#ddd6fe"
        : "#f3f4f6"};
  color: ${(p) =>
    p.status === "completed"
      ? "#065f46"
      : p.status === "delivering"
        ? "#5b21b6"
        : "#374151"};
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  @media (max-width: 900px) {
    grid-template-columns: 1fr;
  }
`;

const Card = styled.div`
  border: 1px solid var(--primary-gray);
  border-radius: 10px;
  padding: 16px;
  background: #fff;
`;

const SectionTitle = styled.h2`
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 12px;
`;

const Row = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
  font-size: 14px;
`;

const MapBox = styled.div`
  width: 100%;
  height: 480px;
  border: 1px solid var(--primary-gray);
  border-radius: 10px;
  overflow: hidden;
`;

const Loading = styled.div`
  padding: 80px;
  text-align: center;
`;

const ErrorMsg = styled.div`
  padding: 80px;
  text-align: center;
  color: var(--secondary-red);
`;

function decodePolyline(encoded: string): [number, number][] {
  let index = 0;
  let lat = 0;
  let lng = 0;
  const coordinates: [number, number][] = [];
  while (index < encoded.length) {
    let result = 0;
    let shift = 0;
    let b: number;
    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlat = (result & 1) ? ~(result >> 1) : result >> 1;
    lat += dlat;
    result = 0;
    shift = 0;
    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlng = (result & 1) ? ~(result >> 1) : result >> 1;
    lng += dlng;
    coordinates.push([lng * 1e-5, lat * 1e-5]);
  }
  return coordinates;
}

function haversine(a: [number, number], b: [number, number]) {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 6371000;
  const dLat = toRad(b[1] - a[1]);
  const dLng = toRad(b[0] - a[0]);
  const lat1 = toRad(a[1]);
  const lat2 = toRad(b[1]);
  const sinDLat = Math.sin(dLat / 2);
  const sinDLng = Math.sin(dLng / 2);
  const h =
    sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
  return 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function interpolateAlongLine(
  coords: [number, number][],
  startMs: number,
  durationSec: number,
  nowMs: number
): [number, number] | null {
  if (coords.length < 2 || !durationSec || !startMs) return null;
  const progress = Math.min(
    1,
    Math.max(0, (nowMs - startMs) / (durationSec * 1000))
  );
  let total = 0;
  for (let i = 1; i < coords.length; i++) {
    total += haversine(coords[i - 1], coords[i]);
  }
  if (total === 0) return coords[coords.length - 1];
  const target = total * progress;
  let traveled = 0;
  for (let i = 1; i < coords.length; i++) {
    const seg = haversine(coords[i - 1], coords[i]);
    if (traveled + seg >= target) {
      const remain = target - traveled;
      const t = seg === 0 ? 1 : remain / seg;
      const lng = coords[i - 1][0] + (coords[i][0] - coords[i - 1][0]) * t;
      const lat = coords[i - 1][1] + (coords[i][1] - coords[i - 1][1]) * t;
      return [lng, lat];
    }
    traveled += seg;
  }
  return coords[coords.length - 1];
}

function computeLiveDroneCoord(order: any) {
  const dr = order?.droneRouting;
  if (!dr) return null;
  const now = Date.now();
  const leg1 =
    dr.leg1Polyline && typeof dr.leg1Polyline === "string"
      ? decodePolyline(dr.leg1Polyline)
      : [];
  const leg2 =
    dr.leg2Polyline && typeof dr.leg2Polyline === "string"
      ? decodePolyline(dr.leg2Polyline)
      : [];

  const status = dr.status;
  if (status === "waiting_load" && leg1.length) return leg1[leg1.length - 1];
  if (status === "delivered" && leg2.length) return leg2[leg2.length - 1];
  if (status === "enroute_merchant" && leg1.length) {
    const start = dr.departedAt ?? dr.startedAt ?? order.createdAt ?? now;
    const dur = dr.leg1DurationSeconds ?? dr.durationSeconds ?? 0;
    return interpolateAlongLine(leg1, start, dur, now) || leg1[leg1.length - 1];
  }
  if (status === "enroute_customer" && leg2.length) {
    const start =
      dr.departedMerchantAt ??
      dr.loadConfirmedAt ??
      dr.arrivedMerchantAt ??
      dr.startedAt ??
      order.createdAt ??
      now;
    const dur = dr.leg2DurationSeconds ?? dr.durationSeconds ?? 0;
    return interpolateAlongLine(leg2, start, dur, now) || leg2[leg2.length - 1];
  }
  return null;
}

function computeEta(order: any) {
  const dr = order?.droneRouting;
  if (!dr) return { minutes: null, arrival: null };
  if (
    dr.status === "delivered" ||
    dr.status === "enroute_return" ||
    dr.status === "returned"
  ) {
    return { minutes: null, arrival: null };
  }
  const now = Date.now();
  const start = dr.departedAt ?? dr.startedAt ?? order?.createdAt ?? now;
  const totalDur =
    dr.durationSeconds ??
    ((dr.leg1DurationSeconds ?? 0) + (dr.leg2DurationSeconds ?? 0));
  if (!totalDur) return { minutes: null, arrival: null };
  const elapsed = Math.max(0, (now - start) / 1000);
  const remaining = Math.max(0, totalDur - elapsed);
  return {
    minutes: Math.round(remaining / 60),
    arrival: new Date(now + remaining * 1000),
  };
}

export default function OrderDetailsPage() {
  const router = useRouter();
  const { orderId } = router.query;
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);

  const order = useQuery(
    api.orders.get,
    orderId ? { orderId: orderId as Id<"orders"> } : "skip"
  );
  const routing = order?.droneRouting;
  const eta = computeEta(order);
  const etaMinutes = eta.minutes;

  const routingStatus = routing?.status;
  const displayStatus =
    routingStatus &&
    (routingStatus === "delivered" ||
      routingStatus === "enroute_return" ||
      routingStatus === "returned")
      ? "completed"
      : order?.status ?? "pending";
  const droneStatus =
    routingStatus &&
    (routingStatus === "delivered" ||
      routingStatus === "enroute_return" ||
      routingStatus === "returned")
      ? "delivered"
      : routingStatus ?? order?.status ?? "pending";

  // Init map
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current || !order) return;
    const token = process.env.NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN;
    if (!token) return;
    mapboxgl.accessToken = token;
    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: "mapbox://styles/mapbox/streets-v12",
      center: [-95.3698, 29.7604],
      zoom: 11,
    });
    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, [order]);

  // Draw route
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !order || !routing) return;
    const draw = () => {
      const leg1 =
        routing.leg1Polyline && decodePolyline(routing.leg1Polyline as string);
      const leg2 =
        routing.leg2Polyline && decodePolyline(routing.leg2Polyline as string);

      const stopsSource = "order-stops";
      const leg1Source = "order-leg1";
      const leg2Source = "order-leg2";
      const droneSource = "order-drone";
      [stopsSource, leg1Source, leg2Source, droneSource].forEach((id) => {
        if (map.getLayer(id)) map.removeLayer(id);
        if (map.getSource(id)) map.removeSource(id);
      });

      const features: GeoJSON.Feature[] = [];
      const coords: [number, number][] = [];

      if (leg1?.length) {
        map.addSource(leg1Source, {
          type: "geojson",
          data: {
            type: "Feature",
            geometry: { type: "LineString", coordinates: leg1 },
          },
        });
        map.addLayer({
          id: leg1Source,
          type: "line",
          source: leg1Source,
          paint: { "line-color": "#3b82f6", "line-width": 4 },
        });
        coords.push(...leg1);
        features.push({
          type: "Feature",
          geometry: { type: "Point", coordinates: leg1[0] },
          properties: { label: routing.droneportName ?? "Droneport" },
        });
        features.push({
          type: "Feature",
          geometry: { type: "Point", coordinates: leg1[leg1.length - 1] },
          properties: { label: order.business?.name ?? "Merchant" },
        });
      }
      if (leg2?.length) {
        map.addSource(leg2Source, {
          type: "geojson",
          data: {
            type: "Feature",
            geometry: { type: "LineString", coordinates: leg2 },
          },
        });
        map.addLayer({
          id: leg2Source,
          type: "line",
          source: leg2Source,
          paint: { "line-color": "#22c55e", "line-width": 4 },
        });
        coords.push(...leg2);
        features.push({
          type: "Feature",
          geometry: { type: "Point", coordinates: leg2[leg2.length - 1] },
          properties: { label: "Customer" },
        });
      }

      if (features.length) {
        map.addSource(stopsSource, {
          type: "geojson",
          data: { type: "FeatureCollection", features },
        });
        map.addLayer({
          id: stopsSource,
          type: "circle",
          source: stopsSource,
          paint: {
            "circle-radius": 8,
            "circle-color": "#ef4444",
            "circle-stroke-width": 2,
            "circle-stroke-color": "#ffffff",
          },
        });
        map.addLayer({
          id: `${stopsSource}-labels`,
          type: "symbol",
          source: stopsSource,
          layout: {
            "text-field": ["get", "label"],
            "text-offset": [0, 1.2],
            "text-anchor": "top",
            "text-size": 12,
          },
        });
      }

      const live = computeLiveDroneCoord(order);
      if (live) {
        map.addSource(droneSource, {
          type: "geojson",
          data: { type: "Feature", geometry: { type: "Point", coordinates: live } },
        });
        map.addLayer({
          id: droneSource,
          type: "circle",
          source: droneSource,
          paint: {
            "circle-radius": 6,
            "circle-color": "#111827",
            "circle-stroke-width": 2,
            "circle-stroke-color": "#ffffff",
          },
        });
        coords.push(live);
      }

      if (coords.length) {
        const bounds = coords.reduce(
          (b, c) => b.extend(c as [number, number]),
          new mapboxgl.LngLatBounds(coords[0], coords[0])
        );
        map.fitBounds(bounds, { padding: 60, duration: 500 });
      }
    };

    if (!map.isStyleLoaded()) {
      const once = () => draw();
      map.once("load", once);
      return () => {
        map.off("load", once);
      };
    }

    draw();
  }, [order, routing]);

  if (order === undefined) {
    return (
      <>
        <Head>
          <title>Loading Order...</title>
        </Head>
        <Navbar isShoppingCartToggleable />
        <Loading>Loading order details...</Loading>
      </>
    );
  }

  if (order === null) {
    return (
      <>
        <Head>
          <title>Order Not Found</title>
        </Head>
        <Navbar isShoppingCartToggleable />
        <ErrorMsg>Order not found or you don't have access to it.</ErrorMsg>
      </>
    );
  }

  const priceFormatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  });

  return (
    <>
      <Head>
        <title>Order {orderId}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <Navbar isShoppingCartToggleable />
      <PageContainer>
        <Content>
          <Header>
            <Title>Order Details</Title>
            <StatusBadge status={displayStatus}>{displayStatus}</StatusBadge>
          </Header>

          <Grid>
            <Card>
              <SectionTitle>Order Items</SectionTitle>
              {(order.lineItems ?? []).map((lineItem: any, idx: number) => (
                <Row key={idx}>
                  <span>{lineItem.item?.name ?? "Item"}</span>
                  <span>
                    {lineItem.quantity} ×{" "}
                    {priceFormatter.format(lineItem.priceCents / 100)}
                  </span>
                </Row>
              ))}
              <Row>
                <strong>Total</strong>
                <strong>{priceFormatter.format(order.totalCents / 100)}</strong>
              </Row>
            </Card>

            <Card>
              <SectionTitle>Delivery Information</SectionTitle>
              <Row>
                <span>Method</span>
                <span>{order.deliveryMethod === "pickup" ? "Pickup" : "Delivery"}</span>
              </Row>
              {order.deliveryAddress && (
                <Row>
                  <span>Address</span>
                  <span style={{ textAlign: "right" }}>
                    {order.deliveryAddress.line1}
                    {order.deliveryAddress.line2 ? `, ${order.deliveryAddress.line2}` : ""}
                    <br />
                    {order.deliveryAddress.city}
                    {order.deliveryAddress.state ? `, ${order.deliveryAddress.state}` : ""}{" "}
                    {order.deliveryAddress.postalCode}
                  </span>
                </Row>
              )}
              {order.customer?.email && (
                <Row>
                  <span>Email</span>
                  <span>{order.customer.email}</span>
                </Row>
              )}
              <Row>
                <span>Order Date</span>
                <span>{new Date(order.createdAt).toLocaleString()}</span>
              </Row>
              <Row>
                <span>Drone Status</span>
                <span>{droneStatus}</span>
              </Row>
              {etaMinutes !== null && (
                <Row>
                  <span>ETA</span>
                  <span>{etaMinutes} min</span>
                </Row>
              )}
              {eta.arrival && (
                <Row>
                  <span>Arrives By</span>
                  <span>
                    {eta.arrival.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
                  </span>
                </Row>
              )}
              {routing?.distanceMeters && (
                <Row>
                  <span>Route Distance</span>
                  <span>{(routing.distanceMeters / 1000).toFixed(1)} km</span>
                </Row>
              )}
            </Card>
          </Grid>

          {routing && (
            <Card>
              <SectionTitle>Delivery Route</SectionTitle>
              <MapBox ref={mapContainerRef} />
            </Card>
          )}
        </Content>
      </PageContainer>
    </>
  );
}
