import Head from "next/head";
import { useQuery } from "convex/react";
import { api } from "../../../packages/backend/convex/_generated/api";

export default function MenuPage() {
  const items = useQuery(api.items.list, { onlyAvailable: true });

  return (
    <>
      <Head>
        <title>Menu</title>
      </Head>
      <main style={{ maxWidth: 960, margin: "0 auto", padding: 16 }}>
        <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 16 }}>
          Menu
        </h1>
        {!items && <p>Loading items…</p>}
        {items && items.length === 0 && (
          <p>No items available yet. Check back soon.</p>
        )}
        {items && items.length > 0 && (
          <ul
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
              gap: 16,
              listStyle: "none",
              padding: 0,
              margin: 0,
            }}
          >
            {items.map((item) => (
              <li
                key={item._id}
                style={{
                  border: "1px solid #e5e7eb",
                  borderRadius: 8,
                  padding: 12,
                  background: "white",
                }}
              >
                {item.imageUrl ? (
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    style={{
                      width: "100%",
                      height: 140,
                      objectFit: "cover",
                      borderRadius: 6,
                      marginBottom: 8,
                      display: "block",
                    }}
                  />
                ) : null}
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 8,
                  }}
                >
                  <h2 style={{ fontSize: 16, fontWeight: 600, margin: 0 }}>
                    {item.name}
                  </h2>
                  <span style={{ fontSize: 14, whiteSpace: "nowrap" }}>
                    ${(item.priceCents / 100).toFixed(2)}
                  </span>
                </div>
                {item.description ? (
                  <p
                    style={{
                      margin: "8px 0 0 0",
                      color: "#4b5563",
                      fontSize: 14,
                    }}
                  >
                    {item.description}
                  </p>
                ) : null}
                {item.category ? (
                  <p
                    style={{
                      margin: "8px 0 0 0",
                      color: "#6b7280",
                      fontSize: 12,
                    }}
                  >
                    {item.category}
                  </p>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
}
