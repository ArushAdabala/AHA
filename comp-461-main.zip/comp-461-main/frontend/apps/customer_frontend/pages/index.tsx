import Head from "next/head";
import styled from "styled-components";
import { useQuery } from "convex/react";
import styles from "../styles/Home.module.css";
import HomeLayout from "../components/Layouts/HomeLayout";
import { api } from "../../../packages/backend/convex/_generated/api";
import Link from "next/link";

const BusinessesSection = styled.section`
  width: 100%;
  max-width: 1152px;
  margin: 30px auto;
  padding: 0 32px;

  @media screen and (max-width: 1280px) {
    max-width: 100%;
    margin: 30px 64px;
  }

  @media screen and (max-width: 960px) {
    margin: 30px 32px;
  }

  @media screen and (max-width: 770px) {
    margin: 30px 0;
    padding: 0 32px;
  }

  @media screen and (max-width: 480px) {
    margin: 15px 0;
    padding: 0 16px;
  }
`;

const BusinessesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 24px;
  margin-top: 24px;

  @media screen and (max-width: 480px) {
    grid-template-columns: 1fr;
    gap: 16px;
  }
`;

const BusinessCard = styled.article`
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s, box-shadow 0.2s;
  cursor: pointer;
  background: white;

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  }
`;

const BusinessCardLink = styled.a`
  text-decoration: none;
  color: inherit;
  display: block;
`;

const BusinessImageWrapper = styled.div`
  width: 100%;
  height: 200px;
  background: #f3f4f6;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #9ca3af;
  font-size: 14px;
`;

const BusinessInfo = styled.div`
  padding: 16px;
`;

const BusinessName = styled.h3`
  font-size: 18px;
  font-weight: 600;
  margin: 0 0 8px 0;
  color: #111827;
`;

const BusinessDescription = styled.p`
  font-size: 14px;
  color: #6b7280;
  margin: 0 0 12px 0;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

const BusinessCategories = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
`;

const CategoryTag = styled.span`
  font-size: 12px;
  padding: 4px 8px;
  background: #f3f4f6;
  border-radius: 4px;
  color: #4b5563;
`;

const LoadingMessage = styled.div`
  text-align: center;
  padding: 48px;
  color: #6b7280;
  font-size: 16px;
`;

const EmptyMessage = styled.div`
  text-align: center;
  padding: 48px;
  color: #6b7280;
  font-size: 16px;
`;

export default function Home() {
  const businesses = useQuery(api.businesses.list, { onlyActive: true });

  return (
    <>
      <Head>
        <title>Aha Drone Delivery</title>
        <meta
          name="Aha"
          content="Aha Drone Delivery - Fast drone deliveries from nearby partners"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <HomeLayout>
        <main className={styles.main}>
          <BusinessesSection>
            {businesses === undefined ? (
              <LoadingMessage>Loading businesses...</LoadingMessage>
            ) : businesses.length === 0 ? (
              <EmptyMessage>No businesses available at this time.</EmptyMessage>
            ) : (
              <BusinessesGrid>
                {businesses.map((business) => (
                  <BusinessCard key={business._id}>
                    <Link href={`/store/${business._id}`} passHref legacyBehavior>
                      <BusinessCardLink>
                        <BusinessImageWrapper>
                          {business.imageUrl ? (
                            <img
                              src={business.imageUrl}
                              alt={business.name}
                              style={{
                                width: "100%",
                                height: "100%",
                                objectFit: "cover",
                              }}
                            />
                          ) : (
                            business.name.charAt(0)
                          )}
                        </BusinessImageWrapper>
                        <BusinessInfo>
                          <BusinessName>{business.name}</BusinessName>
                          {business.description && (
                            <BusinessDescription>
                              {business.description}
                            </BusinessDescription>
                          )}
                          {business.categories && business.categories.length > 0 && (
                            <BusinessCategories>
                              {business.categories.map((category, idx) => (
                                <CategoryTag key={idx}>{category}</CategoryTag>
                              ))}
                            </BusinessCategories>
                          )}
                        </BusinessInfo>
                      </BusinessCardLink>
                    </Link>
                  </BusinessCard>
                ))}
              </BusinessesGrid>
            )}
          </BusinessesSection>
        </main>
      </HomeLayout>
    </>
  );
}
