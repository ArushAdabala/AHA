import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Id } from '../../../../../packages/backend/convex/_generated/dataModel';

interface ICartState {
    businessId?: string; // Convex business ID as string
    isOpenFromCartSheet?: boolean;
    pageViewingBusinessId?: string; // Convex business ID as string
    cart: ICartItem[];
    totalValue: number;
    // Map of itemId to price for calculating totals
    itemPrices: Record<string, number>;
}

interface ICartItem {
    itemId: string; // Convex item ID as string
    quantity: number;
}

const initialState: ICartState = {
    isOpenFromCartSheet: false,
    cart: [],
    totalValue: 0,
    itemPrices: {},
};

function immutableCalculateCartTotal(state: ICartState) {
    let sum = 0;
    state.cart.forEach((item) => {
        const price = state.itemPrices[item.itemId] || 0;
        sum += item.quantity * price;
    });
    state.totalValue = sum;
}

// cartSlice needs access to the storeID to ensure that all items in the cart are from storeID.
// Without storeID validation, the cart could contain items from multiple stores, which is
//  disallowed in standard DD delivery
// (with exception of having dasher pick up items after a delivery has been dispatched)
const cartSlice = createSlice({
    name: 'cart',
    initialState,
    reducers: {
        toggleIsOpenFromCartSheet: (state) => {
            state.isOpenFromCartSheet = !state.isOpenFromCartSheet;
        },

        setFalseIsOpenFromCartSheet: (state) => {
            state.isOpenFromCartSheet = false;
        },

        setPageViewingBusinessId: (state, action: PayloadAction<string>) => {
            state.pageViewingBusinessId = action.payload;
        },

        setBusinessId: (state, action: PayloadAction<string>) => {
            state.businessId = action.payload;
        },

        // if the user adds an item from a different store, we need to
        // reset the businessId and cart to the businessId of the new item they were looking at
        resetCartNewStore: (state, action: PayloadAction<string>) => {
            state.businessId = action.payload;
            state.cart = [];
            state.itemPrices = {};
            immutableCalculateCartTotal(state);
        },

        // Set item price (used when adding items to cart)
        setItemPrice: (state, action: PayloadAction<{ itemId: string; price: number }>) => {
            state.itemPrices[action.payload.itemId] = action.payload.price;
            immutableCalculateCartTotal(state);
        },

        // the user adds an item, passing the itemId and price
        addItemToCart: (state, action: PayloadAction<ICartItem & { price: number }>) => {
            // Store the price for this item
            state.itemPrices[action.payload.itemId] = action.payload.price;

            // loop through cart items to see if the itemId exists.
            // if it exists, then just increment the quantity.
            // if it does not exist, then add the new item to a copy of the existing cart state.

            let itemExists = false;
            const newState = { ...state }; // create a copy of the state
            for (let i = 0; i < newState.cart.length; i++) {
                if (newState.cart[i].itemId === action.payload.itemId) {
                    newState.cart[i].quantity += action.payload.quantity;
                    itemExists = true;
                    break;
                }
            }

            if (!itemExists) {
                newState.cart = [
                    ...newState.cart,
                    {
                        itemId: action.payload.itemId,
                        quantity: action.payload.quantity,
                    },
                ];
            }
            state.cart = newState.cart;
            immutableCalculateCartTotal(state);
        },

        // reduces the quantity of an item in a cart if quantity > 0
        // if quantity is 1 and user hits delete, item should be removed from list
        deleteItemFromCart: (state, action: PayloadAction<string>) => {
            const newState = { ...state };
            for (let i = 0; i < newState.cart.length; i++) {
                if (
                    newState.cart[i].itemId === action.payload &&
                    newState.cart[i].quantity > 1
                ) {
                    newState.cart[i].quantity -= 1;
                    break;
                } else if (
                    newState.cart[i].itemId === action.payload &&
                    newState.cart[i].quantity === 1
                ) {
                    // if state.cart[i].quantity is 1, then filter out that item altogether.
                    newState.cart = newState.cart.filter(
                        (item) => item.itemId !== action.payload
                    );
                    // Remove price from map
                    delete state.itemPrices[action.payload];
                    break;
                }
            }
            state.cart = newState.cart;
            immutableCalculateCartTotal(state);
        },

        // Clear cart (useful after order is placed)
        clearCart: (state) => {
            state.cart = [];
            state.itemPrices = {};
            state.totalValue = 0;
        },
    },
});

export const {
    toggleIsOpenFromCartSheet,
    setFalseIsOpenFromCartSheet,
    setPageViewingBusinessId,
    setBusinessId,
    resetCartNewStore,
    setItemPrice,
    addItemToCart,
    deleteItemFromCart,
    clearCart,
} = cartSlice.actions;
export default cartSlice.reducer;
