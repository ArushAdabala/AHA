import Link from "next/link";
import styled from "styled-components";
import { useState, useMemo } from "react";
import { SignedIn, SignedOut, UserButton, SignInButton } from "@clerk/nextjs";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../../packages/backend/convex/_generated/api";
import HamburgerButton from "./HamburgerButton";
import HomeLogoLink from "./HomeLogoLink";
import AddressButtonToggle from "./AddressButtonToggle";
import SearchBar from "./SearchBar";
import ShoppingCartButton from "./ShoppingCartButton";
import AddressModal from "../AddressModal/AddressModal";

// Navbar styles

const NavbarWrapper = styled.nav`
  position: fixed;
  top: 0;
  overscroll-behavior-y: none;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  height: 64px;
  background-color: var(--primary-white);
  border: 1px solid var(--primary-gray);
  border-top: none;
  border-right: none;
  border-left: none;
  padding-left: 64px;
  padding-right: 144px;
  z-index: 3;

  @media screen and (max-width: 1185px) {
    padding-left: 0;
    padding-right: 48px;
  }

  @media screen and (max-width: 960px) {
    padding-left: 0;
    padding-right: 16px;
  }
`;

const NavbarSubLeft = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  column-gap: 2px;

  @media screen and (max-width: 1280px) {
    min-width: 496px;
  }

  @media screen and (max-width: 960px) {
    justify-content: flex-start;
    min-width: fit-content;
  }

  @media screen and (max-width: 770px) {
    margin-right: 30px;
  }
`;

const NavbarLinkGroup = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-left: 32px;
  margin-right: 16px;

  @media screen and (max-width: 770px) {
    display: none;
  }
`;

const NavbarLinkWrapper = styled.div`
  display: flex;
  column-gap: 24px;
  text-decoration: none;
  list-style: none;
`;

const NavbarLinkInner = styled.a`
  padding: 10px 0;
`;

const NavbarLabel = styled.span`
  font-family: var(--primary-font-family);
  font-size: var(--nav-label-font-size);
  font-weight: var(--nav-label-font-weight);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
`;

const NavbarVerticalDivider = styled.hr`
  width: 0px;
  height: 24px;
  border: 1px solid var(--primary-gray);
  border-radius: 2px;

  @media screen and (max-width: 960px) {
    display: none;
  }
`;

const NavbarSubRight = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  column-gap: 16px;

  @media screen and (max-width: 1185px) {
    width: 100%;
    justify-content: flex-end;
  }

  @media screen and (max-width: 960px) {
    padding-right: 24px;
  }

  @media screen and (max-width: 770px) {
    width: 100%;
  }
`;

type TNavBar = {
  isShoppingCartToggleable: boolean;
};

export default function Navbar({ isShoppingCartToggleable }: TNavBar) {
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isSearchBarToggled, setIsSearchBarToggled] = useState(false);

  // Fetch current customer from Convex
  const customer = useQuery(api.customers.getCurrent);
  const updateDefaultAddress = useMutation(api.customers.updateDefaultAddress);

  // Format address from Convex customer data
  const currentAddress = useMemo(() => {
    if (customer?.defaultDeliveryAddress) {
      const addr = customer.defaultDeliveryAddress;
      const addressParts = [addr.line1];
      if (addr.line2) addressParts.push(addr.line2);
      if (addr.city) addressParts.push(addr.city);
      if (addr.state) addressParts.push(addr.state);
      if (addr.postalCode) addressParts.push(addr.postalCode);
      return addressParts.join(", ");
    }
    // Show "Select Address" if not logged in or no address set
    return "Select Address";
  }, [customer]);

  const handleSaveAddress = async (address: {
    line1: string;
    line2?: string;
    city: string;
    state?: string;
    postalCode?: string;
  }) => {
    try {
      // Save address to Convex
      await updateDefaultAddress({
        address: {
          line1: address.line1,
          line2: address.line2,
          city: address.city,
          state: address.state,
          postalCode: address.postalCode,
        },
      });
      // The address will automatically update when the customer query refetches
    } catch (error) {
      console.error("Error saving address:", error);
    }
  };

  return (
    <>
      <NavbarWrapper>
        <NavbarSubLeft>
          <HamburgerButton />
          <HomeLogoLink />
          <NavbarLinkGroup>
            <NavbarLinkWrapper>
              <Link href="/" passHref legacyBehavior>
                <NavbarLinkInner>
                  <NavbarLabel aria-label="Delivery.">Delivery</NavbarLabel>
                </NavbarLinkInner>
              </Link>
              {/* <Link href="/pickup" passHref legacyBehavior>
                            <NavbarLinkInner>
                                <NavbarLabel aria-label="Pickup.">
                                    Pickup
                                </NavbarLabel>
                            </NavbarLinkInner>
                        </Link> */}
            </NavbarLinkWrapper>
          </NavbarLinkGroup>
          <NavbarVerticalDivider />
          <NavbarLinkWrapper>
            <AddressButtonToggle
              setIsAddressButtonToggled={() => setIsAddressModalOpen(true)}
              currentAddress={currentAddress}
            />
          </NavbarLinkWrapper>
        </NavbarSubLeft>
        <NavbarSubRight>
          <SearchBar
            isSearchBarToggled={isSearchBarToggled}
            setIsSearchBarToggled={setIsSearchBarToggled}
          />
          <ShoppingCartButton
            isShoppingCartToggleable={isShoppingCartToggleable}
          />
          <SignedIn>
            <UserButton afterSignOutUrl="/" />
          </SignedIn>
          <SignedOut>
            <SignInButton mode="modal">
              <button
                style={{
                  padding: "8px 16px",
                  border: "1px solid #d1d5db",
                  borderRadius: "6px",
                  background: "white",
                  cursor: "pointer",
                  fontSize: "14px",
                  fontWeight: 500,
                }}
              >
                Sign In
              </button>
            </SignInButton>
          </SignedOut>
        </NavbarSubRight>
      </NavbarWrapper>
      <AddressModal
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
        currentAddress={currentAddress}
        currentAddressData={customer?.defaultDeliveryAddress}
        onSaveAddress={handleSaveAddress}
      />
    </>
  );
}
