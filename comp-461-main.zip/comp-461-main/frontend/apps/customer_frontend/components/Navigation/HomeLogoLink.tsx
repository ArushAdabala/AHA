import Link from "next/link";
import styled from "styled-components";

const HomeLogoLinkStyle = styled.a`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 12px;
`;

const BrandLogoText = styled.div`
  display: flex;
  align-items: center;

  @media screen and (max-width: 960px) {
    display: none;
  }
`;

export default function HomeLogoLink() {
  return (
    <Link href="/" passHref legacyBehavior>
      <HomeLogoLinkStyle aria-label="Aha Homepage">
        <BrandLogoText>
          <span
            style={{
              fontWeight: 700,
              fontSize: "18px",
              color: "var(--primary-black)",
            }}
          >
            Aha
          </span>
        </BrandLogoText>
      </HomeLogoLinkStyle>
    </Link>
  );
}
