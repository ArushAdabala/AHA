import styled from "styled-components";
import { useState, useRef, useEffect } from "react";
import FocusTrap from "focus-trap-react";
import { Transition } from "react-transition-group";
import X from "../Icons/XIcon";

const ModalOverlay = styled.div<{ state: string }>`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: ${(props) => (props.state === "entered" ? 1 : 0)};
  transition: opacity 0.2s ease;
  pointer-events: ${(props) => (props.state === "entered" ? "all" : "none")};
`;

const ModalContent = styled.div<{ state: string }>`
  background: white;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  transform: ${(props) =>
    props.state === "entered" ? "scale(1)" : "scale(0.95)"};
  transition: transform 0.2s ease;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.2);
`;

const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 24px;
  border-bottom: 1px solid #e5e7eb;
`;

const ModalTitle = styled.h2`
  font-size: 20px;
  font-weight: 600;
  margin: 0;
  color: #111827;
`;

const CloseButton = styled.button`
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #6b7280;
  transition: color 0.2s;

  &:hover {
    color: #111827;
  }
`;

const ModalBody = styled.div`
  padding: 24px;
`;

const SearchInput = styled.input`
  width: 100%;
  padding: 12px 16px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 16px;
  margin-bottom: 16px;
  transition: border-color 0.2s;

  &:focus {
    outline: none;
    border-color: #3b82f6;
  }
`;

const AddressForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 16px;
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`;

const FormLabel = styled.label`
  font-size: 14px;
  font-weight: 500;
  color: #374151;
`;

const FormInput = styled.input`
  padding: 12px 16px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 16px;
  transition: border-color 0.2s;

  &:focus {
    outline: none;
    border-color: #3b82f6;
  }
`;

const FormRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;

  @media screen and (max-width: 480px) {
    grid-template-columns: 1fr;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 12px;
  margin-top: 8px;
`;

const Button = styled.button<{ variant?: "primary" | "secondary" }>`
  flex: 1;
  padding: 12px 24px;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;

  ${(props) =>
    props.variant === "primary"
      ? `
    background-color: #3b82f6;
    color: white;
    &:hover {
      background-color: #2563eb;
    }
  `
      : `
    background-color: #f3f4f6;
    color: #374151;
    &:hover {
      background-color: #e5e7eb;
    }
  `}
`;

type AddressModalProps = {
  isOpen: boolean;
  onClose: () => void;
  currentAddress?: string;
  currentAddressData?: {
    line1: string;
    line2?: string;
    city: string;
    state?: string;
    postalCode?: string;
  };
  onSaveAddress: (address: {
    line1: string;
    line2?: string;
    city: string;
    state?: string;
    postalCode?: string;
  }) => void;
};

export default function AddressModal({
  isOpen,
  onClose,
  currentAddress,
  currentAddressData,
  onSaveAddress,
}: AddressModalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [formData, setFormData] = useState({
    line1: "",
    line2: "",
    city: "",
    state: "",
    postalCode: "",
  });
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (currentAddressData) {
      // Use structured address data if available
      setFormData({
        line1: currentAddressData.line1 || "",
        line2: currentAddressData.line2 || "",
        city: currentAddressData.city || "",
        state: currentAddressData.state || "",
        postalCode: currentAddressData.postalCode || "",
      });
    } else if (currentAddress) {
      // Fallback to string address (for backward compatibility)
      setFormData({
        line1: currentAddress,
        line2: "",
        city: "",
        state: "",
        postalCode: "",
      });
    }
  }, [currentAddress, currentAddressData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.line1 && formData.city) {
      onSaveAddress(formData);
      onClose();
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    // In a real app, you would call a geocoding API here
    // For now, we'll just update the line1 field
    if (e.target.value) {
      setFormData((prev) => ({ ...prev, line1: e.target.value }));
    }
  };

  return (
    <Transition in={isOpen} timeout={200} unmountOnExit>
      {(state) => (
        <ModalOverlay state={state} onClick={onClose}>
          <FocusTrap active={isOpen}>
            <ModalContent
              state={state}
              ref={modalRef}
              onClick={(e) => e.stopPropagation()}
            >
              <ModalHeader>
                <ModalTitle>Enter Delivery Address</ModalTitle>
                <CloseButton onClick={onClose} aria-label="Close">
                  <X />
                </CloseButton>
              </ModalHeader>
              <ModalBody>
                <SearchInput
                  type="text"
                  placeholder="Search for an address..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                />
                <AddressForm onSubmit={handleSubmit}>
                  <FormGroup>
                    <FormLabel>Street Address</FormLabel>
                    <FormInput
                      type="text"
                      required
                      value={formData.line1}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          line1: e.target.value,
                        }))
                      }
                      placeholder="123 Main Street"
                    />
                  </FormGroup>
                  <FormGroup>
                    <FormLabel>Apartment, suite, etc. (optional)</FormLabel>
                    <FormInput
                      type="text"
                      value={formData.line2}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          line2: e.target.value,
                        }))
                      }
                      placeholder="Apt 4B"
                    />
                  </FormGroup>
                  <FormRow>
                    <FormGroup>
                      <FormLabel>City</FormLabel>
                      <FormInput
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            city: e.target.value,
                          }))
                        }
                        placeholder="Houston"
                      />
                    </FormGroup>
                    <FormGroup>
                      <FormLabel>State</FormLabel>
                      <FormInput
                        type="text"
                        value={formData.state}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            state: e.target.value,
                          }))
                        }
                        placeholder="TX"
                        maxLength={2}
                      />
                    </FormGroup>
                  </FormRow>
                  <FormGroup>
                    <FormLabel>ZIP Code</FormLabel>
                    <FormInput
                      type="text"
                      value={formData.postalCode}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          postalCode: e.target.value,
                        }))
                      }
                      placeholder="77001"
                    />
                  </FormGroup>
                  <ButtonGroup>
                    <Button type="button" variant="secondary" onClick={onClose}>
                      Cancel
                    </Button>
                    <Button type="submit" variant="primary">
                      Save Address
                    </Button>
                  </ButtonGroup>
                </AddressForm>
              </ModalBody>
            </ModalContent>
          </FocusTrap>
        </ModalOverlay>
      )}
    </Transition>
  );
}
