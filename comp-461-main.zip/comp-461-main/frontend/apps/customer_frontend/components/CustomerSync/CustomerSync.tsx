import { useEffect } from "react";
import { useUser } from "@clerk/nextjs";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../../packages/backend/convex/_generated/api";

/**
 * Component that automatically creates a customer record in Convex
 * when a user signs in with Clerk, if one doesn't already exist.
 */
export default function CustomerSync() {
  const { user, isLoaded } = useUser();
  const customer = useQuery(api.customers.getCurrent);
  const createCustomer = useMutation(api.customers.create);

  useEffect(() => {
    // Wait for Clerk to load
    if (!isLoaded) return;

    // Only proceed if user is signed in
    if (!user) return;

    // If customer already exists, do nothing
    if (customer !== undefined && customer !== null) return;

    // If customer query is still loading, wait
    if (customer === undefined) return;

    // Create customer record with Clerk user info
    const createCustomerRecord = async () => {
      try {
        await createCustomer({
          name: user.fullName || user.firstName || undefined,
          email: user.primaryEmailAddress?.emailAddress || undefined,
          phone: user.primaryPhoneNumber?.phoneNumber || undefined,
        });
      } catch (error) {
        // If customer already exists (race condition), that's fine
        if (
          error instanceof Error &&
          error.message.includes("already exists")
        ) {
          console.log("Customer already exists");
        } else {
          console.error("Error creating customer:", error);
        }
      }
    };

    createCustomerRecord();
  }, [user, isLoaded, customer, createCustomer]);

  // This component doesn't render anything
  return null;
}
