/* eslint-disable react/jsx-no-bind */
import styled from 'styled-components';
import Minus from '../../Icons/MinusIcon';
import Plus from '../../Icons/PlusIcon';
import GarbageCan from '../../Icons/GarbageCanIcon';

// redux global state
import { useAppDispatch, useAppSelector } from '../../../app-redux/hooks';
import { addItemToCart, deleteItemFromCart } from '../../../app-redux/features/cart/cartSlice';

const InputStepperWrapper = styled.div`
    display: flex;
    align-items: center;
    background-color: var(--secondary-gray);
    border-radius: 17px;
    box-shadow: rgb(0 0 0 / 20%) 0px 2px 8px;
    margin-left: auto;
`;

const InputStepperButton = styled.button`
    display: flex;
    justify-content: center;
    align-items: center;
    width: 32px;
    height: 32px;
    border-radius: 500px;
    background-color: var(--primary-white);
    color: inherit;

    &:hover {
        cursor: pointer;
    }

    &:visited {
        color: inherit;
    }
`;

const InputStepperLabelWrapper = styled.div`
    display: flex;
    justify-content: center;
    min-width: 32px;
`;

const InputStepperLabel = styled.span`
    font-weight: 500;
    font-size: 14px;
    color: var(--primary-black);
`;

type TInputStepper = {
    itemId: string; // Convex item ID
    price: number; // Item price for adding to cart
};

export default function InputStepper({ itemId, price }: TInputStepper) {
    const stateCart = useAppSelector((state) => state.cartSlice.cart);
    const itemPrices = useAppSelector((state) => state.cartSlice.itemPrices);
    let quantityCart = 0;

    stateCart.forEach((item) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        itemId === item.itemId ? quantityCart = item.quantity : null;
    });

    /**
     * TODO: Values need to be debounced before they are dispatched to global store.
     * REVISION: Values can be directly dispatched to global store. the reducer itself will take care of
     * debouncing since it will post to the server then.
     */

    const dispatch = useAppDispatch();

    function handleClickIncrement() {
        const itemPrice = itemPrices[itemId] || price;
        const cartPayload = {
            itemId,
            quantity: 1,
            price: itemPrice,
        };
        dispatch(addItemToCart(cartPayload));
    }

    function handleClickDecrement() {
        if (quantityCart > 1) {
            dispatch(deleteItemFromCart(itemId));
        } else if (quantityCart === 1) {
            // delete item and remove from list if stepperCount reaches 0.
            dispatch(deleteItemFromCart(itemId));
        }
    }

    return (
        <InputStepperWrapper
            aria-relevant="removals additions"
        >
            <InputStepperButton
                onClick={handleClickDecrement}
                aria-label={`Subtract quantity. Currently at ${quantityCart} items.`}
            >
                {quantityCart === 1 ?
                    <GarbageCan />
                    :
                    <Minus />}
            </InputStepperButton>
            <InputStepperLabelWrapper>
                <InputStepperLabel
                    aria-label="Quantity: "
                    aria-live="polite"
                    aria-atomic="true"
                >
                    {quantityCart}
                    {' '}
                    ×
                </InputStepperLabel>
            </InputStepperLabelWrapper>
            <InputStepperButton
                onClick={handleClickIncrement}
                aria-label={`Add quantity. Currently at ${quantityCart} items.`}
            >
                <Plus />
            </InputStepperButton>
        </InputStepperWrapper>
    );
}
