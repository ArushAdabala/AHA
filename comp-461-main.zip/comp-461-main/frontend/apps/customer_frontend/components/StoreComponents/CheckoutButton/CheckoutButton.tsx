import styled from "styled-components";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../../../../packages/backend/convex/_generated/api";
import { Id } from "../../../../../packages/backend/convex/_generated/dataModel";
import { useRouter } from "next/router";
import { useAppSelector, useAppDispatch } from "../../../app-redux/hooks";
import { clearCart } from "../../../app-redux/features/cart/cartSlice";

const CheckoutButtonWrapper = styled.button`
  width: 100%;
  height: 40px;
  display: flex;
  align-items: center;
  background-color: var(--primary-black);
  border-radius: 20px;
  transition: ease 0.15s;
  transition-property: background-color;

  &:hover {
    background-color: var(--primary-black);
    transition: ease 0.15s;
    transition-property: background-color;
    cursor: pointer;
  }

  &:active {
    transition: 0.15s ease;
    transition-property: background-color;
    background-color: var(--primary-black);
  }
`;

const CheckoutButtonTextWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 0 16px;
  width: 100%;
`;

const CheckoutButtonCheckoutLabel = styled.span`
  font-size: 16px;
  font-weight: 500;
  color: var(--primary-white);
`;

const CheckoutButtonPriceLabel = styled.span`
  font-size: 16px;
  font-weight: 500;
  color: var(--primary-white);
`;

export default function CheckoutButton() {
  const cartTotalValue = useAppSelector(
    (state: any) => state.cartSlice.totalValue
  );
  const cart = useAppSelector((state: any) => state.cartSlice.cart);
  const itemPrices = useAppSelector((state: any) => state.cartSlice.itemPrices);
  const businessId = useAppSelector((state: any) => state.cartSlice.businessId);
  const dispatch = useAppDispatch();
  const router = useRouter();
  const createOrder = useMutation(api.orders.create);

  // Fetch customer to get default delivery address
  const customer = useQuery(api.customers.getCurrent);

  const priceFormatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  });

  const handleCheckout = async () => {
    if (cart.length === 0 || !businessId) {
      return;
    }

    // Check if customer has a delivery address
    if (!customer?.defaultDeliveryAddress) {
      alert("Please set a delivery address before checking out.");
      return;
    }

    try {
      // Convert cart items to line items format
      const lineItems = cart.map(
        (cartItem: { itemId: string; quantity: number }) => {
          const priceCents = Math.round(
            (itemPrices[cartItem.itemId] || 0) * 100
          );
          return {
            itemId: cartItem.itemId as Id<"items">,
            quantity: cartItem.quantity,
            priceCents,
          };
        }
      );

      // Create order in Convex with delivery address
      const orderId = await createOrder({
        lineItems,
        deliveryMethod: "delivery", // TODO: Allow user to select delivery method
        deliveryAddress: customer.defaultDeliveryAddress,
      });

      // Clear cart after successful order
      dispatch(clearCart());

      // Redirect to order details page
      router.push(`/orders/${orderId}`);
    } catch (error) {
      console.error("Failed to create order:", error);
      // TODO: Show error message to user
      alert("Failed to create order. Please try again.");
    }
  };

  return (
    <CheckoutButtonWrapper onClick={handleCheckout}>
      <CheckoutButtonTextWrapper>
        <CheckoutButtonCheckoutLabel>Checkout</CheckoutButtonCheckoutLabel>
        <CheckoutButtonPriceLabel>
          {priceFormatter.format(cartTotalValue)}
        </CheckoutButtonPriceLabel>
      </CheckoutButtonTextWrapper>
    </CheckoutButtonWrapper>
  );
}
