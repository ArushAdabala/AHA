import styled from "styled-components";
import Heart from "../../../Icons/HeartIcon";
import GroupOfPeople from "../../../Icons/GroupOfPeopleIcon";

// redux global state
import { useAppSelector, useAppDispatch } from "../../../../app-redux/hooks";
// Removed: import { toggleDeliveryState } from "../../../../app-redux/features/delivery/deliverySlice";

const AuxOptionsWrapper = styled.div`
  display: flex;
  height: 40px;
  column-gap: 15px;
  margin-bottom: 5px;

  @media screen and (max-width: 480px) {
    align-items: center;
  }
`;

const AuxOptionsButtonPrimary = styled.button`
  display: flex;
  height: 100%;
  background-color: var(--primary-gray);
  transition: 0.15s ease;
  transition-property: background-color;
  align-items: center;
  border: none;
  border-radius: 20px;
  padding: 0 12px;
  column-gap: 10px;
  color: inherit;

  &:hover {
    cursor: pointer;
    transition: 0.15s ease;
    transition-property: background-color;
    background-color: var(--secondary-gray);
  }

  // equivalent to onMouseDown
  &:active {
    transition: 0.15s ease;
    transition-property: background-color;
    background-color: var(--quaternary-gray);
  }

  &:visited {
    color: inherit;
    background-color: inherit;
  }

  @media screen and (max-width: 480px) {
    padding: 0 8px;
    height: 32px;
  }
`;

const AuxOptionsButtonLabel = styled.span`
  font-size: 14px;
  font-weight: 500;
  color: var(--primary-black);

  @media screen and (max-width: 480px) {
    display: none;
  }
`;

const AuxOptionsDeliveryTag = styled.div`
  display: flex;
  align-items: center;
  height: 100%;
  background-color: var(--primary-gray);
  border: none;
  border-radius: 20px;
  position: relative;
  overflow: hidden;
  padding: 0 24px;
  transition: 0.15s ease;
  transition-property: background-color;

  @media screen and (max-width: 480px) {
    padding: 0 12px;
    height: 32px;
  }
`;

const AuxOptionsDeliveryLabelWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  row-gap: 1px;
  margin-bottom: 1px;
`;

const AuxOptionsDeliveryLabel = styled.span`
  font-size: 14px;
  font-weight: 500;
  color: var(--primary-black);
`;

const AuxOptionsDeliveryLabelSmall = styled.span`
  font-size: 12px;
  color: var(--quaternary-gray);
`;

type TAuxOptions = {
  deliveryTime: string;
  pickupTime: string; // unused now, but kept for type compatibility
};

export default function AuxOptions({ deliveryTime, pickupTime }: TAuxOptions) {
  // const isDelivery = useAppSelector((state) => state.deliverySlice.isDelivery);
  // const dispatch = useAppDispatch();

  return (
    <AuxOptionsWrapper>
      <AuxOptionsButtonPrimary>
        <Heart />
        <AuxOptionsButtonLabel>Save</AuxOptionsButtonLabel>
      </AuxOptionsButtonPrimary>
      <AuxOptionsButtonPrimary>
        <GroupOfPeople />
        <AuxOptionsButtonLabel>Group Order</AuxOptionsButtonLabel>
      </AuxOptionsButtonPrimary>
      {/*
        Instead of using a styled.button, we're using a styled.div here for AuxOptionsDeliveryTag 
        so that React's children prop is correctly passed (styled.button expects HTMLButton props).
      */}
      <AuxOptionsDeliveryTag as="div" aria-label="Delivery" role="status">
        <AuxOptionsDeliveryLabelWrapper>
          <AuxOptionsDeliveryLabel>Delivery</AuxOptionsDeliveryLabel>
          <AuxOptionsDeliveryLabelSmall>
            {deliveryTime}
          </AuxOptionsDeliveryLabelSmall>
        </AuxOptionsDeliveryLabelWrapper>
      </AuxOptionsDeliveryTag>
    </AuxOptionsWrapper>
  );
}
