declare module "react-redux" {
  import * as React from "react";
  export interface ProviderProps {
    store: any;
    context?: any;
    children?: React.ReactNode;
  }
  export const Provider: React.ComponentType<ProviderProps>;
  export { Provider as ReduxProvider };
}


