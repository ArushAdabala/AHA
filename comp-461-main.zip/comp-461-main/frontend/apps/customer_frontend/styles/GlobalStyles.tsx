import { createGlobalStyle } from "styled-components";

const GlobalStyles = createGlobalStyle`
    :root {
        /* Semantic Color Tokens (mapped from system variables) */
        --text-primary: rgba(25, 25, 25, 1);
        --text-muted: rgba(96, 96, 96, 1);
        --bg-primary: rgba(255, 255, 255, 1);
        --bg-subtle: rgba(247, 247, 247, 1);
        --border-default: rgba(231, 231, 231, 1);
        --border-strong: rgba(214, 214, 214, 1);
        --accent: rgba(0, 131, 138, 1); /* Aha accent */
        --accent-contrast: rgba(255, 255, 255, 1);
        --destructive: rgba(183, 16, 0, 1);
        --success: rgba(0, 135, 47, 1);
        --warning: rgba(161, 108, 0, 1);

        /* Back-compat existing variables mapped to semantic tokens */
        --primary-black: var(--text-primary);
        --primary-black-transparency-75: rgba(25, 25, 25, 0.75);
        --secondary-black: rgba(73, 73, 73, 1);
        --primary-gray: var(--border-default);
        --secondary-gray: var(--bg-subtle);
        --tertiary-gray: var(--text-muted);
        --quaternary-gray: var(--border-strong);
        --quinary-gray: rgba(118, 118, 118, 1);
        --primary-white: var(--bg-primary);
        --primary-red: rgba(255, 48, 8, 1);
        --secondary-red: rgba(235, 23, 0, 1);
        --tertiary-red: rgba(217, 20, 0, 1);
        --quaternary-red: rgba(183, 16, 0, 1);
        --primary-teal: var(--accent);
        --primary-green: var(--success);
        --primary-gold: var(--warning);
        
        /* System Font Family Variable */
        --primary-font-family: 'TTNorms';
        
        /* Nav Label Font Option Variables */
        --nav-label-font-size: 14px;
        --nav-label-font-weight: 500;
    }

    * {
        /* Setting default font family and disabling ligatures */
        font-family: var(--primary-font-family);
        font-variant-ligatures: no-common-ligatures;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
`;

export default GlobalStyles;
