"use client";

import * as React from "react";
import { useMemo } from "react";
import { useQuery } from "convex/react";
import { api } from "@packages/backend/convex/_generated/api";
import { ChevronDown, History, ListOrdered } from "lucide-react";
import Head from "next/head";

import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { AppSidebar } from "@/components/app-sidebar";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import { PageHeader } from "@/components/page-header";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

type OrderStatus = "Pending" | "En Route" | "Delivered" | "Cancelled";

type Order = {
  id: string;
  status: OrderStatus;
  droneport: string;
  pickup: string;
  dropoff: string;
  contents: string;
};

// Fake droneports for now (same as dashboard)
const FAKE_DRONEPORTS = [
  "IAH Droneport",
  "Pearland Droneport",
  "Sugar Land Droneport",
  "Houston Droneport",
  "Katy Droneport",
  "The Woodlands Droneport",
];

// Helper to format address string
function formatAddress(
  address?: {
    line1?: string;
    line2?: string;
    city?: string;
    state?: string;
    postalCode?: string;
  } | null
): string {
  if (!address) return "Unknown";
  const parts = [
    address.line1,
    address.line2,
    address.city,
    address.state,
    address.postalCode,
  ].filter(Boolean);
  return parts.join(", ") || "Unknown";
}

// Helper to map Convex order status to display status
function mapStatus(
  status: "pending" | "paid" | "preparing" | "delivering" | "completed" | "cancelled"
): OrderStatus {
  if (status === "cancelled") return "Cancelled";
  if (status === "completed") return "Delivered";
  if (status === "delivering") return "En Route";
  return "Pending"; // pending, paid, preparing
}

// Helper to generate contents description from line items
function getContentsDescription(lineItems: Array<{ quantity: number }>): string {
  const totalItems = lineItems.reduce((sum, item) => sum + item.quantity, 0);
  // Estimate weight: roughly 1-2kg per item
  const estimatedWeight = (totalItems * 1.5).toFixed(1);
  return `${totalItems} item${totalItems !== 1 ? "s" : ""}: ~${estimatedWeight}kg`;
}

function StatusTag({ status }: { status: OrderStatus }) {
  const colorClass =
    status === "Pending"
      ? "bg-secondary text-secondary-foreground"
      : status === "En Route"
      ? "bg-primary text-primary-foreground"
      : status === "Delivered"
      ? "bg-accent text-accent-foreground"
      : "bg-muted text-muted-foreground";

  return (
    <span
      className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ${colorClass}`}
    >
      {status}
    </span>
  );
}

function OrderRow({ order }: { order: Order }) {
  return (
    <Collapsible className="rounded-lg border bg-card text-card-foreground shadow-sm">
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <div className="font-medium">{order.id}</div>
          <Separator orientation="vertical" className="mx-1 h-4" />
          <StatusTag status={order.status} />
        </div>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm">
            Details
            <ChevronDown className="ml-2 size-4" />
          </Button>
        </CollapsibleTrigger>
      </div>
      <Separator />
      <CollapsibleContent>
        <div className="grid gap-4 p-3 text-sm md:grid-cols-2">
          <div>
            <div className="text-muted-foreground">Droneport</div>
            <div className="font-medium">{order.droneport}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Pickup</div>
            <div className="font-medium">{order.pickup}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Dropoff</div>
            <div className="font-medium">{order.dropoff}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Contents</div>
            <div className="font-medium">{order.contents}</div>
          </div>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

export default function OrdersPage() {
  const [showHistorical, setShowHistorical] = React.useState(false);

  // Fetch all orders from Convex
  const convexOrders = useQuery(api.orders.listAll, {});

  // Transform Convex orders to display format
  const allOrders: Order[] = useMemo(() => {
    if (!convexOrders) return [];

    return convexOrders.map((order, index) => {
      // Get business address for pickup
      const businessAddress = order.business?.address;
      const pickupAddress = formatAddress(businessAddress);

      // Get delivery address for dropoff
      const deliveryAddress = order.deliveryAddress;
      const dropoffAddress = formatAddress(deliveryAddress);

      // Assign fake droneport (round-robin for now)
      const droneport = FAKE_DRONEPORTS[index % FAKE_DRONEPORTS.length];

      // Generate order ID (use first 8 chars of Convex ID)
      const orderId = `ORD-${order._id.slice(0, 8).toUpperCase()}`;

      return {
        id: orderId,
        status: mapStatus(order.status),
        droneport,
        pickup: pickupAddress,
        dropoff: dropoffAddress,
        contents: getContentsDescription(order.lineItems),
      };
    });
  }, [convexOrders]);

  // Separate active and historical orders
  const activeOrders = useMemo(
    () => allOrders.filter((o) => o.status !== "Delivered" && o.status !== "Cancelled"),
    [allOrders]
  );

  const historicalOrders = useMemo(
    () => allOrders.filter((o) => o.status === "Delivered" || o.status === "Cancelled"),
    [allOrders]
  );

  const orders = showHistorical ? historicalOrders : activeOrders;

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="min-h-svh p-6">
        <Head>
          <title>AHA Enterprise</title>
        </Head>
        <div className="mx-auto w-full max-w-6xl">
          <PageHeader icon={ListOrdered} title="Orders" count={orders.length}>
            <Button
              variant={showHistorical ? "outline" : "default"}
              size="sm"
              onClick={() => setShowHistorical(false)}
            >
              Active
            </Button>
            <Button
              variant={showHistorical ? "default" : "outline"}
              size="sm"
              onClick={() => setShowHistorical(true)}
            >
              <History className="mr-2 size-4" /> Historical
            </Button>
          </PageHeader>
          <Separator className="my-4" />
          <div className="space-y-3">
            {orders.map((order) => (
              <OrderRow key={order.id} order={order} />
            ))}
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}
