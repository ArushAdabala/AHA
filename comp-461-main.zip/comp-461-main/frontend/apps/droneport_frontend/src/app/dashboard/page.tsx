"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import mapboxgl from "mapbox-gl";
import { useMutation, useQuery } from "convex/react";
import { api } from "@packages/backend/convex/_generated/api";
import Head from "next/head";
import { AppSidebar } from "@/components/app-sidebar";
import { OrderQueue } from "@/components/order-queue";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import { useDroneportContext } from "@/components/droneport-provider";

type QueueOrder = import("@/components/order-queue").Order;

const DEFAULT_CENTER: [number, number] = [-95.3698, 29.7604]; // Houston
const FALLBACK_DRONEPORT: [number, number] = [-95.3698, 29.7604];

function decodePolyline(encoded: string): [number, number][] {
  let index = 0;
  let lat = 0;
  let lng = 0;
  const coordinates: [number, number][] = [];
  while (index < encoded.length) {
    let result = 0;
    let shift = 0;
    let b: number;
    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlat = (result & 1) ? ~(result >> 1) : result >> 1;
    lat += dlat;

    result = 0;
    shift = 0;
    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlng = (result & 1) ? ~(result >> 1) : result >> 1;
    lng += dlng;
    coordinates.push([lng * 1e-5, lat * 1e-5]);
  }
  return coordinates;
}

function haversineDistance(a: [number, number], b: [number, number]) {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 6371000;
  const dLat = toRad(b[1] - a[1]);
  const dLng = toRad(b[0] - a[0]);
  const lat1 = toRad(a[1]);
  const lat2 = toRad(b[1]);
  const sinDLat = Math.sin(dLat / 2);
  const sinDLng = Math.sin(dLng / 2);
  const h =
    sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
  return 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function interpolateAlongLine(
  coords: [number, number][],
  startMs: number,
  durationSec: number,
  nowMs: number
): [number, number] | null {
  if (coords.length < 2 || !durationSec || !startMs) return null;
  const progress = Math.min(
    1,
    Math.max(0, (nowMs - startMs) / (durationSec * 1000))
  );
  let total = 0;
  for (let i = 1; i < coords.length; i++) {
    total += haversineDistance(coords[i - 1], coords[i]);
  }
  if (total === 0) return coords[coords.length - 1];
  const target = total * progress;
  let traveled = 0;
  for (let i = 1; i < coords.length; i++) {
    const seg = haversineDistance(coords[i - 1], coords[i]);
    if (traveled + seg >= target) {
      const remain = target - traveled;
      const t = seg === 0 ? 1 : remain / seg;
      const lng = coords[i - 1][0] + (coords[i][0] - coords[i - 1][0]) * t;
      const lat = coords[i - 1][1] + (coords[i][1] - coords[i - 1][1]) * t;
      return [lng, lat];
    }
    traveled += seg;
  }
  return coords[coords.length - 1];
}

function getCoordinates(
  address?:
    | {
        lat?: number;
        lng?: number;
        line1?: string;
        city?: string;
        state?: string;
      }
    | null
): [number, number] {
  if (address?.lat != null && address?.lng != null) {
    return [address.lng, address.lat];
  }
  return DEFAULT_CENTER;
}

function formatAddress(
  address?:
    | {
        line1?: string;
        line2?: string;
        city?: string;
        state?: string;
        postalCode?: string;
      }
    | null
): string {
  if (!address) return "";
  const parts = [
    address.line1,
    address.line2,
    address.city,
    address.state,
    address.postalCode,
  ].filter(Boolean);
  return parts.join(", ");
}

function computeLiveDroneCoord(order: any) {
  const dr = order?.droneRouting;
  if (!dr) return null;
  const now = Date.now();
  const leg1 =
    dr.leg1Polyline && typeof dr.leg1Polyline === "string"
      ? decodePolyline(dr.leg1Polyline)
      : [];
  const leg2 =
    dr.leg2Polyline && typeof dr.leg2Polyline === "string"
      ? decodePolyline(dr.leg2Polyline)
      : [];
  const retLegRaw =
    dr.returnPolyline && typeof dr.returnPolyline === "string"
      ? decodePolyline(dr.returnPolyline)
      : [];
  const retLeg =
    retLegRaw.length > 0
      ? retLegRaw
      : leg1.length && leg2.length
        ? [leg2[leg2.length - 1], leg1[0]]
        : [];

  const status = dr.status;
  if (status === "delivered" && leg2.length) return leg2[leg2.length - 1];
  if (status === "waiting_load" && leg1.length) return leg1[leg1.length - 1];

  if (status === "enroute_merchant" && leg1.length) {
    const start =
      dr.departedAt ??
      dr.startedAt ??
      order.createdAt ??
      dr.completedAt ??
      now;
    const dur = dr.leg1DurationSeconds ?? dr.durationSeconds ?? 0;
    return (
      interpolateAlongLine(leg1, start, dur, now) || leg1[leg1.length - 1]
    );
  }

  if (status === "enroute_customer" && leg2.length) {
    const start =
      dr.departedMerchantAt ??
      dr.loadConfirmedAt ??
      dr.arrivedMerchantAt ??
      dr.startedAt ??
      order.createdAt ??
      now;
    const dur = dr.leg2DurationSeconds ?? dr.durationSeconds ?? 0;
    return (
      interpolateAlongLine(leg2, start, dur, now) || leg2[leg2.length - 1]
    );
  }

  if (status === "enroute_return" && retLeg.length) {
    const start = dr.returnStartedAt ?? dr.deliveredAt ?? now;
    const dur =
      dr.returnDurationSeconds ??
      dr.leg2DurationSeconds ??
      dr.durationSeconds ??
      0;
    return (
      interpolateAlongLine(retLeg, start, dur, now) ||
      retLeg[retLeg.length - 1]
    );
  }

  if (status === "returned" && retLeg.length) {
    return retLeg[retLeg.length - 1];
  }

  return null;
}

export default function DashboardPage() {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const [mapReadyVersion, setMapReadyVersion] = useState(0);
  const { droneports, selectedDroneportId, setSelectedDroneportId, selectedDroneport } =
    useDroneportContext();
  const [selectedOrder, setSelectedOrder] = useState<QueueOrder | null>(null);
  const [liveTick, setLiveTick] = useState(0);
  const confirmLoad = useMutation(api.router.confirmLoad);

  const convexOrders = useQuery(api.orders.listAll, {});
  const convexDrones = useQuery(api.drones.list, {
    droneportId: selectedDroneportId ? (selectedDroneportId as any) : undefined,
  });

  const filteredDrones = useMemo(() => {
    const list = convexDrones ?? [];
    return list.filter(
      (d: any) =>
        !selectedDroneportId ||
        (d.droneportId && String(d.droneportId) === String(selectedDroneportId))
    );
  }, [convexDrones, selectedDroneportId]);

  const fleet = useMemo(() => {
    const list = filteredDrones;
    return {
      ready: list.filter((d: any) => d.status === "idle"),
      inflight: list.filter((d: any) => d.status === "in-flight"),
      charging: list.filter((d: any) => d.status === "charging"),
      maintenance: list.filter((d: any) => d.status === "maintenance"),
    };
  }, [filteredDrones]);

  // Refresh live marker every 2s
  useEffect(() => {
    const t = setInterval(() => setLiveTick((v) => v + 1), 2000);
    return () => clearInterval(t);
  }, []);

  const orders: QueueOrder[] = useMemo(() => {
    if (!convexOrders) return [];

    const filtered = convexOrders.filter(
      (order) =>
        order.status !== "completed" &&
        order.status !== "cancelled" &&
        (!selectedDroneportId ||
          String(order.droneRouting?.droneportId) === selectedDroneportId)
    );

    return filtered.map((order) => {
      const businessAddress = order.business?.address ?? null;
      const deliveryAddress = order.deliveryAddress ?? null;
      const basePickupCoord = getCoordinates(businessAddress);
      const baseDropoffCoord = getCoordinates(deliveryAddress);

      const dp =
        (order.droneRouting?.droneportId &&
          droneports.find(
            (d) => String(d._id) === String(order.droneRouting?.droneportId)
          )) ||
        null;
      const dpCoord =
        dp?.address?.lat != null && dp?.address?.lng != null
          ? [dp.address.lng, dp.address.lat]
          : FALLBACK_DRONEPORT;
      const droneportName =
        dp?.name ?? order.droneRouting?.droneportName ?? "Droneport";

      const leg1 =
        order.droneRouting?.leg1Polyline &&
        decodePolyline(order.droneRouting.leg1Polyline);
      const leg2 =
        order.droneRouting?.leg2Polyline &&
        decodePolyline(order.droneRouting.leg2Polyline);

      const etaMinutes =
        order.droneRouting?.durationSeconds != null
          ? Math.round(order.droneRouting.durationSeconds / 60)
          : null;
      const distanceKm =
        order.droneRouting?.distanceMeters != null
          ? order.droneRouting.distanceMeters / 1000
          : null;

      const items =
        (order.lineItems ?? []).map((li, idx) => ({
          name: (li as any).item?.name ?? `Item ${idx + 1}`,
          quantity: li.quantity,
          notes: (li as any).item?.description ?? undefined,
        })) ?? [];

      const routingStatus = order.droneRouting?.status;
      const displayStatus: QueueOrder["status"] =
        routingStatus === "enroute_merchant"
          ? "En Route to Merchant"
          : routingStatus === "waiting_load"
            ? "Waiting Load"
            : routingStatus === "enroute_customer"
              ? "En Route to Customer"
              : routingStatus === "enroute_return"
                ? "Returning"
                : routingStatus === "returned"
                  ? "Returned"
                  : routingStatus === "delivered"
                    ? "Delivered"
                    : routingStatus === "failed"
                      ? "Failed"
                      : routingStatus === "routing"
                        ? "Routing"
                        : "Pending";

      const droneportCoord = leg1?.length ? (leg1[0] as [number, number]) : dpCoord;
      const pickupCoord = leg1?.length
        ? (leg1[leg1.length - 1] as [number, number])
        : basePickupCoord;
      const dropoffCoord = leg2?.length
        ? (leg2[leg2.length - 1] as [number, number])
        : baseDropoffCoord;

      return {
        convexId: String(order._id),
        id: `ORD-${order._id.slice(0, 8).toUpperCase()}`,
        status: displayStatus,
        droneport: droneportName,
        pickup: formatAddress(businessAddress),
        dropoff: formatAddress(deliveryAddress),
        droneportCoord,
        pickupCoord,
        dropoffCoord,
        items,
        etaMinutes,
        distanceKm,
        meetingPoint: formatAddress(businessAddress),
        batteryRemainingPct: order.droneRouting?.batteryRemainingPct ?? null,
        leg1Minutes:
          order.droneRouting?.leg1DurationSeconds != null
            ? Math.round(order.droneRouting.leg1DurationSeconds / 60)
            : null,
        leg2Minutes:
          order.droneRouting?.leg2DurationSeconds != null
            ? Math.round(order.droneRouting.leg2DurationSeconds / 60)
            : null,
        routing: {
          leg1,
          leg2,
          returnLeg:
            order.droneRouting?.returnPolyline &&
            decodePolyline(order.droneRouting.returnPolyline),
          droneportName,
        },
      };
    });
  }, [convexOrders, droneports, selectedDroneportId]);

  // initialize map
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;
    mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN || "";
    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: "mapbox://styles/mapbox/streets-v12",
      center: DEFAULT_CENTER,
      zoom: 11,
    });
    map.on("load", () => setMapReadyVersion((v) => v + 1));
    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // draw selected order route
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !map.isStyleLoaded()) return;
    if (!selectedOrder) {
      const layerIds = [
        "selected-stops-layer",
        "selected-leg1-layer",
        "selected-leg2-layer",
        "selected-return-layer",
        "selected-drone-layer",
      ];
      const sourceIds = [
        "selected-stops",
        "selected-leg1",
        "selected-leg2",
        "selected-return",
        "selected-drone",
      ];
      layerIds.forEach((id) => {
        if (map.getLayer(id)) map.removeLayer(id);
      });
      sourceIds.forEach((id) => {
        if (map.getSource(id)) map.removeSource(id);
      });
      return;
    }
    const baseOrder =
      convexOrders?.find(
        (o: any) => `ORD-${o._id.slice(0, 8).toUpperCase()}` === selectedOrder.id
      ) ?? null;

    const stopsSourceId = "selected-stops";
    const stopsLayerId = "selected-stops-layer";
    const leg1SourceId = "selected-leg1";
    const leg2SourceId = "selected-leg2";
    const returnSourceId = "selected-return";
    const leg1LayerId = "selected-leg1-layer";
    const leg2LayerId = "selected-leg2-layer";
    const returnLayerId = "selected-return-layer";
    const droneSourceId = "selected-drone";
    const droneLayerId = "selected-drone-layer";

    [stopsLayerId, leg1LayerId, leg2LayerId, returnLayerId, droneLayerId].forEach((id) => {
      if (map.getLayer(id)) map.removeLayer(id);
    });
    [stopsSourceId, leg1SourceId, leg2SourceId, returnSourceId, droneSourceId].forEach((id) => {
      if (map.getSource(id)) map.removeSource(id);
    });

    const stops: GeoJSON.Feature<GeoJSON.Point, { label: string; role: string }>[] =
      [
        {
          type: "Feature",
          geometry: { type: "Point", coordinates: selectedOrder.droneportCoord },
          properties: { label: selectedOrder.droneport, role: "droneport" },
        },
        {
          type: "Feature",
          geometry: { type: "Point", coordinates: selectedOrder.pickupCoord },
          properties: { label: selectedOrder.pickup || "Merchant", role: "merchant" },
        },
        {
          type: "Feature",
          geometry: { type: "Point", coordinates: selectedOrder.dropoffCoord },
          properties: { label: selectedOrder.dropoff || "Customer", role: "customer" },
        },
      ];

    map.addSource(stopsSourceId, {
      type: "geojson",
      data: { type: "FeatureCollection", features: stops },
    });
    map.addLayer({
      id: stopsLayerId,
      type: "circle",
      source: stopsSourceId,
      paint: {
        "circle-color": "#ef4444",
        "circle-radius": 7,
        "circle-stroke-width": 2,
        "circle-stroke-color": "#ffffff",
      },
    });

    const popup = new mapboxgl.Popup({ closeButton: false, closeOnClick: false });
    const onEnter = (e: mapboxgl.MapLayerMouseEvent) => {
      map.getCanvas().style.cursor = "pointer";
      const feature = e.features?.[0];
      const label = (feature?.properties as any)?.label || "";
      popup.setLngLat(e.lngLat).setHTML(label).addTo(map);
    };
    const onMove = (e: mapboxgl.MapLayerMouseEvent) => {
      if (popup.isOpen()) popup.setLngLat(e.lngLat);
    };
    const onLeave = () => {
      map.getCanvas().style.cursor = "";
      popup.remove();
    };
    map.on("mouseenter", stopsLayerId, onEnter);
    map.on("mousemove", stopsLayerId, onMove);
    map.on("mouseleave", stopsLayerId, onLeave);

    if (selectedOrder.routing?.leg1?.length) {
      map.addSource(leg1SourceId, {
        type: "geojson",
        data: {
          type: "Feature",
          geometry: { type: "LineString", coordinates: selectedOrder.routing.leg1 },
          properties: {},
        },
      });
      map.addLayer({
        id: leg1LayerId,
        type: "line",
        source: leg1SourceId,
        paint: { "line-color": "#3b82f6", "line-width": 4 },
        layout: { "line-cap": "round", "line-join": "round" },
      });
    }
    const returnLeg =
      selectedOrder.routing?.returnLeg && selectedOrder.routing.returnLeg.length
        ? selectedOrder.routing.returnLeg
        : selectedOrder.routing?.leg2?.length && selectedOrder.routing?.leg1?.length
          ? [
              selectedOrder.routing.leg2[selectedOrder.routing.leg2.length - 1] as [
                number,
                number,
              ],
              selectedOrder.routing.leg1[0] as [number, number],
            ]
          : undefined;

    if (selectedOrder.routing?.leg2?.length) {
      map.addSource(leg2SourceId, {
        type: "geojson",
        data: {
          type: "Feature",
          geometry: { type: "LineString", coordinates: selectedOrder.routing.leg2 },
          properties: {},
        },
      });
      map.addLayer({
        id: leg2LayerId,
        type: "line",
        source: leg2SourceId,
        paint: { "line-color": "#22c55e", "line-width": 4 },
        layout: { "line-cap": "round", "line-join": "round" },
      });
    }
    if (returnLeg?.length) {
      map.addSource(returnSourceId, {
        type: "geojson",
        data: {
          type: "Feature",
          geometry: { type: "LineString", coordinates: returnLeg },
          properties: {},
        },
      });
      map.addLayer({
        id: returnLayerId,
        type: "line",
        source: returnSourceId,
        paint: { "line-color": "#f97316", "line-width": 3, "line-dasharray": [2, 2] },
        layout: { "line-cap": "round", "line-join": "round" },
      });
    }

    const coords: [number, number][] = [];
    if (selectedOrder.routing?.leg1?.length) {
      coords.push(...(selectedOrder.routing.leg1 as [number, number][]));
    }
    if (selectedOrder.routing?.leg2?.length) {
      coords.push(...(selectedOrder.routing.leg2 as [number, number][]));
    }
    if (coords.length === 0) {
      coords.push(
        selectedOrder.droneportCoord,
        selectedOrder.pickupCoord,
        selectedOrder.dropoffCoord
      );
    }
    if (returnLeg?.length) {
      coords.push(...(returnLeg as [number, number][]));
    }

    const live = computeLiveDroneCoord(baseOrder);
    if (live) {
      map.addSource(droneSourceId, {
        type: "geojson",
        data: {
          type: "Feature",
          geometry: { type: "Point", coordinates: live },
        },
      });
      map.addLayer({
        id: droneLayerId,
        type: "circle",
        source: droneSourceId,
        paint: {
          "circle-radius": 6,
          "circle-color": "#111827",
          "circle-stroke-width": 2,
          "circle-stroke-color": "#ffffff",
        },
      });
      coords.push(live as [number, number]);
    }

    const bounds = coords.reduce(
      (b, coord) => b.extend(coord as [number, number]),
      new mapboxgl.LngLatBounds(coords[0], coords[0])
    );
    map.fitBounds(bounds, { padding: 60, duration: 500 });

    return () => {
      map.off("mouseenter", stopsLayerId, onEnter);
      map.off("mousemove", stopsLayerId, onMove);
      map.off("mouseleave", stopsLayerId, onLeave);
      popup.remove();
    };
  }, [selectedOrder, mapReadyVersion, convexOrders, liveTick]);

  // Default selection and clear when switching droneport
  useEffect(() => {
    if (orders.length && !selectedOrder) {
      setSelectedOrder(orders[0]);
    } else if (!orders.length) {
      setSelectedOrder(null);
    }
  }, [orders, selectedDroneportId, selectedOrder]);

  return (
    <SidebarProvider className="overlay-sidebar">
      <Head>
        <title>AHA Enterprise</title>
      </Head>
      <AppSidebar />
      <SidebarInset className="min-h-svh p-0 relative">
        <div
          ref={mapContainerRef}
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
        />
        <div className="absolute right-4 top-4 z-10 w-96">
          <OrderQueue
            orders={orders}
            activeOrderId={selectedOrder?.id ?? null}
            onSelect={(o) => setSelectedOrder(o)}
            onConfirmLoad={(o) => {
              if (!o.convexId) return;
              confirmLoad({ orderId: o.convexId as any }).catch(() => {});
            }}
          />
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}
