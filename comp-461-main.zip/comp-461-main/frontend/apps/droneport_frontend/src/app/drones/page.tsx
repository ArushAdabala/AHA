"use client";

import { useMemo } from "react";
import { useQuery } from "convex/react";
import { api } from "@packages/backend/convex/_generated/api";
import { AppSidebar } from "@/components/app-sidebar";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import { PageHeader } from "@/components/page-header";
import { useDroneportContext } from "@/components/droneport-provider";
import { Plane } from "lucide-react";
import Head from "next/head";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  RadialBar,
  RadialBarChart,
  PolarAngleAxis,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Cell,
} from "recharts";

type Drone = {
  id: string;
  name: string;
  status: "in_use" | "maintenance" | "ready";
  battery: number; // percent
  lastMission: string;
};

// Helper to map Convex drone status to display status
function mapStatus(
  status?: "idle" | "in-flight" | "charging" | "maintenance" | null
): "in_use" | "maintenance" | "ready" {
  if (status === "maintenance") return "maintenance";
  if (status === "in-flight") return "in_use";
  return "ready"; // idle or charging are considered "ready"
}

// Helper to get last mission text
function getLastMission(
  currentOrderId: string | null | undefined,
  status?: string | null
): string {
  if (currentOrderId) {
    return "Active Delivery";
  }
  if (status === "charging") {
    return "Charging";
  }
  if (status === "maintenance") {
    return "Maintenance";
  }
  return "Standby";
}

function StatusPercentBar({ drones }: { drones: Drone[] }) {
  const data = useMemo(() => {
    const total = drones.length || 1;
    const maintenance = drones.filter((d) => d.status === "maintenance").length;
    const inUse = drones.filter((d) => d.status === "in_use").length;
    const ready = drones.filter((d) => d.status === "ready").length;
    return [
      {
        label: "Status %",
        Maintenance: (maintenance / total) * 100,
        InUse: (inUse / total) * 100,
        Ready: (ready / total) * 100,
      },
    ];
  }, [drones]);

  return (
    <div className="rounded-xl border bg-card text-card-foreground shadow-sm p-4">
      <div className="mb-2 text-base font-semibold">Fleet Status (Percent)</div>
      <div className="text-muted-foreground text-sm mb-4">
        Percentage of drones by status
      </div>
      <div style={{ width: "100%", height: 260 }}>
        <ResponsiveContainer>
          {/* Use raw percentage values and a fixed 0–100% Y scale */}
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="label" hide />
            <YAxis domain={[0, 100]} tickFormatter={(v) => `${v}%`} />
            <Tooltip formatter={(v: any) => `${Math.round(v)}%`} />
            <Legend />
            <Bar
              dataKey="Maintenance"
              stackId="a"
              name="Maintenance"
              fill="var(--destructive)"
            />
            <Bar
              dataKey="InUse"
              stackId="a"
              name="In Use"
              fill="var(--chart-4)"
            />
            <Bar
              dataKey="Ready"
              stackId="a"
              name="Ready"
              fill="var(--chart-2)"
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function AvgBatteryByStatus({ drones }: { drones: Drone[] }) {
  const data = useMemo(() => {
    const groups: Record<Drone["status"], number[]> = {
      in_use: [],
      maintenance: [],
      ready: [],
    };
    drones.forEach((d) => groups[d.status].push(d.battery));
    const avg = (arr: number[]) =>
      arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
    return [
      { status: "Maintenance", value: avg(groups.maintenance) },
      { status: "In Use", value: avg(groups.in_use) },
      { status: "Ready", value: avg(groups.ready) },
    ];
  }, [drones]);

  return (
    <div className="rounded-xl border bg-card text-card-foreground shadow-sm p-4">
      <div className="mb-2 text-base font-semibold">
        Average Battery by Status
      </div>
      <div className="text-muted-foreground text-sm mb-4">
        Mean battery level
      </div>
      <div style={{ width: "100%", height: 240 }}>
        <ResponsiveContainer>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="status" />
            <YAxis domain={[0, 100]} tickFormatter={(v) => `${v}%`} />
            <Tooltip formatter={(v: any) => `${Math.round(v)}%`} />
            <Bar dataKey="value" name="Avg Battery">
              {data.map((entry, idx) => (
                <Cell
                  key={idx}
                  fill={
                    entry.status === "Maintenance"
                      ? "var(--destructive)"
                      : entry.status === "In Use"
                      ? "var(--chart-4)"
                      : "var(--chart-2)"
                  }
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function BatteryDistribution({ drones }: { drones: Drone[] }) {
  const data = useMemo(() => {
    const buckets = [
      { label: "0-25%", min: 0, max: 25 },
      { label: "25-50%", min: 25, max: 50 },
      { label: "50-75%", min: 50, max: 75 },
      { label: "75-100%", min: 75, max: 100 },
    ];
    return buckets.map((b) => ({
      bucket: b.label,
      count: drones.filter(
        (d) =>
          d.battery >= b.min &&
          d.battery < (b.label === "75-100%" ? 101 : b.max)
      ).length,
    }));
  }, [drones]);

  return (
    <div className="rounded-xl border bg-card text-card-foreground shadow-sm p-4">
      <div className="mb-2 text-base font-semibold">Battery Distribution</div>
      <div className="text-muted-foreground text-sm mb-4">
        Drones per battery band
      </div>
      <div style={{ width: "100%", height: 240 }}>
        <ResponsiveContainer>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="bucket" />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="count" name="# Drones" fill="var(--chart-3)" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function ReadinessGauge({ drones }: { drones: Drone[] }) {
  const data = useMemo(() => {
    const ready = drones.filter((d) => d.status === "ready").length;
    const pct = Math.round((ready / (drones.length || 1)) * 100);
    return [{ name: "Ready", value: pct, fill: "var(--chart-2)" }];
  }, [drones]);

  return (
    <div className="rounded-xl border bg-card text-card-foreground shadow-sm p-4">
      <div className="mb-2 text-base font-semibold">Readiness Rate</div>
      <div className="text-muted-foreground text-sm mb-4">
        Share of fleet ready
      </div>
      <div style={{ width: "100%", height: 240 }}>
        <ResponsiveContainer>
          <RadialBarChart
            innerRadius="70%"
            outerRadius="100%"
            data={data}
            startAngle={90}
            endAngle={-270}
          >
            {/* Fix domain to map value (0–100) to angle rather than full circle */}
            <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
            <RadialBar dataKey="value" background cornerRadius={8} />
            <Tooltip formatter={(v: any) => `${v}%`} />
            <text
              x="50%"
              y="50%"
              textAnchor="middle"
              dominantBaseline="middle"
              fill="currentColor"
              fontSize={18}
            >
              {`${data[0].value}%`}
            </text>
          </RadialBarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function DroneCard({ drone }: { drone: Drone }) {
  const statusLabel =
    drone.status === "in_use"
      ? "In Use"
      : drone.status === "maintenance"
      ? "Maintenance"
      : "Ready";

  const badgeClass =
    drone.status === "in_use"
      ? "bg-primary text-primary-foreground"
      : drone.status === "maintenance"
      ? "bg-destructive text-destructive-foreground"
      : "bg-secondary text-secondary-foreground";

  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm p-4">
      <div className="flex items-center justify-between">
        <div className="font-semibold">{drone.name}</div>
        <span
          className={`rounded-md px-2 py-0.5 text-xs font-medium ${badgeClass}`}
        >
          {statusLabel}
        </span>
      </div>
      <div className="mt-3 text-sm space-y-1">
        <div className="text-muted-foreground">ID</div>
        <div className="font-medium">{drone.id}</div>
        <div className="text-muted-foreground mt-2">Battery</div>
        <div className="font-medium">{drone.battery}%</div>
        <div className="text-muted-foreground mt-2">Last mission</div>
        <div className="font-medium">{drone.lastMission}</div>
      </div>
    </div>
  );
}

export default function DronesPage() {
  const { selectedDroneportId, selectedDroneport } = useDroneportContext();
  // Fetch all drones from Convex
  const convexDrones = useQuery(api.drones.list, {
    droneportId: selectedDroneportId ? (selectedDroneportId as any) : undefined,
  });

  // Transform Convex drones to display format
  const drones: Drone[] = useMemo(() => {
    if (!convexDrones) return [];

    return convexDrones.map((drone, index) => {
      // Generate a name like "Falcon 1", "Falcon 2", etc.
      const name = `Falcon ${index + 1}`;
      // Use first 8 chars of Convex ID for display
      const id = `DR-${drone._id.slice(0, 8).toUpperCase()}`;

      return {
        id,
        name,
        status: mapStatus(drone.status),
        battery: drone.batteryPercent,
        lastMission: getLastMission(drone.currentOrderId, drone.status),
      };
    });
  }, [convexDrones]);

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="min-h-svh p-6">
        <Head>
          <title>AHA Enterprise</title>
        </Head>
        <div className="mx-auto w-full max-w-7xl space-y-6">
          <PageHeader
            icon={Plane}
            title="Drones"
            count={drones.length}
            countLabel="drones"
          ></PageHeader>
          <div className="text-sm text-muted-foreground">
            {selectedDroneport
              ? `Showing drones at ${selectedDroneport.name}`
              : "All droneports"}
          </div>
          <Separator className="my-4" />
          <div className="text-lg font-semibold">Fleet Stats</div>
          <StatusPercentBar drones={drones} />

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            <AvgBatteryByStatus drones={drones} />
            <BatteryDistribution drones={drones} />
            <ReadinessGauge drones={drones} />
          </div>

          <div className="text-lg font-semibold">Drones</div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {drones.map((d) => (
              <DroneCard key={d.id} drone={d} />
            ))}
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}
