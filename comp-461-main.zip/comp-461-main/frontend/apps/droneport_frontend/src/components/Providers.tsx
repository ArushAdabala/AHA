"use client";

import { ClerkProvider } from "@clerk/nextjs";
import ConvexProviderWithAuth from "./ConvexProviderWithAuth";
import { DroneportProvider } from "./droneport-provider";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider
      publishableKey={process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY || ""}
    >
      <ConvexProviderWithAuth>
        <DroneportProvider>{children}</DroneportProvider>
      </ConvexProviderWithAuth>
    </ClerkProvider>
  );
}
