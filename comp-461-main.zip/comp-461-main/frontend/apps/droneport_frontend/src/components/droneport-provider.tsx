"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useQuery } from "convex/react";
import { api } from "@packages/backend/convex/_generated/api";

type Droneport = {
  _id: string;
  name: string;
  address?: {
    line1?: string;
    city?: string;
    state?: string;
    lat?: number;
    lng?: number;
  } | null;
};

type DroneportContextValue = {
  droneports: Droneport[];
  selectedDroneportId: string | null;
  setSelectedDroneportId: (id: string | null) => void;
  selectedDroneport: Droneport | null;
};

const DroneportContext = createContext<DroneportContextValue | undefined>(
  undefined
);

export function useDroneportContext(): DroneportContextValue {
  const ctx = useContext(DroneportContext);
  if (!ctx) {
    throw new Error(
      "useDroneportContext must be used within a DroneportProvider"
    );
  }
  return ctx;
}

export function DroneportProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const droneportsResult = useQuery(api.droneports.list, {
    onlyActive: true,
  });
  const droneports = (droneportsResult ?? []) as Droneport[];

  const [selectedDroneportId, setSelectedDroneportId] = useState<string | null>(
    null
  );

  // Default to first active droneport
  useEffect(() => {
    if (droneports.length === 0) return;
    if (!selectedDroneportId) {
      setSelectedDroneportId(String(droneports[0]._id));
    }
  }, [droneports, selectedDroneportId]);

  const value = useMemo<DroneportContextValue>(() => {
    const selected =
      droneports.find((d) => String(d._id) === selectedDroneportId) ?? null;
    return {
      droneports,
      selectedDroneportId,
      setSelectedDroneportId,
      selectedDroneport: selected,
    };
  }, [droneports, selectedDroneportId]);

  return (
    <DroneportContext.Provider value={value}>
      {children}
    </DroneportContext.Provider>
  );
}
