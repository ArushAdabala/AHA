import { redirect } from "next/navigation";

export default function Page() {
  // Send users to the full-screen map dashboard.
  redirect("/dashboard");
}
