"use client";

import { useEffect, useMemo, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@packages/backend/convex/_generated/api";
import {
  ChevronDown,
  EllipsisVertical,
  ListOrdered,
  Search,
  SlidersHorizontal,
} from "lucide-react";
import Head from "next/head";

import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AppSidebar } from "@/components/app-sidebar";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import { PageHeader } from "@/components/page-header";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { useBusinessContext } from "@/components/business-provider";

type OrderStatus = "Pending" | "En Route" | "Delivered" | "Cancelled";

type Order = {
  id: string;
  status: OrderStatus;
  droneport: string;
  pickup: string;
  dropoff: string;
  contents: string;
};

// Same fake droneports as dashboard/droneport_frontend for now
const FAKE_DRONEPORTS = [
  "IAH Droneport",
  "Pearland Droneport",
  "Sugar Land Droneport",
  "Houston Droneport",
  "Katy Droneport",
  "The Woodlands Droneport",
];

type ConvexOrderStatus =
  | "pending"
  | "paid"
  | "preparing"
  | "delivering"
  | "completed"
  | "cancelled";

function formatAddress(
  address?:
    | {
        line1?: string;
        line2?: string;
        city?: string;
        state?: string;
        postalCode?: string;
      }
    | null
): string {
  if (!address) return "Unknown";
  const parts = [
    address.line1,
    address.line2,
    address.city,
    address.state,
    address.postalCode,
  ].filter(Boolean);
  return parts.join(", ") || "Unknown";
}

function mapStatus(status: ConvexOrderStatus): OrderStatus {
  if (status === "cancelled") return "Cancelled";
  if (status === "completed") return "Delivered";
  if (status === "delivering") return "En Route";
  return "Pending"; // pending, paid, preparing
}

function getContentsDescription(
  lineItems: Array<{
    quantity: number;
    item?: { name?: string | null } | null;
  }>
): string {
  if (!lineItems.length) return "No items";

  const parts = lineItems.map((lineItem) => {
    const name = lineItem.item?.name ?? "Item";
    return `${name} × ${lineItem.quantity}`;
  });

  return parts.join(", ");
}

function StatusTag({ status }: { status: OrderStatus }) {
  const colorClass =
    status === "Pending"
      ? "bg-secondary text-secondary-foreground"
      : status === "En Route"
      ? "bg-primary text-primary-foreground"
      : status === "Delivered"
      ? "bg-accent text-accent-foreground"
      : "bg-muted text-muted-foreground";

  return (
    <span
      className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ${colorClass}`}
    >
      {status}
    </span>
  );
}

export default function OrdersPage() {
  const { selectedBusinessId } = useBusinessContext();
  const convexOrders = useQuery(api.orders.listAll, {});

  const allOrders = useMemo<Order[]>(() => {
    if (!convexOrders) return [];

    const byBusiness = selectedBusinessId
      ? convexOrders.filter(
          (order) =>
            order.business &&
            String(order.business._id) === String(selectedBusinessId)
        )
      : convexOrders;

    return byBusiness.map((order, index) => {
      const businessAddress = order.business?.address ?? null;
      const deliveryAddress = order.deliveryAddress ?? null;
      const pickup = formatAddress(businessAddress);
      const dropoff = formatAddress(deliveryAddress);
      const droneport =
        FAKE_DRONEPORTS[index % FAKE_DRONEPORTS.length] ?? "Droneport";
      const orderId = `ORD-${order._id.slice(0, 8).toUpperCase()}`;

      const anyOrder = order as any;
      return {
        id: orderId,
        status: mapStatus(order.status as ConvexOrderStatus),
        droneport,
        pickup,
        dropoff,
        contents: getContentsDescription(anyOrder.lineItems ?? []),
      };
    });
  }, [convexOrders, selectedBusinessId]);

  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | OrderStatus>("All");
  const [droneportFilter, setDroneportFilter] = useState<string>("All");

  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [detail, setDetail] = useState<Order | null>(null);

  useEffect(() => {
    setOrders(allOrders);
    setSelectedIds(new Set());
    setDetail(null);
  }, [allOrders]);

  const droneports = useMemo(
    () => Array.from(new Set(allOrders.map((o) => o.droneport))),
    [allOrders]
  );

  const filtered = orders.filter((o) => {
    const matchesStatus =
      statusFilter === "All" ? true : o.status === statusFilter;
    const matchesDroneport =
      droneportFilter === "All" ? true : o.droneport === droneportFilter;
    const q = query.trim().toLowerCase();
    const matchesQuery = q
      ? [o.id, o.droneport, o.pickup, o.dropoff, o.contents].some((v) =>
          v.toLowerCase().includes(q)
        )
      : true;
    return matchesStatus && matchesDroneport && matchesQuery;
  });

  const allVisibleSelected =
    filtered.length > 0 && filtered.every((o) => selectedIds.has(o.id));
  const someSelected = filtered.some((o) => selectedIds.has(o.id));

  function toggleSelectAll() {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allVisibleSelected) {
        filtered.forEach((o) => next.delete(o.id));
      } else {
        filtered.forEach((o) => next.add(o.id));
      }
      return next;
    });
  }

  function toggleRow(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function updateStatus(ids: string[], status: OrderStatus) {
    setOrders((prev) =>
      prev.map((o) => (ids.includes(o.id) ? { ...o, status } : o))
    );
    setSelectedIds((s) => {
      const next = new Set(s);
      ids.forEach((id) => next.delete(id));
      return next;
    });
  }

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="min-h-svh p-6">
        <Head>
          <title>AHA Merchant</title>
        </Head>
        <div className="mx-auto w-full max-w-6xl">
          <PageHeader icon={ListOrdered} title="Orders" count={filtered.length}>
            <div className="flex items-center gap-2">
              <div className="relative w-64">
                <Search className="pointer-events-none absolute left-2 top-2.5 size-4 text-muted-foreground" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search orders…"
                  className="pl-8"
                />
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <SlidersHorizontal className="mr-2 size-4" /> Filters
                    <ChevronDown className="ml-1 size-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  <div className="px-2 py-1.5 text-xs text-muted-foreground">
                    Status
                  </div>
                  <DropdownMenuItem onSelect={() => setStatusFilter("All")}>
                    All
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => setStatusFilter("Pending")}>
                    Pending
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => setStatusFilter("En Route")}
                  >
                    En Route
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => setStatusFilter("Delivered")}
                  >
                    Delivered
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => setStatusFilter("Cancelled")}
                  >
                    Cancelled
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <div className="px-2 py-1.5 text-xs text-muted-foreground">
                    Droneport
                  </div>
                  <DropdownMenuItem onSelect={() => setDroneportFilter("All")}>
                    All
                  </DropdownMenuItem>
                  {droneports.map((d) => (
                    <DropdownMenuItem
                      key={d}
                      onSelect={() => setDroneportFilter(d)}
                    >
                      {d}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant={someSelected ? "default" : "outline"}
                    size="sm"
                    disabled={!someSelected}
                  >
                    Bulk actions
                    <ChevronDown className="ml-2 size-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    onSelect={() =>
                      updateStatus(Array.from(selectedIds), "En Route")
                    }
                  >
                    Mark En Route
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() =>
                      updateStatus(Array.from(selectedIds), "Delivered")
                    }
                  >
                    Mark Delivered
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() =>
                      updateStatus(Array.from(selectedIds), "Cancelled")
                    }
                  >
                    Cancel
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </PageHeader>

          <Separator className="my-4" />

          <div className="overflow-hidden rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-accent/40 text-muted-foreground">
                <tr>
                  <th className="w-10 px-3 py-2 text-left">
                    <input
                      type="checkbox"
                      aria-label="Select all"
                      checked={allVisibleSelected}
                      onChange={toggleSelectAll}
                      className="h-4 w-4 rounded border-input align-middle"
                    />
                  </th>
                  <th className="px-3 py-2 text-left">Order</th>
                  <th className="px-3 py-2 text-left">Status</th>
                  <th className="px-3 py-2 text-left">Droneport</th>
                  <th className="px-3 py-2 text-left">Pickup</th>
                  <th className="px-3 py-2 text-left">Dropoff</th>
                  <th className="w-12 px-3 py-2"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((o) => {
                  const checked = selectedIds.has(o.id);
                  return (
                    <tr key={o.id} className="border-t">
                      <td className="px-3 py-2 align-top">
                        <input
                          type="checkbox"
                          aria-label={`Select ${o.id}`}
                          checked={checked}
                          onChange={() => toggleRow(o.id)}
                          className="h-4 w-4 rounded border-input align-middle"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <button
                          className="font-medium hover:underline"
                          onClick={() => setDetail(o)}
                        >
                          {o.id}
                        </button>
                      </td>
                      <td className="px-3 py-2">
                        <StatusTag status={o.status} />
                      </td>
                      <td className="px-3 py-2">{o.droneport}</td>
                      <td className="px-3 py-2">{o.pickup}</td>
                      <td className="px-3 py-2">{o.dropoff}</td>
                      <td className="px-3 py-2 text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              size="icon"
                              variant="ghost"
                              aria-label="Actions"
                            >
                              <EllipsisVertical className="size-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onSelect={() => setDetail(o)}>
                              View details
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onSelect={() => updateStatus([o.id], "En Route")}
                            >
                              Mark En Route
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onSelect={() => updateStatus([o.id], "Delivered")}
                            >
                              Mark Delivered
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onSelect={() => updateStatus([o.id], "Cancelled")}
                            >
                              Cancel
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr>
                    <td
                      colSpan={7}
                      className="px-3 py-10 text-center text-muted-foreground"
                    >
                      No orders match your filters
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {someSelected && (
            <div className="mt-3 text-sm text-muted-foreground">
              {selectedIds.size} selected
            </div>
          )}
        </div>
      </SidebarInset>

      <Sheet open={!!detail} onOpenChange={(open) => !open && setDetail(null)}>
        <SheetContent side="right">
          {detail && (
            <>
              <SheetHeader>
                <SheetTitle>{detail.id}</SheetTitle>
                <SheetDescription>
                  Manage and view order details
                </SheetDescription>
              </SheetHeader>
              <div className="space-y-4 px-4">
                <div className="flex items-center gap-2">
                  <div className="text-muted-foreground">Status</div>
                  <StatusTag status={detail.status} />
                </div>
                <div>
                  <div className="text-muted-foreground">Droneport</div>
                  <div className="font-medium">{detail.droneport}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Pickup</div>
                  <div className="font-medium">{detail.pickup}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Dropoff</div>
                  <div className="font-medium">{detail.dropoff}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Contents</div>
                  <div className="font-medium">{detail.contents}</div>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="flex gap-2 px-4 pb-4">
                <Button onClick={() => updateStatus([detail.id], "En Route")}>
                  Mark En Route
                </Button>
                <Button
                  variant="outline"
                  onClick={() => updateStatus([detail.id], "Delivered")}
                >
                  Mark Delivered
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => updateStatus([detail.id], "Cancelled")}
                >
                  Cancel
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </SidebarProvider>
  );
}
