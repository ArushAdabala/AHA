"use client";

import { ClerkProvider } from "@clerk/nextjs";
import ConvexProviderWithAuth from "./ConvexProviderWithAuth";
import { BusinessProvider } from "./business-provider";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider
      publishableKey={process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY || ""}
    >
      <ConvexProviderWithAuth>
        <BusinessProvider>{children}</BusinessProvider>
      </ConvexProviderWithAuth>
    </ClerkProvider>
  );
}


