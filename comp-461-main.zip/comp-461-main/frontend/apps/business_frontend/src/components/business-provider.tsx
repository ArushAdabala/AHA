"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useQuery } from "convex/react";
import { api } from "@packages/backend/convex/_generated/api";

type Business = {
  _id: string;
  name: string;
  address?: {
    line1?: string;
    city?: string;
    state?: string;
  } | null;
};

type BusinessContextValue = {
  businesses: Business[];
  selectedBusinessId: string | null;
  setSelectedBusinessId: (id: string | null) => void;
  selectedBusiness: Business | null;
};

const BusinessContext = createContext<BusinessContextValue | undefined>(
  undefined
);

export function useBusinessContext(): BusinessContextValue {
  const ctx = useContext(BusinessContext);
  if (!ctx) {
    throw new Error(
      "useBusinessContext must be used within a BusinessProvider"
    );
  }
  return ctx;
}

export function BusinessProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const businessesResult = useQuery(api.businesses.list, {
    onlyActive: true,
  });
  const [selectedBusinessId, setSelectedBusinessId] = useState<string | null>(
    null
  );

  const businesses = (businessesResult ?? []) as Business[];

  // Default selection to the first active business when data loads
  useEffect(() => {
    if (businesses.length === 0) return;
    if (!selectedBusinessId) {
      setSelectedBusinessId(String(businesses[0]._id));
    }
  }, [businesses, selectedBusinessId]);

  const value = useMemo<BusinessContextValue>(() => {
    const selected =
      businesses.find((b) => String(b._id) === selectedBusinessId) ?? null;

    return {
      businesses,
      selectedBusinessId,
      setSelectedBusinessId,
      selectedBusiness: selected,
    };
  }, [businesses, selectedBusinessId]);

  return (
    <BusinessContext.Provider value={value}>
      {children}
    </BusinessContext.Provider>
  );
}


