"use client";

import * as React from "react";
import type { LucideIcon } from "lucide-react";

type PageHeaderProps = {
  icon?: LucideIcon;
  title: string;
  count?: number;
  countLabel?: string;
  children?: React.ReactNode; // right-side actions
};

export function PageHeader({
  icon: Icon,
  title,
  count,
  countLabel = "items",
  children,
}: PageHeaderProps) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        {Icon ? <Icon className="size-5" /> : null}
        <h1 className="text-xl font-semibold">{title}</h1>
        {typeof count === "number" ? (
          <span className="text-muted-foreground text-sm">
            {count} {countLabel}
          </span>
        ) : null}
      </div>
      {children ? (
        <div className="flex items-center gap-2">{children}</div>
      ) : null}
    </div>
  );
}
