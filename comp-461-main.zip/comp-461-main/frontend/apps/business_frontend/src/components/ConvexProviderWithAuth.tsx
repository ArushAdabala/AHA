"use client";

import { ConvexProviderWithClerk } from "convex/react-clerk";
import { useAuth } from "@clerk/nextjs";
import { convexClient } from "../lib/convexClient";

/**
 * Convex provider with Clerk authentication for client-side components
 * Uses the centralized convexClient instance
 */
export default function ConvexProviderWithAuth({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ConvexProviderWithClerk client={convexClient} useAuth={useAuth}>
      {children}
    </ConvexProviderWithClerk>
  );
}


