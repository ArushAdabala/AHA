"use client";

import { Separator } from "@/components/ui/separator";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

type OrderStatus =
  | "Pending"
  | "Routing"
  | "En Route to Merchant"
  | "Waiting Load"
  | "En Route to Customer"
  | "Returning"
  | "Returned"
  | "Delivered"
  | "Failed";

export type Order = {
  convexId: string;
  id: string;
  status: OrderStatus;
  droneport: string;
  pickup: string;
  dropoff: string;
  droneportCoord: [number, number];
  pickupCoord: [number, number];
  dropoffCoord: [number, number];
  items: { name: string; quantity: number; notes?: string }[];
  etaMinutes?: number | null;
  distanceKm?: number | null;
  leg1Minutes?: number | null;
  leg2Minutes?: number | null;
  droneId?: string | null;
  batteryRemainingPct?: number | null;
  routing?: {
    leg1?: [number, number][];
    leg2?: [number, number][];
    returnLeg?: [number, number][];
    droneportName?: string;
  };
  meetingPoint?: string;
  timestamps?: {
    startedAt?: number;
    arrivedMerchantAt?: number;
    loadConfirmedAt?: number;
    departedMerchantAt?: number;
    deliveredAt?: number;
  };
};

function StatusTag({ status }: { status: OrderStatus }) {
  const statusClasses = {
    Pending: "bg-secondary text-secondary-foreground",
    Routing: "bg-secondary text-secondary-foreground",
    "En Route to Merchant": "bg-primary text-primary-foreground",
    "Waiting Load": "bg-amber-200 text-amber-900",
    "En Route to Customer": "bg-primary text-primary-foreground",
    Returning: "bg-secondary text-secondary-foreground",
    Returned: "bg-secondary text-secondary-foreground",
    Delivered: "bg-emerald-200 text-emerald-900",
    Failed: "bg-destructive text-destructive-foreground",
  }[status];

  return (
    <span
      className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ${statusClasses}`}
    >
      {status}
    </span>
  );
}

function OrderCard({ order }: { order: Order }) {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
      <div className="flex items-center justify-between p-3">
        <div className="font-medium">{order.id}</div>
        <StatusTag status={order.status} />
      </div>
      <Separator />
      <div className="space-y-2 p-3 text-sm">
        <div>
          <div className="text-muted-foreground">Droneport</div>
          <div className="font-medium">{order.droneport}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Pickup</div>
          <div className="font-medium">{order.pickup}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Dropoff</div>
          <div className="font-medium">{order.dropoff}</div>
        </div>
        {(order.etaMinutes != null || order.distanceKm != null) && (
          <div className="flex gap-3 text-muted-foreground text-xs">
            {order.etaMinutes != null && <span>ETA: {order.etaMinutes} min</span>}
            {order.distanceKm != null && (
              <span>Dist: {order.distanceKm.toFixed(1)} km</span>
            )}
            {order.batteryRemainingPct != null && (
              <span>Battery: {order.batteryRemainingPct.toFixed(0)}%</span>
            )}
          </div>
        )}
        {(order.leg1Minutes || order.leg2Minutes) && (
          <div className="text-muted-foreground text-xs">
            {order.leg1Minutes ? `Leg1: ${order.leg1Minutes} min` : ""}{" "}
            {order.leg2Minutes ? `Leg2: ${order.leg2Minutes} min` : ""}
          </div>
        )}
        {order.timestamps?.startedAt && (
          <div className="text-[11px] text-muted-foreground">
            Started {formatDistanceToNow(order.timestamps.startedAt, { addSuffix: true })}
          </div>
        )}
      </div>
    </div>
  );
}

// Mini map removed per request; keeping textual details only

export function OrderQueue({
  orders: ordersProp,
  onSelect,
  activeOrderId,
  onConfirmLoad,
}: {
  orders?: Order[];
  onSelect?: (order: Order) => void;
  activeOrderId?: string | null;
  onConfirmLoad?: (order: Order) => void;
}) {
  const orders: Order[] = ordersProp ?? [];

  const [openOrderId, setOpenOrderId] = useState<string | null>(null);

  return (
    <div className="pointer-events-auto fixed right-4 inset-y-4 z-20 w-96 md:right-6 md:inset-y-6">
      <div className="rounded-xl border bg-card text-card-foreground shadow flex h-full flex-col">
        <div className="flex items-center justify-between p-4">
          <div className="text-base font-semibold">Order Queue</div>
          <div className="text-muted-foreground text-sm">
            {orders.length} items
          </div>
        </div>
        <Separator />
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {orders.map((order) => {
            const isActive = activeOrderId === order.id;
            const isOpen = openOrderId === order.id;
            return (
              <Collapsible
                key={order.id}
                open={isOpen}
                onOpenChange={(next) => {
                  setOpenOrderId(next ? order.id : null);
                }}
                className={`w-full ${
                  isActive ? "ring-2 ring-ring rounded-lg" : ""
                }`}
              >
                <CollapsibleTrigger asChild>
                  <button
                    onClick={() => {
                      onSelect?.(order);
                    }}
                    className="w-full text-left"
                  >
                    <OrderCard order={order} />
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="rounded-b-lg border-x border-b bg-muted/20 p-3 space-y-3">
                    <div className="text-sm font-medium">Meeting Details</div>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="text-muted-foreground">Business</div>
                        <div className="font-medium break-words">
                          {order.pickup}
                        </div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">
                          Meeting Point
                        </div>
                        <div className="font-medium break-words">
                          {order.meetingPoint}
                        </div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Droneport</div>
                        <div className="font-medium break-words">
                          {order.droneport}
                        </div>
                      </div>
                    </div>
                    <Separator />
                    <div>
                    <div className="text-sm font-medium mb-1">
                      Order Contents
                    </div>
                    <ul className="list-disc pl-5 text-sm space-y-1">
                      {order.items.map((it, idx) => (
                          <li key={idx}>
                            <span className="font-medium">{it.name}</span>
                            <span className="text-muted-foreground">
                              {" "}
                              × {it.quantity}
                            </span>
                            {it.notes ? (
                              <span className="text-muted-foreground">
                                {" "}
                                — {it.notes}
                              </span>
                            ) : null}
                          </li>
                        ))}
                      </ul>
                    </div>
                    {order.status === "Waiting Load" && (
                      <div className="pt-2">
                        <Button
                          size="sm"
                          onClick={() => onConfirmLoad?.(order)}
                          className="w-full"
                        >
                          Confirm Loaded on Drone
                        </Button>
                      </div>
                    )}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            );
          })}
        </div>
      </div>
    </div>
  );
}
