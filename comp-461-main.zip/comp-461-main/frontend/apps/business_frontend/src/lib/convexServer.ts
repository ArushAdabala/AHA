import "server-only";

import { auth } from "@clerk/nextjs/server";

/**
 * Get Clerk auth token for server-side Convex queries
 * Use this with fetchQuery from convex/nextjs
 *
 * This is a server-only function and should only be imported in:
 * - Server Components
 * - Server Actions
 * - API routes
 *
 * @returns Clerk JWT token or undefined if not authenticated
 */
export async function getConvexAuthToken(): Promise<string | undefined> {
  try {
    const { getToken } = await auth();
    if (getToken) {
      const token = await getToken({ template: "convex" });
      return token || undefined;
    }
  } catch (error) {
    // If auth is not available (e.g., public route), return undefined
    // This allows public pages to work without authentication
    console.debug("No auth token available for Convex query");
  }

  return undefined;
}


