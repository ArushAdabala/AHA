# AHA Monorepo (Frontends + Go Router)

This repo contains:

- **Go router backend** (`backend/`): pulls orders from Convex, assigns drones, computes routes, and pushes status/route + fleet state back to Convex.
- **Convex backend** (`frontend/packages/backend/`): schemas, actions, and seeds for businesses, orders, droneports, drones.
- **Next.js apps** (`frontend/apps/`):
  - `customer_frontend` (“AHA” consumer app)
  - `business_frontend` (“AHA Merchant” dashboard)
  - `droneport_frontend` (“AHA Enterprise” ops dashboard)

## Prerequisites

- Node 18+ and **pnpm** (e.g., `npm i -g pnpm`)
- Go 1.21+
- Convex account (deployment URL/token)

## Environment

- Convex shared env lives in `frontend/packages/backend/.env` (deployment + Clerk issuer).
- App envs: `frontend/apps/*/.env` hold `NEXT_PUBLIC_CONVEX_URL` and Clerk keys per app.
- Go router env (`backend/.env`):
  - `CONVEX_ROUTER_URL=https://<your-deployment>.convex.site` (HTTP actions host)
  - `CONVEX_ROUTER_TOKEN=<router access token>` (must match Convex env `ROUTER_ACCESS_TOKEN`)

## Install (frontends + Convex)

```bash
cd frontend
pnpm install
```

## Run Convex (dev)

```bash
cd frontend/packages/backend
pnpm convex dev
```

Seed mock data (businesses/items/droneports/drones):

```bash
pnpm convex run seeds:seedMockData '{"force":true}'
```

## Run apps (dev)

From `frontend/`:

```bash
# all apps in parallel
pnpm dev

# or individually
pnpm --filter customer_frontend dev
pnpm --filter business_frontend dev
pnpm --filter droneport_frontend dev
```

## Go router (routes + fleet sync)

```bash
cd backend
# ensure backend/.env has CONVEX_ROUTER_URL and CONVEX_ROUTER_TOKEN
go run .
```

What it does:
- Polls Convex `router/pull` for pending orders, computes two-leg drone routes, and reports results to `router/result`.
- Tracks lifecycle: enroute to merchant → waiting_load (requires “Confirm loaded” from business/droneport UI) → enroute to customer → delivered.
- Pushes fleet snapshots to Convex `router/fleet` so the droneport dashboard shows per-port drones/battery/status.

## Data flow

1) Consumer app creates orders (Convex `orders`).
2) Go router ingests pending orders via Convex HTTP actions, computes routes, and updates `orders.droneRouting`.
3) Business/droneport apps read Convex orders; “Confirm loaded” triggers `router.confirmLoad`, which lets the router fly leg 2.
4) Fleet state (`drones` table) comes from Go fleet snapshots; droneport “Drones” page filters by the selected droneport.

## Useful scripts

- Build all: `pnpm build`
- Lint all: `pnpm lint`
- Seed data: `pnpm convex run seeds:seedMockData '{"force":true}'`

## Notes

- If you change Convex deployment, update `.env` files and restart apps/router.
- Make sure Convex env has `ROUTER_ACCESS_TOKEN` matching `CONVEX_ROUTER_TOKEN` for the Go router to post results/fleet.
